package Buttons.MainMenuPanel;

import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class ExitButton extends OriginalButton {

	public ExitButton() {
		super((BufferedImage)MyObjectCollection.getInstance().getImage("ExitInClick"),
				(BufferedImage)MyObjectCollection.getInstance().getImage("ExitOutClick"), 
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50 ,
				(int)MyAdminister.getInstance().getSizeOfFrame().getHeight()-50 - 100, 400, 100);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if(rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			System.exit(0);
		}
	}

}
