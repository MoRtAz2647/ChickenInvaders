package BossPackage;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import Tool.IntersectsRotateRectangle;

public class Fire implements Movable, Destroyable, Updatable, Paintable, Serializable {

	private transient BufferedImage fireImage;

	private double x;
	private double y;
	private int width = 100;
	private int height = 25;

	private double velocty = 3.25;
	private double degree;

	private boolean isDestroy;

	public Fire(Point point, double degree) {
		x = point.getX();
		y = point.getY();
		this.degree = degree;

		getImage();

	}

	private void getImage() {
		fireImage = resize((BufferedImage) MyObjectCollection.getInstance().getImage("Fire"), height, width);

	}

	private static BufferedImage resize(BufferedImage img, int height, int width) {
		Image tmp = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = resized.createGraphics();
		g2d.drawImage(tmp, 0, 0, null);
		g2d.dispose();
		return resized;
	}

	@Override
	public void paint(Graphics2D g) {
//		g.drawImage(fireImage,(int) x,(int) y, width, height, null);

		AffineTransform at = AffineTransform.getTranslateInstance(x, y);
		at.rotate(degree * Math.PI / 180, width / 2, height / 2);
		Graphics2D g2d = (Graphics2D) g;
		if (fireImage == null) {
			getImage();
		}
		g2d.drawImage(fireImage, at, null);

	}

	@Override
	public void update() {
		for (Player player : MyAdminister.getInstance().getPlayers()) {
			if (player.getInformationOfPlayer().getBombsOfPlayer().isBlasting()) {
				isDestroy = true;
			}
			// if(new Rectangle((int)x,(int) y, width,
			// height).intersects(player.getSpaceShip().getRectangle())
			if (Math.sqrt(Math.pow(x - player.getSpaceShip().getLocation().getX(), 2)
					+ Math.pow(y - player.getSpaceShip().getLocation().getY(), 2)) <= 250 ) {
				if (IntersectsRotateRectangle.intersects(new Rectangle((int) x, (int) y, width, height), degree,
						player.getSpaceShip().getRectangle(), 0) && !player.getSpaceShip().isDestroy()
						&& !player.getSpaceShip().isHavingShield()) {
					isDestroy = true;
					player.getSpaceShip().setDestroy();
				}
			}
		}
		if (y + height <= 0 || y >= MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			isDestroy = true;
		}
		if (x + width <= 0 || x >= MyAdminister.getInstance().getSizeOfFrame().getWidth()) {
			isDestroy = true;

		}
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void move() {
		y += Math.sin(degree * Math.PI / 180) * velocty;
		x += Math.cos(-degree * Math.PI / 180) * velocty;

	}

}
