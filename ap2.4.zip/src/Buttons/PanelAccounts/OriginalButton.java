package Buttons.PanelAccounts;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import javax.swing.JButton;

import InterfaceAble.Paintable;

public abstract class OriginalButton implements MouseMotionListener, MouseListener, Paintable {

	private boolean isInside;
	private BufferedImage imageIn;
	private BufferedImage imageOut;
	private int x;
	private int y;
	private int width;
	private int heigth;
	public Shape rectangle;

	public OriginalButton(BufferedImage imageIn, BufferedImage imageOut, int x, int y, int width,
			int heigth) {
		this.imageIn = imageIn;
		this.imageOut = imageOut;
		this.x = x;
		this.y = y;
		this.width = width;
		this.heigth = heigth;
		rectangle = new Rectangle(x, y, width, heigth);

	}

	@Override
	public void mouseDragged(MouseEvent e) {

		isInside = rectangle.contains(new Point(e.getX(), e.getY()));
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		isInside = rectangle.contains(new Point(e.getX(), e.getY()));

	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	private BufferedImage getImage() {
		if (isInside) {

			return imageIn;
		} else {
			return imageOut;
		}

	}

	@Override
	public void paint(Graphics2D g) {
		g.drawImage(getImage(), x, y, width, heigth, null);

	}

}
