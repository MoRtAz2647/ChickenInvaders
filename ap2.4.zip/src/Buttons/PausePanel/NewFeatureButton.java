package Buttons.PausePanel;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.net.URLClassLoader;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.google.gson.Gson;

import ActionEnum.PlayerTask;
import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import ExternalFeatures.CornerBoss;
import InterfaceAble.BroadcastOfPlayerTask;
import ListOfAddress.MyObjectCollection;

public class NewFeatureButton extends OriginalButton {

	PrintStream printer;
	PopUpNewFeature popUpNewFeature;

	public NewFeatureButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("NewFeatureInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("NewFeatureOutClick"),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() - 300 - 50),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - 100 - 50), 300, 100);

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			popUpNewFeature = new PopUpNewFeature(printer);



		}
	}

	public void setPrinter(PrintStream printer) {
		this.printer = printer;
	}

}

class PopUpNewFeature extends JFrame implements BroadcastOfPlayerTask{

	private JTextField fullName;
	private JButton okButton;

	
	PrintStream printer;

	public PopUpNewFeature(PrintStream printer)  {
		this.printer = printer;
		
		Initialize();
	}

	public String getFullName() {
		return fullName.getText();
	}


	private void Initialize() {
		setSize(350, 150);
		setLocationRelativeTo(null);
		addAll();
	}

	public void addAll() {
		orderTextField();
		addTextField();
		setVisible(true);
	}

	private void addTextField() {

		add(fullName, BorderLayout.CENTER);
		add(okButton, BorderLayout.SOUTH);
	}

	private void orderTextField() {
		fullName = new JTextField("Full Name");
		okButton = new JButton("OK");

		okButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!fullName.getText().equals("")) {
					setVisible(false);
					sendNewFeatureToServer();
				}
			}
		});

		fullName.setPreferredSize(new Dimension(100, 25));

	}
	public void sendNewFeatureToServer() {
		
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("java (.class)", "class"));
		fileChooser.setAcceptAllFileFilterUsed(false);
		fileChooser.showOpenDialog(null);
		
		synchronized (printer) {
			try {
				send(PlayerTask.NewFeature, printer);
				
				
				ClassLoader classLoader = new URLClassLoader(
						new URL[]{fileChooser.getSelectedFile().toURI().toURL()}) ;
				Class classTypeNewFeature = classLoader.loadClass(getFullName());
				
				
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
				objectOutputStream.writeObject(classTypeNewFeature);
				objectOutputStream.flush();
				
				byte[] data = byteArrayOutputStream.toByteArray();
				
				printer.println(new Gson().toJson(data));
				
				
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		
	}
	
}
