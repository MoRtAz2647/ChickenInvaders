package ActionEnum;

public enum DirectionEnum {
	MoveUp, MoveLeft, MoveRight, MoveDown;

	private boolean ifGo;

	public void setGoing(boolean ifGo) {
		this.ifGo = ifGo;
	}

	public boolean getGoing() {
		return ifGo;
	}
}
