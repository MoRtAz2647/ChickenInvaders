package ActionEnum;

public enum PlayerTask {

	ShootBomb, ShootBullet, ChangeDirectionWithMouse, ChangeDirectionWithKeyword, PauseGame, Paint, RequestToPlay,
	StartGameNow, Cheating, WaitingPanel, GamePanel, Continue, Quit , NewFeature , WhichPanelPaint;
	private double x = 0;
	private double y = 0;
	private DirectionEnum direction = DirectionEnum.MoveUp;
	private CheatEnum cheat = CheatEnum.Life;
	private boolean isShootingBullet = false;

	public void setIsShootingBullet(boolean isShooting) {
		this.isShootingBullet = isShooting;
	}

	public boolean getIsShootingBullet() {
		return isShootingBullet;
	}

	public void setLocation(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {

		return x;
	}

	public double getY() {
		return y;
	}

	public void setDirection(DirectionEnum direction) {
		this.direction = direction;
	}

	public DirectionEnum getDirection() {
		return direction;
	}

	public CheatEnum getCheat() {
		return cheat;
	}

	public void setCheat(CheatEnum cheat) {
		this.cheat = cheat;
	}

}
