package Features;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;

import com.sun.tools.javac.code.Attribute.Array;

import BulletPackage.Bullet;
import BulletPackage.LinearBullet;
import BulletPackage.OriginalBullet;
import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import Tool.IntersectsRotateRectangle;

public class Coin implements Paintable, Movable, Updatable, Destroyable  , Serializable{

	private transient ArrayList<BufferedImage> coinsImage = new ArrayList<>();
	private int whichPictureSelected;
	private long lastChangePicture;

	private double x;
	private double y;
	private int width;
	private int height;

	private double veloctyY;

	private boolean isDestroy;

	public Coin(double x, double y) {
		this.x = x;
		this.y = y;

		initialize();
	}

	private void initialize() {
		veloctyY = 0.25;
		width = 25;
		height = 25;
		isDestroy = false;
		whichPictureSelected = 0;
		lastChangePicture = System.currentTimeMillis();

		getImages();
	}

	private void getImages() {
		coinsImage = new ArrayList<>();
		for (int i = 1; i <= 17; i++) {
			coinsImage.add((BufferedImage) MyObjectCollection.getInstance().getImage("Coin" + i));
		}
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void update() {
		if (!isDestroy) {
			for (Player player : MyAdminister.getInstance().getPlayers()) {
				for (Bullet bullet : player.getBullets()) {

					if (bullet.isIntersect(new Rectangle((int) x, (int) y, width, height), 0)) {
						isDestroy = true;
						bullet.setDestroy();

					}
				}
				if (!isDestroy && new Rectangle((int) x, (int) y, width, height)
						.intersects(player.getSpaceShip().getRectangle()) && !player.getSpaceShip().isDestroy()) {
					isDestroy = true;
					player.increaseCoinPlayerStored();
				}

			}
		}

		if (y >= MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			isDestroy = true;

		}

		if (System.currentTimeMillis() - lastChangePicture >= 300) {
			lastChangePicture = System.currentTimeMillis();
			whichPictureSelected++;
			if (whichPictureSelected >= 17) {
				whichPictureSelected %= 17;
			}
		}
	}

	@Override
	public void move() {
		y += veloctyY;
	}

	@Override
	public void paint(Graphics2D g) {
		g.drawImage(getImage(), (int) x, (int) y, width, height, null);
	}

	private Image getImage() {
		if (coinsImage == null) {
			getImages();
		}

		return coinsImage.get(whichPictureSelected);
	}

}
