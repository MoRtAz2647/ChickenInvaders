package GroupChicken;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;

import ChickenPackage.Chicken;
import ChickenPackage.ChickenLinear;
import ChickenPackage.ChickenPolar;
import Controllers.MyAdminister;
import GamePackage.Player;

public class RotationChickens extends OriginalGroupChicken {

	private double degreeOfFirst = 0;
	private long lastChange = 0;
	private long whenCreateGroup;
	private boolean showGreenRegion = true;

	public RotationChickens(int levelPlayerPlay) {
		whenCreateGroup = System.currentTimeMillis();

		for (int i = 0; i < 30; i++) {
			getChickens().add(new ChickenPolar(levelPlayerPlay, -100, -100));
		}
		for (Player player : MyAdminister.getInstance().getPlayers()) {
			player.getSpaceShip().setShieldForSpaceShip(true); 
		} 
	}

	@Override
	public void update() {
		super.update();

		if (System.currentTimeMillis() - whenCreateGroup >= 5000 && showGreenRegion) {
			for (Player player : MyAdminister.getInstance().getPlayers()) {
				player.getSpaceShip().setShieldForSpaceShip(false); 
			} 
			showGreenRegion = false;

		}

		if (System.currentTimeMillis() - lastChange >= 60) {
			degreeOfFirst += 4;
			lastChange = System.currentTimeMillis();
		}
		for (Chicken chicken : getChickens()) {
			int i= getChickens().indexOf(chicken);
			chicken.setVelocty(1.8);

			if (i < 10) {
//				getChickens().get(i).setWhereMustBe(
//						(200 * Math.cos((degreeOfFirst + i * 360 / (10)) * Math.PI / 180)
//								+ MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 25),
//						(200 * Math.sin((degreeOfFirst + i * 360 / (10)) * Math.PI / 180)
//								+ MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 - 50));

				((ChickenPolar) (chicken)).setLocationPolarMustBe(200, (degreeOfFirst + i * 360 / 10));

			} else {
//				getChickens().get(i).setWhereMustBe(
//						(300 * Math.cos((degreeOfFirst + i * 360 / (getChickens().size() - 10)) * Math.PI / 180)
//								+ MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 25),
//						(300 * Math.sin((degreeOfFirst + i * 360 / (getChickens().size() - 10)) * Math.PI / 180)
//								+ MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 - 50));
//				getChickens().get(i).setVelocty(1.8);
//
				((ChickenPolar) (chicken)).setLocationPolarMustBe(300,
						(degreeOfFirst + i * 360 / (getChickens().size() - 10)));
			}
		}

	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);

		if (System.currentTimeMillis() - whenCreateGroup <= 5000) {
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
			g.setColor(Color.GREEN);
			g.fillOval((int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2) - 150,
					(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight()) / 2 - 150, 300, 300);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		}
	}
}
