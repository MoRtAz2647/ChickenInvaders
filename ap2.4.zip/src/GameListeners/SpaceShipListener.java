package GameListeners;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.PrintStream;
import java.util.Scanner;

import com.google.gson.Gson;

import ActionEnum.DirectionEnum;
import ActionEnum.PlayerTask;
import Controllers.MyAdminister;
import InterfaceAble.BroadcastOfPlayerTask;
import InterfaceAble.CheckIfInGame;

public class SpaceShipListener
		implements MouseListener, MouseMotionListener, KeyListener, BroadcastOfPlayerTask, CheckIfInGame {

	private PrintStream printer;
	private boolean isSpectater;
	private Scanner reader;

	public SpaceShipListener(PrintStream printer, Scanner reader, boolean isSpectater) {
		this.printer = printer;
		this.reader = reader;
		this.isSpectater = isSpectater;

	}

	public void setIsSpectater(boolean isSpectater) {
		this.isSpectater = isSpectater;
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToMoveSpaceShipWithMouse(arg0);
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToMoveSpaceShipWithMouse(arg0);
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToMoveSpaceShipWithKeyboard(e, true);

	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToMoveSpaceShipWithKeyboard(e, false);
	}

	private void checkTryingToMoveSpaceShipWithKeyboard(KeyEvent e, boolean b) {
		if (!MyAdminister.getInstance().isPlayingWithMouse()) {
			PlayerTask playerTask = PlayerTask.ChangeDirectionWithKeyword;
			DirectionEnum direction;
			switch (e.getKeyCode()) {
			case (KeyEvent.VK_A):
				direction = DirectionEnum.MoveLeft;
				direction.setGoing(b);
				playerTask.setDirection(direction);
				break;
			case (KeyEvent.VK_W):
				direction = DirectionEnum.MoveUp;
				direction.setGoing(b);
				playerTask.setDirection(direction);
				break;
			case (KeyEvent.VK_S):
				direction = DirectionEnum.MoveDown;
				direction.setGoing(b);
				playerTask.setDirection(direction);
				break;

			case (KeyEvent.VK_D):
				direction = DirectionEnum.MoveRight;
				direction.setGoing(b);
				playerTask.setDirection(direction);
				break;

			}
			send(playerTask, printer);

//			System.out.println("in Listener" + playerTask.getX() + "     " + playerTask.getY());
		}

	}

	private void checkTryingToMoveSpaceShipWithMouse(MouseEvent e) {
		if (MyAdminister.getInstance().isPlayingWithMouse()) {
			PlayerTask playerTask = PlayerTask.ChangeDirectionWithMouse;
			playerTask.setLocation(e.getX(), e.getY());

			send(playerTask, printer);
		}
	}

}
