package Features;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;

import BulletPackage.LinearBullet;
import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import Tool.IntersectsRotateRectangle;

public class PowerUpsOfLevel implements Paintable, Destroyable, Movable, Updatable , Serializable {

	private transient ArrayList<BufferedImage> levelsImage = new ArrayList<>();
	private int whichPictureSelected;
	private long lastChangePicture;

	private double x;
	private double y;
	private int width;
	private int height;

	private double veloctyY;

	private boolean isDestroy;

	public PowerUpsOfLevel(double x, double y) {
		this.x = x;
		this.y = y;

		initialize();
	}

	private void initialize() {
		veloctyY = 0.25;
		width = 25;
		height = 25;
		isDestroy = false;
		whichPictureSelected = 0;
		lastChangePicture = System.currentTimeMillis();

		getImages();
	}

	private void getImages() {
		levelsImage = new ArrayList<>();
		for (int i = 1; i <= 25; i++) {
			levelsImage.add((BufferedImage) MyObjectCollection.getInstance().getImage("PowerUpLevel" + i));
		}
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void update() {
		if (!isDestroy) {
			for (Player player : MyAdminister.getInstance().getPlayers()) {
				if (!isDestroy && new Rectangle((int) x, (int) y, width, height)
						.intersects(player.getSpaceShip().getRectangle()) && !player.getSpaceShip().isDestroy()) {

					player.getInformationOfPlayer().getPowerOfBullet().increaseLevel();
					isDestroy = true;
				}

			}
		}

		if (y >= MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			isDestroy = true;
		}

		if (System.currentTimeMillis() - lastChangePicture >= 300) {
			lastChangePicture = System.currentTimeMillis();
			whichPictureSelected++;
			if (whichPictureSelected >= 25) {
				whichPictureSelected %= 25;
			}
		}

	}

	@Override
	public void move() {
		y += veloctyY;
	}

	@Override
	public void paint(Graphics2D g) {
		g.drawImage(getImage(), (int) x, (int) y, width, height, null);
	}

	private Image getImage() {
		if (levelsImage == null) {
			getImages();
		}

		return levelsImage.get(whichPictureSelected);
	}
}
