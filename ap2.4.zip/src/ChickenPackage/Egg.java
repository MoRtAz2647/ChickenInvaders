package ChickenPackage;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.Serializable;

import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class Egg implements Updatable, Paintable, Movable, Destroyable  , Serializable{

	private double x;
	private double y;
	private  int width = 20;
	private  int height = 20;

	private double velocty;

	private boolean isDestroy = false;

	private transient BufferedImage eggImage;

	public Egg(Point point, int level) {
		getImage();
		velocty = 1 * level;
		x = point.getX() - width / 2;
		y = point.getY() - height / 2;
	}

	private void getImage() {
		eggImage = (BufferedImage) MyObjectCollection.getInstance().getImage("Egg");
		
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void move() {
		y += velocty;
	}

	@Override
	public void paint(Graphics2D g) {
		if(eggImage == null) {
			getImage();
		}
		g.drawImage(eggImage, (int) x, (int) y, width, height, null);
//		g.drawImage((BufferedImage) MyObjectCollection.getInstance().getImage("Egg"), (int) x, (int) y, width, height,
//				null);
	}

	@Override
	public void update() {
		if (!isDestroy) {
			for (Player player : MyAdminister.getInstance().getPlayers()) {
				if (player.getInformationOfPlayer().getBombsOfPlayer().isBlasting()) {
					isDestroy = true;
				}

				if (new Rectangle((int) x, (int) y, width, height).intersects(player.getSpaceShip().getRectangle())
						&& !player.getSpaceShip().isHavingShield() && !player.getSpaceShip().isDestroy()) {
					isDestroy = true;
					player.getSpaceShip().setDestroy();

				}
			}
		}
		if (y >= MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			isDestroy = true;
		}
	}

}
