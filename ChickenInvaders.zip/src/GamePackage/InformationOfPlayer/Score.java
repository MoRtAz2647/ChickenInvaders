package GamePackage.InformationOfPlayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.Serializable;

import Controllers.MyAdminister;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class Score implements Paintable, Updatable, Serializable {

	private long scoreOfGame;
	private long howMuchMustIncrease = 0;

	public Score() {
		scoreOfGame = 0;
	}

	@Override
	public void paint(Graphics2D g) {
	}

	@Override
	public void update() {
		
		if (howMuchMustIncrease > 0) {
			howMuchMustIncrease--;
			scoreOfGame++;
		}
	}

	public void increaseScore(long increaseScore) {
		howMuchMustIncrease += increaseScore;
	}
	public long getScoreOfGame() {
		return scoreOfGame;
	}

}
