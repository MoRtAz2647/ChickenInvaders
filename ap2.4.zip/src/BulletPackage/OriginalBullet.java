package BulletPackage;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.Serializable;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import InterfaceAble.Destroyable;
import InterfaceAble.Intersectable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class OriginalBullet implements Movable, Paintable, Destroyable, Serializable, Updatable, Intersectable {

	private boolean isDestroy;

	private double power;
	private int type;

	public OriginalBullet(double power, int type) {
		this.power = power;
		this.type = type;
		initialize();
	}

	private void initialize() {
		isDestroy = false;

	}

	@Override
	public void update() {

	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void paint(Graphics2D g) {

	}

	@Override
	public void move() {
	}

	public double getPower() {
		return power;
	}

	public int getType() {
		return type;
	}

	public static void playSoundOfFire() {

		try {
			Clip Fire = (Clip) AudioSystem.getClip();
			Fire.open(MyObjectCollection.getInstance().getSound("FireSound"));
			Fire.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public boolean isIntersect(Rectangle rectangle, double degree) {
		return false;
	}

	public static double getVelocty(int type) {
		switch (type) {
		case 1:
			return -2;
		case 2:
			return -4;
		case 3:
			return -8;
		default:
			return -4;
		}

	}

	public static Dimension getDimension(int type) {
		switch (type) {
		case 1:

			return new Dimension(20, 60);
		case 2:

			return new Dimension(10, 30);
		case 3:

			return new Dimension(10, 60);
		default:
			return new Dimension(10, 30);
		}
	}

	public static double getPower(int type, double power) {
		switch (type) {
		case 1:
			return power * 2;

		case 2:
			return power;

		case 3:
			return power / 2;

		case 4:
			return power / 25;
		default:
			return power;
		}
	}

	public static double getVeloctyOfHeatIncreasing(int type, double veloctyDecreasing) {
		switch (type) {
		case 1:
			return veloctyDecreasing * 2;

		case 2:
			return veloctyDecreasing;

		case 3:
			return veloctyDecreasing / 2;
			
		case 4:
			return veloctyDecreasing / 10;
		default:
			return veloctyDecreasing;
		}
	}

	public static double getDistanceBetween2Shots(int type) {
		switch (type) {
		case 1:
			return 450;

		case 2:
			return 300;

		case 3:
			return 150;
		case 4:
			return 30;
		default:
			return 300;
		}
	}

	
}
