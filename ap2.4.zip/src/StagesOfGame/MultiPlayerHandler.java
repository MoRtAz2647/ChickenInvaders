package StagesOfGame;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import ActionEnum.FeatureEnum;
import ActionEnum.PlayerTask;
import BossPackage.Boss;
import BossPackage.LinearBoss;
import Controllers.MyAdminister;
import Features.Features;
import GamePackage.Player;
import GroupChicken.CircleChickens;
import GroupChicken.GroupChicken;
import GroupChicken.OriginalGroupChicken;
import GroupChicken.RectangleChickens;
import GroupChicken.RotationChickens;
import GroupChicken.SuicideChickens;
import InterfaceAble.Finishable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import PlayersData.PropertiesOfPlayer;

public class MultiPlayerHandler implements Updatable, Paintable, Finishable, Serializable {

	private Features features;

	private CopyOnWriteArrayList<GroupChicken> enemyGroup = new CopyOnWriteArrayList<>();
	private CopyOnWriteArrayList<Boss> bosses = new CopyOnWriteArrayList<>();

	private boolean isFinish = false;
	private long whenFinish = 0;
	private int wavesPlay = 0;
	private long whenStart = 0;

	private int levelPlayersPlay = 1;
	private int wavePlayerPlay = 1;
	private transient int leveles = 4;
	private transient int waves = 4;

	private boolean isWaveCompleted = false;
	private boolean isWaveContinueing = false;
	private boolean isWaveStarted;
	private long whenWaveStarted;

	private double alphaWave = 0.1;
	private long lastchangeAlphaWave = 0;
	private boolean mustIncreaseAlphaWave = true;

	private boolean isLevelCompleted = false;
	private boolean isLevelContinueing = false;
	private boolean isLevelStarted;
	private long whenLevelStarted;

	private double alphaLevel = 0.1;
	private long lastChangeAlphaLevel = 0;
	private boolean mustIncreaseAlphaLevel = true;

	private boolean isBossLevelStarted = false;
	private boolean isBossLevelContinueing = false;
	private boolean isBossLevelCompleted = false;
	private long lastchangeAlphaGameOver = 0;
	private boolean mustIncreaseAlphaGameOver = true;
	private double alphaGameOver = 0.1;

	public MultiPlayerHandler(int levels, int waves) {
		this.leveles = levels;
		this.waves = waves;
		initialized();
	}

	private void initialized() {

		isLevelStarted = true;
		isWaveStarted = true;
		whenLevelStarted = System.currentTimeMillis();
		whenWaveStarted = System.currentTimeMillis();
		whenStart = System.currentTimeMillis();

		features = new Features();
	}

	@Override
	public void paint(Graphics2D g) {

		if (isFinish) {
			showStringGameOver(g);
		} else {
			ifShowStringOfStartWaveAndLevel(g);
			ifWaveAndLevelContinueingPaint(g);

		}
	}

	private void showStringGameOver(Graphics2D g) {
		AlphaComposite alphaComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) alphaWave);
		g.setComposite(alphaComposite);

		g.setColor(Color.WHITE);
		g.setFont(new Font("Tahoma", 1, 70));
		g.drawString("Game Over", (int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 35 * 9 / 2),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2));
		alphaComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1);
		g.setComposite(alphaComposite);

	}

	private void changeAlphaGameOver() {
		if (System.currentTimeMillis() - lastchangeAlphaGameOver >= 25) {
			if (mustIncreaseAlphaGameOver) {
				alphaGameOver += 0.01;
				if (alphaGameOver > 0.99) {
					mustIncreaseAlphaGameOver = false;
				}
			} else {
				alphaGameOver -= 0.01;
				if (alphaGameOver < 0.01) {
					mustIncreaseAlphaGameOver = true;
				}
			}
		}
	}

	private void ifWaveAndLevelContinueingPaint(Graphics2D g) {

		ifWaveContinueing(g);
		ifBossLevelContinueing(g);
		features.paint(g);
	}

	private void ifBossLevelContinueing(Graphics2D g) {
		if (isBossLevelContinueing) {
			for (Boss boss : bosses) {
//				new Thread(() -> {
					boss.paint(g);

//				}).start();
			}
		}
	}

	private void ifWaveContinueing(Graphics2D g) {
		if (isWaveContinueing) {
			for (GroupChicken enemy : enemyGroup) {
//				new Thread(() -> {
					enemy.paint(g);

//				}).start();

			}
		}
	}

	private void ifShowStringOfStartWaveAndLevel(Graphics2D g) {
		ifShowLevelString(g);
		ifShowWaveString(g);
	}

	private void ifShowWaveString(Graphics2D g) {
		if (isWaveStarted) {
			AlphaComposite alphaComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) alphaWave);
			g.setComposite(alphaComposite);

			g.setColor(Color.WHITE);
			g.setFont(new Font("Tahoma", 1, 60));
			g.drawString("Wave " + wavePlayerPlay,
					(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 30 * 6 / 2),
					(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 + 50));
			alphaComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1);
			g.setComposite(alphaComposite);

		}
	}

	private void changeAlphaWave() {
		if (System.currentTimeMillis() - lastchangeAlphaWave >= 25) {
			if (mustIncreaseAlphaWave) {
				alphaWave += 0.01;
				if (alphaWave > 0.99) {
					mustIncreaseAlphaWave = false;
				}
			} else {
				alphaWave -= 0.01;
				if (alphaWave < 0.01) {
					mustIncreaseAlphaWave = true;
				}
			}
		}
	}

	private void ifShowLevelString(Graphics2D g) {
		if (isLevelStarted) {
			AlphaComposite alphaComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) alphaLevel);
			g.setComposite(alphaComposite);

			g.setColor(Color.WHITE);
			g.setFont(new Font("Tahoma", 1, 60));
			g.drawString("LEVEL " + levelPlayersPlay,
					(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 30 * 7 / 2),
					(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 - 50));
			alphaComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1);
			g.setComposite(alphaComposite);

		} else {
			alphaLevel = 0;
			mustIncreaseAlphaLevel = true;
		}
	}

	private void changeAlphaLevel() {
		if (System.currentTimeMillis() - lastChangeAlphaLevel >= 25) {
			if (mustIncreaseAlphaLevel) {
				alphaLevel += 0.005;
				if (alphaLevel > 0.99) {
					mustIncreaseAlphaLevel = false;
				}
			} else {
				alphaLevel -= 0.005;
				if (alphaLevel < 0.01) {
					mustIncreaseAlphaLevel = true;
				}
			}
		}
	}

	@Override
	public void update() {
		if (isFinish) {
			changeAlphaGameOver();

			if (System.currentTimeMillis() - whenFinish >= 5000) {
				gameOver();
			}
		} else {
			changeAlphaWave();
			changeAlphaLevel();

			ifLevelAndWaveAndBossStarted();
			ifLevelAndWaveAndBossContinueing();
			ifLevelAndWaveAndBossCompleted();
			features.update();
			ifMustFinishTheGame();
		}

	}

	private void ifMustFinishTheGame() {
		if (ifPlayersDie()) {
			isFinish = true;
			whenFinish = System.currentTimeMillis();
			isLevelContinueing = false;
		}

	}

	private boolean ifPlayersDie() {
		boolean isAllPlayersDie = false;
		for (Player player : MyAdminister.getInstance().getPlayers()) {
			isAllPlayersDie = isAllPlayersDie
					|| player.getInformationOfPlayer().getLifeOfPlayer().isPossibleToContinue();
		}
		return !isAllPlayersDie;
	}

	private void ifLevelAndWaveAndBossCompleted() {
		ifWaveCompleted();
		ifLevelCompleted();
		ifBossLevelCompleted();
	}

	private void ifLevelCompleted() {
		if (isLevelCompleted) {
			if (levelPlayersPlay < leveles) {
				levelPlayersPlay++;
				wavePlayerPlay = 1;
				isLevelCompleted = false;
				isLevelStarted = true;
				isWaveStarted = true;
				whenLevelStarted = System.currentTimeMillis();
				whenWaveStarted = whenLevelStarted;
			} else {
				isFinish = true;
				isLevelContinueing = false;
				whenFinish = System.currentTimeMillis();
			}
		}
	}

	private void gameOver() {
		isLevelContinueing = false;

		MyAdminister.getInstance().changeAllUserForSituationOfGame(PlayerTask.Quit);

	}

	private void ifBossLevelCompleted() {
		if (isBossLevelCompleted) {
			isBossLevelCompleted = false;
			isLevelCompleted = true;
			isLevelContinueing = false;
		}
	}

	private void ifWaveCompleted() {
		if (isWaveCompleted) {
			wavesPlay++;
			for (Player player : MyAdminister.getInstance().getPlayers()) {
				player.calculateCoinScore();
			}
			isWaveCompleted = false;
			if (wavePlayerPlay < waves) {
				isWaveStarted = true;
				whenWaveStarted = System.currentTimeMillis();
				wavePlayerPlay++;

			} else if (wavePlayerPlay == waves) {
				isBossLevelStarted = true;
			}
		}
	}

	private void ifLevelAndWaveAndBossContinueing() {
		ifWaveContinueing();
		isBossLevelContinueing();
	}

	private void isBossLevelContinueing() {
		if (isBossLevelContinueing) {
			for (Boss boss : bosses) {
				if (boss.isDestroy()) {
					bosses.remove(boss);
					features.BossDestroyed(boss.getLocation().getX() + boss.getDimension().getWidth() / 2,
							boss.getLocation().getY() + boss.getDimension().getHeight() / 2);
				}
				new Thread(() -> {
					boss.update();

				}).start();
			}
			if (bosses.size() == 0) {
				isBossLevelCompleted = true;
				isBossLevelContinueing = false;

			}
		}
	}

	private void ifWaveContinueing() {
		if (isWaveContinueing) {
			for (GroupChicken enemy : enemyGroup) {
				features.getPointsThrowGift(enemy.getWherePosibleThrowGift());
				if (enemy.isDestroy()) {
					enemyGroup.remove(enemy);
				}
				new Thread(() -> {
					enemy.update();

				}).start();
			}
			if (enemyGroup.size() == 0) {
				isWaveContinueing = false;
				isWaveCompleted = true;
			}
		}
	}

	private void ifLevelAndWaveAndBossStarted() {
		ifStartedWave();
		ifStartedLevel();
		ifStartedBoss();
	}

	private void ifStartedBoss() {
		if (isBossLevelStarted) {
//			boss = new Boss(new LinearBoss(levelPlayersPlay), LinearBoss.class);

			int level = levelPlayersPlay;
			while (level > 0) {
				int levelBoss;
				if (level > 4) {
					levelBoss = 4;
				} else {
					levelBoss = level;
				}
				level -= levelBoss;

				Class BossFeature = MyAdminister.getInstance().getRandomFeature(FeatureEnum.Boss);

				try {

					bosses.add(new Boss(BossFeature.getDeclaredConstructors()[0].newInstance(levelPlayersPlay),
							BossFeature));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			isBossLevelStarted = false;
			isBossLevelContinueing = true;
		}
	}

	private void ifStartedLevel() {
		if (isLevelStarted && System.currentTimeMillis() - whenLevelStarted >= 4500) {
			isLevelStarted = false;
			isLevelContinueing = true;

		}
	}

	private void ifStartedWave() {
		if (isWaveStarted) {
			MyAdminister.getInstance().getGalaxyWorld().changeWaitingPlayerToPlayer();
		}
		if (isWaveStarted && System.currentTimeMillis() - whenWaveStarted >= 4500) {
			isWaveStarted = false;
			isWaveContinueing = true;
			createEnemy();

		}
	}

	private void createEnemy() {

		int level = levelPlayersPlay;
		while (level > 0) {
			int levelGroup;
			if (level > 4) {
				levelGroup = 4;
			} else {
				levelGroup = level;
			}
			level -= levelGroup;

			Class groupChickenFeature = MyAdminister.getInstance().getRandomFeature(FeatureEnum.GroupChicken);
			try {
				enemyGroup.add(
						new GroupChicken(groupChickenFeature.getDeclaredConstructors()[0].newInstance(levelPlayersPlay),
								groupChickenFeature));
			} catch (Exception e) {
				e.printStackTrace();
			}

//			switch (whichGroup) {
//			case 0:
//				enemyGroup.add(new GroupChicken(new RectangleChickens(levelGroup), RectangleChickens.class));
//
//				break;
//			case 1:
//				enemyGroup.add(new GroupChicken(new CircleChickens(levelGroup), CircleChickens.class));
//
//				break;
//			case 2:
//				enemyGroup.add(new GroupChicken(new SuicideChickens(levelGroup), SuicideChickens.class));
//
//				break;
//			default:
//				break;
//			}
		}
	}

	@Override
	public boolean isFinish() {
		return isFinish;
	}

	public CopyOnWriteArrayList<GroupChicken> getEnemy() {
		return enemyGroup;
	}

	public CopyOnWriteArrayList<Boss> getBosses() {
		return bosses;
	}

}
