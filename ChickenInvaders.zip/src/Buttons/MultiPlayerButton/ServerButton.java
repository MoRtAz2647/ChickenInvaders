package Buttons.MultiPlayerButton;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ActionEnum.PlayerTask;
import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.Selectable;
import ListOfAddress.MyObjectCollection;

public class ServerButton extends OriginalButton implements Selectable {

	private boolean isSelected;
	private ServerHandler serverHandler;

	public ServerButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("ServerInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("ServerOutClick"), 50 + 400 + 50,
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 4 - 25 * 3 + 100 / 2 + 5,
				400, 100);

		isSelected = false;
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().setSelectedOfServerAndClient(false);
			isSelected = !isSelected;
			serverHandler = new ServerHandler();
		}

	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);

		if (isSelected) {
			StartButton.getInstance(true).paint(g);
			if (StartButton.getInstance(true).isClicked()) {
				StartButton.getInstance(true).setIsClicked(false);
				MyAdminister.getInstance().createGalaxyWorld(false, true, serverHandler.getMaxPlayer(),
						serverHandler.getLevels(), serverHandler.getWaves());

				if (MyAdminister.getInstance().runServerConnecter(serverHandler.getPort())) {

					MyAdminister.getInstance().createClientPlayer("127.0.0.1", serverHandler.getPort(),
							serverHandler.isSpectater());
					
					MyAdminister.getInstance().changeAllUserForSituationOfGame(PlayerTask.WaitingPanel);
					
					MyAdminister.getInstance().runGameEngine();
				}
			}
		}

	}

}

class ServerHandler {
	PopUpServer popUpServer;

	public ServerHandler() {
		popUpServer = new PopUpServer();
		popUpServer.addAll();
	}

	public int getPort() {
		return popUpServer.getPort();
	}

	public int getMaxPlayer() {
		return popUpServer.getMaxPlayer();
	}

	public boolean isSpectater() {
		return popUpServer.isSpectater();
	}

	public int getLevels() {
		return popUpServer.getLevels();
	}

	public int getWaves() {
		return popUpServer.getWaves();
	}
}

class PopUpServer extends JFrame {

	private JTextField portServer;
	private JTextField MaxPlayerServer;
	private JTextField levelsServer;
	private JTextField wavesServer;
	private Checkbox spectaterServer;
	private JButton okButton;

	public PopUpServer() {
		Initialize();
	}

	public boolean isSpectater() {
		return spectaterServer.getState();
	}

	public int getMaxPlayer() {
		return Integer.parseInt(MaxPlayerServer.getText());
	}

	public int getPort() {
		return Integer.parseInt(portServer.getText());
	}

	public int getLevels() {
		return Integer.parseInt(levelsServer.getText());
	}

	public int getWaves() {
		return Integer.parseInt(wavesServer.getText());
	}

	private void Initialize() {
		setSize(350, 150);
		setLocationRelativeTo(null);
	}

	public void addAll() {
		orderTextField();
		addTextField();
		setVisible(true);
	}

	private void addTextField() {
		JPanel jPanel = new JPanel();
		jPanel.add(portServer, BorderLayout.EAST);
		jPanel.add(spectaterServer, BorderLayout.WEST);
//		add(portServer ,  BorderLayout.NORTH);
//		add(spectaterServer ,  BorderLayout.NORTH);
		add(jPanel, BorderLayout.NORTH);

		add(levelsServer, BorderLayout.EAST);
		add(wavesServer, BorderLayout.WEST);
		add(MaxPlayerServer, BorderLayout.CENTER);
		add(okButton, BorderLayout.SOUTH);
	}

	private void orderTextField() {
		portServer = new JTextField("Port");
		MaxPlayerServer = new JTextField("Max Player");
		levelsServer = new JTextField("Levels");
		wavesServer = new JTextField("Waves");
		spectaterServer = new Checkbox("Spectater", false);
		okButton = new JButton("OK");

		okButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				PopUpServer.this.setEnabled(false);
				PopUpServer.this.setVisible(false);

			}
		});

		portServer.setPreferredSize(new Dimension(100, 25));
		levelsServer.setPreferredSize(new Dimension(100, 25));
		wavesServer.setPreferredSize(new Dimension(100, 25));
		MaxPlayerServer.setPreferredSize(new Dimension(100, 25));
		spectaterServer.setPreferredSize(new Dimension(100, 25));

	}

}
