package ChatServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.CopyOnWriteArrayList;

import Controllers.MyAdminister;
import sun.rmi.runtime.RuntimeUtil;

public class ServerChat extends Thread {

	private ArrayList<UserInfoChat> users = new ArrayList<>();

	private int port;
	private ServerSocket serverSocket;
	
	private Thread infoUsers;
	private CopyOnWriteArrayList<Thread> senderMassageUsers= new CopyOnWriteArrayList<>();
	
	public ServerChat(int port) {
		this.port = port;
		try {
			serverSocket = new ServerSocket(this.port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}

		start();

	}

	@Override
	public void run() {
		infoUsers = new Thread(() -> {
			
				long lastTimeSend = System.currentTimeMillis();
				while (true) {
					
					if (System.currentTimeMillis() - lastTimeSend >= 10000
							&& MyAdminister.getInstance().getGalaxyWorld().getControllerOfPlayer().size() != 0) {
						lastTimeSend = System.currentTimeMillis();
						broadcast("Server", MyAdminister.getInstance().getGalaxyWorld().getInfoOfPlayers());
					}
					
				}
				
		});
		infoUsers.start();

		while (true) {
			try {
				Socket socket = serverSocket.accept();
				UserInfoChat user = new UserInfoChat(socket);
				users.add(user);
				Thread sender = new Thread(() -> {
					try {
						Scanner scanner = new Scanner(socket.getInputStream());
						String name = scanner.nextLine();
						user.setName(name);
						broadcast(user.getName(), "(Connected!)");
						while (true) {
							String message = scanner.nextLine();
							broadcast(user.getName(), message);
							
						}
					} catch (Exception e) {
					}
				});
				sender.start();
				senderMassageUsers.add(sender);
				
			} catch (IOException e) {
			}
		}
	}

	public void StopServerChat() {
		infoUsers.stop();
		for(Thread sender: senderMassageUsers) {
			sender.stop();
		}
		
		stop();
	}

	private void broadcast(String name, String message) {
		for (UserInfoChat c : users) {
			c.send(name + "\n	" + message);
		}
	}
}
