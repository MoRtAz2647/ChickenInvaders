package InterfaceAble;

import java.awt.Rectangle;

public interface Intersectable {

	public boolean isIntersect(Rectangle rectangle, double degree);
}
