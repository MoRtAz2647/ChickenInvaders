package InterfaceAble;

public interface Finishable {
	public boolean isFinish();
}
