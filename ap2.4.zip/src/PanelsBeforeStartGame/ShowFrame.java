package PanelsBeforeStartGame;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import Controllers.MyAdminister;
import InterfaceAble.Drawable;
import ListOfAddress.MyObjectCollection;

public class ShowFrame extends JFrame implements Drawable {


	public ShowFrame() {
		initialize();
	}

	private void initialize() {
		///////////////////////////////////
		// properties of my Frame
		createProperties();
		pack();
		setVisible(true);
		new Thread(() ->  {
			while(true) {
					repaint();
					revalidate();
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).start();
		
	}

	

	private void createProperties() {
		setPreferredSize(new Dimension(1632,918 ));
		setTitle("Chicken Invaders");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setIconImage((Image) MyObjectCollection.getInstance().getImage("iconImage"));
		setResizable(false);
		
		

	}

	

	

	@Override
	public void render(Graphics2D g) {
		

	}

	
}
