package GroupChicken;

import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;

import ChickenPackage.Chicken;
import InterfaceAble.Destroyable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class GroupChicken implements Serializable, Updatable, Paintable, Destroyable {

	Object groupChicken;
	Class reflectionGroupChicken;

	public GroupChicken(Object groupChicken, Class reflectionGroupChicken) {
		this.groupChicken = groupChicken;
		this.reflectionGroupChicken = reflectionGroupChicken;
	}

	@Override
	public boolean isDestroy() {
		try {
			return (boolean) reflectionGroupChicken.getMethod("isDestroy").invoke(groupChicken);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public void setDestroy() {
		try {
			reflectionGroupChicken.getMethod("setDestroy").invoke(groupChicken);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void paint(Graphics2D g) {
		try {
			reflectionGroupChicken.getMethod("paint", Graphics2D.class).invoke(groupChicken, g);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void update() {
		try {
			reflectionGroupChicken.getMethod("update").invoke(groupChicken);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public CopyOnWriteArrayList<Point> getWherePosibleThrowGift() {
		try {
			return (CopyOnWriteArrayList<Point>) reflectionGroupChicken.getMethod("getWherePosibleThrowGift")
					.invoke(groupChicken);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Chicken getNearestChickenToPlayer(int id) {
		try {
			return (Chicken) (reflectionGroupChicken.getMethod("getNearestChickenToPlayer", int.class))
					.invoke(groupChicken, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
