package BossPackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.imageio.ImageIO;

import BulletPackage.Bullet;
import BulletPackage.LinearBullet;
import BulletPackage.OriginalBullet;
import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import Tool.SuperGameEngineThread;

public class Boss implements Updatable, Paintable, Destroyable, Serializable {

	Object boss;
	Class reflectionBoss;

	public Boss(Object boss, Class reflectionBoss) {

		this.boss = boss;
		this.reflectionBoss = reflectionBoss;

	}

	@Override
	public void paint(Graphics2D g) {
		try {
			reflectionBoss.getMethod("paint", Graphics2D.class).invoke(boss, g);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void update() {
		try {
			reflectionBoss.getMethod("update").invoke(boss);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean isDestroy() {

		try {
			return (boolean) reflectionBoss.getMethod("isDestroy").invoke(boss);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public void setDestroy() {
		try {
			reflectionBoss.getMethod("setDestroy").invoke(boss);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Point getLocation() {
		try {
			return (Point) reflectionBoss.getMethod("getLocation").invoke(boss);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public Dimension getDimension() {
		try {
			return (Dimension) reflectionBoss.getMethod("getDimension").invoke(boss);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public Point getMiddle() {
		try {
			return (Point) reflectionBoss.getMethod("getMiddle").invoke(boss);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
