package PanelsBeforeStartGame;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import Controllers.MyAdminister;
import InterfaceAble.Drawable;
import ListOfAddress.MyObjectCollection;

public class WelcomePage extends JPanel{
	BufferedImage ChickenInvaders ;
	AlphaComposite alphaComposite;
	private int widthImage;
	private int heightImage;
	
	private static double alpha= 0.21;
	private static double speed = 0.05;
	private static boolean isContinueing=true;
	
	public WelcomePage() {
		initialize();
	}

	private void initialize() {
		setBackground(Color.BLACK);
		
		
			ChickenInvaders =  (BufferedImage) MyObjectCollection.getInstance().getImage("ChickenTitle");
	
			widthImage = 500;
			heightImage = 500;
			
			MyAdminister.getInstance().playingBackgroundSound();
			
		repaint();
		setVisible(true);
		new Thread(()-> {
			while(true) {
				
				repaint();
				try {
					Thread.sleep(200);
				} catch(Exception e) {
					
				}
			}
		}).start();
		
		
		
	}
	
	{
		
		
	}
	
	 @Override
	protected void paintComponent(Graphics graphics) {
		 super.paintComponent(graphics);
		 Graphics2D graphics2D = (Graphics2D) graphics;
		alphaComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) alpha);
		changeAlpha();
		graphics2D.setComposite(alphaComposite);
		graphics2D.drawImage(ChickenInvaders, 
				(int)((MyAdminister.getInstance().getSizeOfFrame().getWidth()-widthImage)/2)
				,(int)((MyAdminister.getInstance().getSizeOfFrame().getHeight()-heightImage)/2),
				widthImage , heightImage , null);
		
	}

	private void changeAlpha() {
		if(alpha<=0.2) {
			isContinueing=false;
			MyAdminister.getInstance().showAccountPage();
		}
		else {
			alpha+=speed;
			if(alpha>=1) {
				speed*=-1;
				alpha+=speed;
			}
		}
	}
	public boolean isContinue() {
		return isContinueing;
		
	}

	

	
}
