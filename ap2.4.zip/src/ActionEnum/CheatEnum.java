package ActionEnum;

public enum CheatEnum {
	Bomb , Life , Shield , LevelOfBullet , TypeOfBullet;
	
	int typeOfBullet;
	
	public void setTypeOfBullet(int type) {
		typeOfBullet = type;
	}
	
	public int getTypeOfBullet() {
		return typeOfBullet;
	}
}
