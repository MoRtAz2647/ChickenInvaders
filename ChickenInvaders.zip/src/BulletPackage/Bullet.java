package BulletPackage;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.Serializable;

import InterfaceAble.Destroyable;
import InterfaceAble.Intersectable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class Bullet implements Updatable, Paintable, Destroyable, Intersectable , Serializable {

	private  Class reflectionBullet;
	private  Object bullet;

	public Bullet(Object bullet, Class reflectionBullet) {
		this.reflectionBullet = reflectionBullet;
		this.bullet = bullet;
	}

	@Override
	public void paint(Graphics2D g) {
		try {
			reflectionBullet.getMethod("paint", Graphics2D.class).invoke(bullet, g);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update() {
		try {
			reflectionBullet.getMethod("update").invoke(bullet);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean isDestroy() {
		try {
			return (boolean) (reflectionBullet.getMethod("isDestroy").invoke(bullet));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public void setDestroy() {
		try {
			reflectionBullet.getMethod("setDestroy").invoke(bullet);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean isIntersect(Rectangle rectangle, double degree) {
		try {
			return (boolean) reflectionBullet.getMethod("isIntersect", new Class[] { Rectangle.class, double.class })
					.invoke(bullet, new Object[] { rectangle, degree });
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public double getPower() {
		try {
			return (double) reflectionBullet.getMethod("getPower").invoke(bullet);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

}
