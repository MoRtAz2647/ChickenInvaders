package InterfaceAble;

import java.awt.Graphics2D;

public interface Drawable {
	void render(Graphics2D g);

}
