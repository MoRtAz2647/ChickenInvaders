package GamePackage.Tabs;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.Serializable;

import Controllers.MyAdminister;
import GamePackage.Player;
import GamePackage.InformationOfPlayer.Heat;
import GamePackage.InformationOfPlayer.Score;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.PlayerPaint;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class ScoreAndHeatTab implements PlayerPaint, Updatable, Serializable {

	private transient GradientPaint gradientPaintLeftSide;
	private transient GradientPaint gradientPaintRigthSide;
	private int whereChangeToYellow = 375;
	private int whereChangeToRed = 450;

	private int x =  250;
	private int height = 20;

	private transient BufferedImage mainTab;

	private int id;

	public ScoreAndHeatTab(int id) {
		this.id = id;
		initialize();
	}

	private void initialize() {
//		mainTab = (BufferedImage) MyObjectCollection.getInstance().getImage("ScoreAndHeatTab");
	}

	@Override
	public void paint(Graphics2D g, Player player) {
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
//		g.drawImage(mainTab, 0, 0, 500, 80, null);
		g.drawImage((BufferedImage) MyObjectCollection.getInstance().getImage("ScoreAndHeatTab"), 0, 0, 500, 80, null);

		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

		g.drawString(Long.toString(player.getInformationOfPlayer().getScore().getScoreOfGame()), 15,
				(int) (height / 2 + 40));

		for (int i = 0; i < 4; i++) {
			paintRectangle(g, i, player.getInformationOfPlayer().getHeat().getMaxHeat(),
					player.getInformationOfPlayer().getHeat().getDegreeHeat());
		}


	}

	@Override
	public void update() {
	}

	private void paintRectangle(Graphics2D g, int i, double maxHeat, double degreeHeat) {
		gradientPaintLeftSide = new GradientPaint(x, i * height, Color.GREEN, whereChangeToYellow, i * height,
				Color.YELLOW);
		gradientPaintRigthSide = new GradientPaint(whereChangeToYellow + 25, i * height, Color.YELLOW, whereChangeToRed,
				i * height, Color.RED);
		g.setPaint(gradientPaintLeftSide);
		g.drawRect(x, i * height, 150, height);
		g.fillRect(x, i * height, WidthOfGradientYellow(i, maxHeat, degreeHeat), height);
		g.setPaint(gradientPaintRigthSide);
		g.drawRect(400, i * height, 100, height);
		if (degreeHeat > 60 * 100 / maxHeat) {
			g.fillRect(400, i * height, WidthOfGradientRed(i, maxHeat, degreeHeat), height);
		}

	}

	private int WidthOfGradientRed(int i, double degreeHeat, double maxHeat) {
		if (degreeHeat >= maxHeat) {
			return 100;
		}
		return (int) ((degreeHeat * (10 - i) / 4 - 150) * 100 / maxHeat);
	}

	private int WidthOfGradientYellow(int i, double maxHeat, double degreeHeat) {
//		if (degreeHeat >= 60) {
//			return 150;
//		} else {
		if (degreeHeat >= maxHeat) {
			return 150;
		}
		return (int) ((degreeHeat * (10 - i) / 4) * 100 / maxHeat);
//		}
	}

}
