package ChatServer;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

public class UserInfoChat {
    private Socket socket;
    private String name;
    private PrintStream printer;

    public UserInfoChat(Socket socket) {
        this.socket = socket;
        try {
            printer = new PrintStream(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void send(String s) {
    	printer.println(s);
    }

	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}