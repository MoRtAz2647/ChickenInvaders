package Features;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;

import BulletPackage.LinearBullet;
import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import Tool.IntersectsRotateRectangle;
import sun.awt.www.content.image.gif;

public class Gift implements Updatable, Movable, Paintable, Destroyable  , Serializable{

	private transient ArrayList<BufferedImage> giftsImage = new ArrayList<>();
	private int whichPictureSelected;
	private long lastChangePicture;

	private double x;
	private double y;
	private int width;
	private int height;

	private double veloctyY;

	private boolean isDestroy;

	private int type;

	public Gift(double x, double y, int type) {
		this.x = x;
		this.y = y;
		this.type = type;

		initialize();
	}

	private void initialize() {
		veloctyY = 0.25;
		width = 50;
		height = 50;
		isDestroy = false;
		whichPictureSelected = 0;
		lastChangePicture = System.currentTimeMillis();

		getImages();
	}

	private void getImages() {
		giftsImage = new ArrayList<>();
		for (int i = 1; i <= 14; i++) {
			giftsImage.add((BufferedImage) MyObjectCollection.getInstance().getImage("Gift" + type + "" + i));
		}
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void update() {
		if (!isDestroy) {
			for (Player player : MyAdminister.getInstance().getPlayers()) {
				if (!isDestroy && new Rectangle((int) x, (int) y, width, height)
						.intersects(player.getSpaceShip().getRectangle()) && !player.getSpaceShip().isDestroy()) {

					player.getInformationOfPlayer().getPowerOfBullet().setTypeOfBullet(type);
					isDestroy = true;
				}

			}
		}

		if (y >= MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			isDestroy = true;
		}

		if (System.currentTimeMillis() - lastChangePicture >= 300) {
			lastChangePicture = System.currentTimeMillis();
			whichPictureSelected++;
			if (whichPictureSelected >= 14) {
				whichPictureSelected %= 14;
			}
		}
	}

	@Override
	public void move() {
		y += veloctyY;
	}

	@Override
	public void paint(Graphics2D g) {
		g.drawImage(getImage(), (int) x, (int) y, width, height, null);
	}

	private Image getImage() {
		if (giftsImage == null) {
			getImages();
		}

		return giftsImage.get(whichPictureSelected);
	}

}
