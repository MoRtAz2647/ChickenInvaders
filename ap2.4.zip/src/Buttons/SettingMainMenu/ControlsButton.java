package Buttons.SettingMainMenu;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.Paintable;
import InterfaceAble.Selectable;
import ListOfAddress.MyObjectCollection;

public class ControlsButton extends OriginalButton implements Selectable {
	
	private boolean isSelected=false;
	
	public ControlsButton() {
		super((BufferedImage)MyObjectCollection.getInstance().getImage("ControlsInClick"),
				(BufferedImage)MyObjectCollection.getInstance().getImage("ControlsOutClick"), 
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50 ,
				(int)MyAdminister.getInstance().getSizeOfFrame().getHeight()-50 - 100 *6 - 25*5, 400, 100);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if(rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().setSelectedOfSettingButtons(false);
			setSelected(true);
			
		}
		if(isSelected()) {
			ControlsImage.getInstance().checkIfSelectedControls(e);
		}
	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);
		if(isSelected()) {
			ControlsImage.getInstance().paint(g);
		}
	}	
	
	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

}
class ControlsImage implements Paintable {

	private static ControlsImage controlsImage;
	
	private BufferedImage mouseIcon;
	private BufferedImage keyboardIcon;
	
	private int widthMouse;
	private int heightMouse;
	private int mouseX;
	private int mouseY;
	private Rectangle mouseRectangle;
	
	private int widthKeyboard;
	private int heightKeyboard;
	private int keyboardX;
	private int keyboardY;
	private Rectangle keyboardRectangle;
	
	private ControlsImage() {
		initialize();
	}
	

	public void checkIfSelectedControls(MouseEvent e) {
		if(mouseRectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingWithMouse(true);
			MyAdminister.getInstance().setSelectedOfSettingButtons(false);
		}else if(keyboardRectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingWithMouse(false);
			MyAdminister.getInstance().setSelectedOfSettingButtons(false);

		}
	}


	private void initialize() {
		
		mouseIcon = (BufferedImage) MyObjectCollection.getInstance().getImage("MouseIcon");
		keyboardIcon = (BufferedImage) MyObjectCollection.getInstance().getImage("KeyboardIcon");
		
		widthMouse = 100;
		heightMouse = 200;
		widthKeyboard = 500;
		heightKeyboard = 200;
		
		mouseX = (int) ((MyAdminister.getInstance().getSizeOfFrame().getWidth() - widthMouse - 200)/2);
		mouseY = 200;  //(int) ((MyAdminister.getInstance().getSizeOfFrame().getHeight() - heightMouse)/2);
		keyboardX = (int) ((MyAdminister.getInstance().getSizeOfFrame().getWidth()+widthMouse+200)/2);
		keyboardY = 200; //(int) (( MyAdminister.getInstance().getSizeOfFrame().getHeight() - heightKeyboard )/2);
		
		mouseRectangle = new Rectangle(mouseX, mouseY, widthMouse, heightMouse);
		keyboardRectangle = new Rectangle(keyboardX, keyboardY, widthKeyboard, heightKeyboard);
		
	}

	public static ControlsImage getInstance() {
		if(controlsImage == null) {
			controlsImage = new ControlsImage();
		}
		return controlsImage;
	}

	@Override
	public void paint(Graphics2D g) {
		g.drawImage(mouseIcon, mouseX, mouseY, widthMouse, heightMouse, null);
		g.drawImage(keyboardIcon, keyboardX, keyboardY, widthKeyboard, heightKeyboard, null);
	}
	
}
