package GamePackage;

import java.awt.AWTException;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Robot;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import BulletPackage.Bullet;
import BulletPackage.LightningBullet;
import BulletPackage.LinearBullet;
import BulletPackage.OriginalBullet;
import Controllers.MyAdminister;
import GameListeners.BombListener;
import GameListeners.BulletsListener;
import GameListeners.SpaceShipListener;
import GamePackage.InformationOfPlayer.InformationOfPlayer;
import GamePackage.Tabs.InformationOfPlayerTab;
import GamePackage.Tabs.ScoreAndHeatTab;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import PlayersData.PropertiesOfPlayer;

public class Player implements Paintable, Updatable, Serializable {

	private String playerName;
	private int coinPlayerStored = 0;

	private transient boolean tryingToShotBullet = false;;
	private CopyOnWriteArrayList<Bullet> bullets = new CopyOnWriteArrayList<>(); // work
	private transient Point locationTryingToShotBullet;

	private SpaceShip spaceShip; // work

	private InformationOfPlayer informationOfPlayer;

	private PropertiesOfPlayer propertiesOfPlayer;

	private long lastShotBullet = 0;

	private int id;

	public Player(int id, String playerName) {
		this.id = id;
		this.playerName = playerName;
		initialize();
	}

	public int getId() {
		return id;
	}

	private void initialize() {
		spaceShip = new SpaceShip(id, playerName);

		informationOfPlayer = new InformationOfPlayer(id);

		propertiesOfPlayer = new PropertiesOfPlayer(playerName, 0, 0, 0);

	}

	@Override
	public void update() {
		spaceShip.update();

		createBullet();

		if (bullets != null) {
			for (Bullet bullet : bullets) {
				if (!bullet.isDestroy()) {
					bullet.update();
				} else {
					bullets.remove(bullet);
				}
			}
		}

		informationOfPlayer.update();

	}

	private void createBullet() {
		if (isPosibleToShot()) {
			if (!MyAdminister.getInstance().isPlayingWithMouse()) {
				locationTryingToShotBullet = new Point((int) getSpaceShip().getLocation().getX() + 25 + 12 - 5,
						(int) getSpaceShip().getLocation().getY() + 40 - 50);
			}
			howManyBullets();

			lastShotBullet = System.currentTimeMillis();
			OriginalBullet.playSoundOfFire();
			informationOfPlayer.setDegreeIncreasing(true);
		}
	}

	private void howManyBullets() {
		int howManyBullets = informationOfPlayer.getPowerOfBullet().getLevel() + 1;
		if (informationOfPlayer.getPowerOfBullet().getTypeOfBullet() <= 3) {
			if (howManyBullets % 2 == 0) {
				bullets.add(new Bullet(new LinearBullet(
						new Point((int) locationTryingToShotBullet.getX() - 10,
								(int) locationTryingToShotBullet.getY()),
						informationOfPlayer.getPowerOfBullet().getPower(), 0,
						informationOfPlayer.getPowerOfBullet().getTypeOfBullet()), LinearBullet.class));
				bullets.add(new Bullet(new LinearBullet(
						new Point((int) locationTryingToShotBullet.getX() + 10,
								(int) locationTryingToShotBullet.getY()),
						informationOfPlayer.getPowerOfBullet().getPower(), 0,
						informationOfPlayer.getPowerOfBullet().getTypeOfBullet()), LinearBullet.class));
				howManyBullets -= 2;
			} else {
				bullets.add(new Bullet(
						new LinearBullet(locationTryingToShotBullet, informationOfPlayer.getPowerOfBullet().getPower(),
								0, informationOfPlayer.getPowerOfBullet().getTypeOfBullet()),
						LinearBullet.class));
				howManyBullets -= 1;
			}
			for (int i = 1; i <= howManyBullets / 2; i++) {
				bullets.add(new Bullet(
						new LinearBullet(locationTryingToShotBullet, informationOfPlayer.getPowerOfBullet().getPower(),
								i * 5, informationOfPlayer.getPowerOfBullet().getTypeOfBullet()),
						LinearBullet.class));
				bullets.add(new Bullet(
						new LinearBullet(locationTryingToShotBullet, informationOfPlayer.getPowerOfBullet().getPower(),
								i * -5, informationOfPlayer.getPowerOfBullet().getTypeOfBullet()),
						LinearBullet.class));

			}
		} else if (informationOfPlayer.getPowerOfBullet().getTypeOfBullet() == 4) {
			while (howManyBullets > 0) {
				bullets.add(new Bullet(new LightningBullet(locationTryingToShotBullet,
						MyAdminister.getInstance().getGalaxyWorld().getNearestEnemyForPlayer(id),
						informationOfPlayer.getPowerOfBullet().getPower(),
						informationOfPlayer.getPowerOfBullet().getTypeOfBullet()), LightningBullet.class));

				howManyBullets--;
			}

		}

	}

	@Override
	public void paint(Graphics2D g) {
		spaceShip.paint(g);

		if (bullets != null) {
			for (Bullet bullet : bullets) {
				bullet.paint(g);
			}
		}

		informationOfPlayer.paint(g);

	}

	private boolean isPosibleToShot() {
		return System.currentTimeMillis() - lastShotBullet >= OriginalBullet
				.getDistanceBetween2Shots(informationOfPlayer.getPowerOfBullet().getTypeOfBullet())
				&& tryingToShotBullet && !informationOfPlayer.isBoiling() && !spaceShip.isDestroy();
	}

	public void tryingToShotBullet(boolean istryingToShotBullet) {
		this.tryingToShotBullet = istryingToShotBullet;
		if (istryingToShotBullet) {
			locationTryingToShotBullet = new Point(
					(int) (spaceShip.getLocation().getX() + spaceShip.getDimension().getWidth() / 2),
					(int) spaceShip.getLocation().getY());

		}

	}

	public void tryingToShotBomb(boolean isTryingToShotBomb) {
		informationOfPlayer.getBombsOfPlayer().TryingToShotBombs(isTryingToShotBomb);
	}

	public InformationOfPlayer getInformationOfPlayer() {

		return informationOfPlayer;
	}

	public void setInformationOfPlayer(InformationOfPlayer informationOfPlayer) {
		this.informationOfPlayer = informationOfPlayer;
	}

	public void increaseBomb() {
		informationOfPlayer.increaseBomb();
	}

	public CopyOnWriteArrayList<Bullet> getBullets() {
		return bullets;
	}

	public SpaceShip getSpaceShip() {
		return spaceShip;
	}

	public void setBullets(CopyOnWriteArrayList<Bullet> bullets) {
		this.bullets = bullets;
	}

	public void setSpaceShip(SpaceShip spaceShip) {
		this.spaceShip = spaceShip;
	}

	public PropertiesOfPlayer getPropertiesOfPlayer() {
		return propertiesOfPlayer;
	}

	public void setPropertiesOfPlayer(PropertiesOfPlayer propertiesOfPlayer) {
		this.propertiesOfPlayer = propertiesOfPlayer;
	}

	public void increaseCoinPlayerStored() {
		coinPlayerStored++;
	}

	public void calculateCoinScore() {
		informationOfPlayer.getScore().increaseScore(coinPlayerStored * 5);
		coinPlayerStored = 0;

	}

	public String getPlayerName() {
		return playerName;
	}

	public Point getLocationTryingToShotBullet() {
		return locationTryingToShotBullet;
	}

}
