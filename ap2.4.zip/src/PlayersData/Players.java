package PlayersData;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Modifier;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.sun.jmx.remote.security.HashedPasswordManager;

import BulletPackage.LinearBullet;
import Controllers.MyAdminister;
import GamePackage.BackgroundGame;
import GamePackage.GalaxyWorld;
import GamePackage.GameEngine;
import GamePackage.Player;
import GamePackage.SpaceShip;
import GamePackage.InformationOfPlayer.InformationOfPlayer;
import GamePackage.InformationOfPlayer.PowerOfBullet;
import GamePackage.Tabs.InformationOfPlayerTab;
import GamePackage.Tabs.ScoreAndHeatTab;
import StagesOfGame.SinglePLayerHandler;

import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Players {

	private static Players playersOfGame;
	private ArrayList<HashMap<String, byte[]>> dataOfPlayers = new ArrayList<>();
	private ArrayList<String> playersName = new ArrayList<>();
//	private ObjectInputStream objectInputStream ;
//	private ObjectOutputStream objectOutputStream ;

	private Connection allDataBases;
	private boolean isConnectedDataBase;

	private Players() {
		isConnectedDataBase = false;
		loadGame();
	}

	private void loadGame() {
		try {
//			objectInputStream = new ObjectInputStream(new FileInputStream(new File("Game.data")));
//			playersName = (ArrayList<String>) objectInputStream.readObject();
//			dataOfPlayers = (ArrayList<HashMap<String, String>>) objectInputStream.readObject();

			loadFromDataBase();

		} catch (Exception e) {
			loadFromFile();
		}
	}

	private void loadFromFile() {
		Scanner scanner;
		try {
			scanner = new Scanner(new FileInputStream(new File("Game.data")));
			GsonBuilder gsonBuilder = new GsonBuilder();
			Gson gson = gsonBuilder.excludeFieldsWithModifiers(Modifier.TRANSIENT).create();
			playersName = gson.fromJson(scanner.nextLine(), new TypeToken<ArrayList<String>>() {
			}.getType());
			dataOfPlayers = gson.fromJson(scanner.nextLine(), new TypeToken<ArrayList<HashMap<String, byte[]>>>() {
			}.getType());
		} catch (FileNotFoundException e1) {

		}
	}

	private void loadFromDataBase() throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			allDataBases = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "");

			isConnectedDataBase = true;
		} catch (SQLException | ClassNotFoundException e) {
			new Thread(() -> {
				JOptionPane.showMessageDialog(null,
						"Sorry! We Can't Connect To DataBase Or Data Not Exist But Can Read From File",
						"NotFoundDataBase", JOptionPane.ERROR_MESSAGE);

			}).start();

		}

		if (!isConnectedDataBase) {
			throw new SQLException();
		}
		createDataBaseIfNotExist();

		readFromDataBase();

	}

	private void readFromDataBase() throws SQLException {
		try {

			Statement statement = allDataBases.createStatement();
			ResultSet resultSet = statement.executeQuery("select * FROM `ChickenInvadersV2019`.`GalaxyWorld`");
			while (resultSet.next()) {
				GalaxyWorld galaxyWorld = new GalaxyWorld(resultSet.getInt(2), resultSet.getInt(3));
				Player player = new Player(0, resultSet.getString(1));
				SinglePLayerHandler singlePLayerHandler = new SinglePLayerHandler();
				InformationOfPlayer informationOfPlayer = new InformationOfPlayer(0);
				PropertiesOfPlayer propertiesOfPlayer = new PropertiesOfPlayer(resultSet.getString(1),
						resultSet.getInt(12), resultSet.getInt(13), resultSet.getInt(14));

				informationOfPlayer.getLifeOfPlayer().setLife(resultSet.getInt(4));
				informationOfPlayer.getBombsOfPlayer().setNumberOfBombs(resultSet.getInt(5));
				;
				informationOfPlayer.getScore().increaseScore(resultSet.getLong(6));
				informationOfPlayer.setPowerOfBullet(
						new PowerOfBullet(resultSet.getDouble(8), resultSet.getInt(7), resultSet.getInt(9)));
				informationOfPlayer.getHeat().setVeloctyDegreeDecreasing(resultSet.getDouble(11));
				informationOfPlayer.getHeat().setVeloctyDegreeIncreasing(resultSet.getDouble(10));

				singlePLayerHandler.setWavesPlay(resultSet.getInt(15));
				singlePLayerHandler.setWhenStart(resultSet.getLong(16));
				singlePLayerHandler.setLevelPlayersPlay(resultSet.getInt(17));
				singlePLayerHandler.setWavePlayerPlay(resultSet.getInt(18));

				player.setInformationOfPlayer(informationOfPlayer);
				player.setPropertiesOfPlayer(propertiesOfPlayer);
				CopyOnWriteArrayList<Player> players = new CopyOnWriteArrayList<>();
				players.add(player);
				galaxyWorld.setPlayers(players);
				galaxyWorld.getHandlerOfEnemyAndChicken().setSinglePLayerHandler(singlePLayerHandler);

				playersName.add(resultSet.getString(1));
				GameEngine gameEngine = new GameEngine(player.getPlayerName());
				gameEngine.setGalaxyWorld(galaxyWorld);
				dataOfPlayers.add(changeGalaxyWorldToHashMap(gameEngine));
			}
//			object.finishedPlayers.add(new FinishedPlayer(resultSet.getString(1), resultSet.getInt(2),
//					resultSet.getLong(3), resultSet.getLong(4)));
		} catch (SQLException e) {
			throw e;
		}
	}

	private void createDataBaseIfNotExist() throws SQLException {
		Connection dataBase = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "");
		Statement statement = dataBase.createStatement();
		statement.execute("CREATE DATABASE IF NOT EXISTS ChickenInvadersV2019");
		statement.execute(
				"CREATE TABLE IF NOT EXISTS `chickeninvadersV2019`.`GalaxyWorld` ( `playerName` TEXT, `levelS` INT , `waves` INT"
						+ ",`life` INT , `bomb` INT , `score` BIGINT , `levelOfBullet` INT , `powerOfBullet` INT , `typeOfBullet` INT"
						+ ", `veloctyDegreeIncreasing` DOUBLE , `veloctyDegreeDecreasing` DOUBLE , `wavesPlayMax` INT , `maxScore` BIGINT , `howMuchTakeTime` BIGINT"
						+ ", `wavesPlay` INT , `whenStart` BIGINT , `levelPlayerPlay` INT , `wavePlayerPlay` INT) ;"); // 18
																														// ta
																														// culomn

	}

	public static Players getInstance() {
		if (playersOfGame == null) {
			playersOfGame = new Players();
		}
		return playersOfGame;

	}

	public void saveGame() {

		if (isConnectedDataBase) {
			saveInDataBase();
		}
		saveInFile();
	}

	private void saveInDataBase() {
		try {
			Statement statement = allDataBases.createStatement();
			statement.executeUpdate("DELETE FROM `ChickenInvadersV2019`.`GalaxyWorld` ;");

			String sql = "INSERT INTO `ChickenInvadersV2019`.`GalaxyWorld` "
					+ "( `playerName` , `levelS`  , `waves` ,`life`  , `bomb`"
					+ "  , `score` , `levelOfBullet`  , `powerOfBullet`  , `typeOfBullet` "
					+ ", `veloctyDegreeIncreasing`  , `veloctyDegreeDecreasing`  , `wavesPlayMax` , `maxScore` , `howMuchTakeTime` "
					+ ", `wavesPlay`  , `whenStart` , `levelPlayerPlay`  , `wavePlayerPlay` )"
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ? , ? , ? , ? , ? , ? , ?);";
			PreparedStatement preparedStatement = allDataBases.prepareStatement(sql);
			for (HashMap<String, byte[]> data : dataOfPlayers) {
				try {
					GalaxyWorld galaxyWorld = changeHashMapToGalaxyWorld(data);
					SinglePLayerHandler singlePLayerHandler = galaxyWorld.getHandlerOfEnemyAndChicken()
							.getSinglePLayerHandler();
					Player player = galaxyWorld.getPlayer(0);
					if (player != null) {
					} else {
						player = new Player(0, playersName.get(dataOfPlayers.indexOf(data)));
					}
					InformationOfPlayer informationOfPlayer = player.getInformationOfPlayer();
					PropertiesOfPlayer propertiesOfPlayer = player.getPropertiesOfPlayer();

					preparedStatement.setString(1, player.getPlayerName());
					preparedStatement.setInt(2, singlePLayerHandler.getLeveles());
					preparedStatement.setInt(3, singlePLayerHandler.getWaves());

					preparedStatement.setInt(4, informationOfPlayer.getLifeOfPlayer().getLife());
					preparedStatement.setInt(5, informationOfPlayer.getBombsOfPlayer().getNumberOfBomb());
					preparedStatement.setLong(6, informationOfPlayer.getScore().getScoreOfGame());
					preparedStatement.setInt(7, informationOfPlayer.getPowerOfBullet().getLevel());
					preparedStatement.setDouble(8, informationOfPlayer.getPowerOfBullet().getPower());
					preparedStatement.setInt(9, informationOfPlayer.getPowerOfBullet().getTypeOfBullet());
					preparedStatement.setDouble(10, informationOfPlayer.getHeat().getVeloctyDegreeIncreasing());
					preparedStatement.setDouble(11, informationOfPlayer.getHeat().getVeloctyDegreeDecreasing());
					preparedStatement.setInt(12, propertiesOfPlayer.getWavesPlay());
					preparedStatement.setLong(13, propertiesOfPlayer.getScore());
					preparedStatement.setLong(14, propertiesOfPlayer.getHowMuchTimeTake());
					preparedStatement.setInt(15, singlePLayerHandler.getWavesPlay());
					preparedStatement.setLong(16, singlePLayerHandler.getWhenStart());
					preparedStatement.setInt(17, singlePLayerHandler.getLevelPlayersPlay());
					preparedStatement.setInt(18, singlePLayerHandler.getWavePlayerPlay());
					preparedStatement.executeUpdate();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,
					"Sorry! We Can't Connect To DataBase Or Data Not Exist But Can Write To File", "NotFoundDataBase",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	private void saveInFile() {
		try {
//			objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File("Game.data")));
//			objectOutputStream.writeObject(playersName);
//			objectOutputStream.writeObject(dataOfPlayers);
			PrintStream printStream = new PrintStream(new FileOutputStream(new File("Game.data")));
			GsonBuilder gsonBuilder = new GsonBuilder();
			Gson gson = gsonBuilder.excludeFieldsWithModifiers(Modifier.TRANSIENT).create();
			printStream.println(gson.toJson(playersName));
			printStream.println(gson.toJson(dataOfPlayers));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public HashMap<String, byte[]> getDataOfPlayer(String player) {

		return dataOfPlayers.get(playersName.indexOf(player));
	}

	public ArrayList<String> getPlayersName() {

		return playersName;
	}

	public void updateDataOfPlayer(String player, HashMap<String, byte[]> data) {
		dataOfPlayers.set(playersName.indexOf(player), data);
	}

	public void removePlayer(String Player) {
		dataOfPlayers.remove(playersName.indexOf(Player));
		playersName.remove(Player);
	}

	public void addPlayer(String player, HashMap<String, byte[]> data) {
		playersName.add(player);
		dataOfPlayers.add(data);
	}

	public HashMap<String, byte[]> changeGalaxyWorldToHashMap(GameEngine gameEngine) {
		HashMap<String, byte[]> data = new HashMap<>();
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.excludeFieldsWithModifiers(Modifier.TRANSIENT).create();
//		data.put("Bullets", ChangeBulletsToJson(galaxyWorld , gson));
//		data.put("Bullets", gson.toJson(galaxyWorld.getBullets() , ArrayList.class));
//		data.put("Bullets" , gson.toJson(galaxyWorld.getPlayer(0).getBullets()));
//		data.put("BackgroundGame", gson.toJson(galaxyWorld.getBackgroundGame() , BackgroundGame.class));
//		data.put("SpaceShip" , gson.toJson(galaxyWorld.getPlayer(0).getSpaceShip() , SpaceShip.class));
//		data.put("ScoreAndHeatTab" , gson.toJson(galaxyWorld.getPlayer(0).getScoreAndHeatTab() , ScoreAndHeatTab.class));
//		data.put("InformationOfPlayerTab", gson.toJson(galaxyWorld.getPlayer(0).getInformationOfPlayerTab() , 
//				InformationOfPlayerTab.class));
//		
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
			objectOutputStream.writeObject(gameEngine.getGalaxyWorld());

			data.put("galaxyWorld", byteArrayOutputStream.toByteArray());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}

//	private String ChangeBulletsToJson(GalaxyWorld galaxyWorld, Gson gson) {
//		ArrayList<Bullet> bullets = galaxyWorld.getBullets();
//		ArrayList<String> stringBullets = new ArrayList<>();
//		for(int i = 0 ; i<bullets.size() ; i++) {
//			stringBullets.add(gson.toJson(bullets.get(i), Bullet.class));
//		}
//		return gson.toJson(stringBullets, ArrayList.class);
//	}

	public GalaxyWorld changeHashMapToGalaxyWorld(HashMap<String, byte[]> data) {
		GalaxyWorld galaxyWorld = null;
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.excludeFieldsWithModifiers(Modifier.TRANSIENT).create();
//		galaxyWorld.setBullets(ChangeJsonToBullets(data.get("Bullets"), gson));
//		galaxyWorld.setBullets(gson.fromJson(data.get("Bullets"), ArrayList.class));
//		galaxyWorld.getPlayer(0).setBullets(gson.fromJson(data.get("Bullets"), new TypeToken<ArrayList<Bullet>>(){}.getType()));
//		galaxyWorld.setBackgroundGame(gson.fromJson(data.get("BackgroundGame"), BackgroundGame.class));
//		galaxyWorld.getPlayer(0).setSpaceShip(gson.fromJson(data.get("SpaceShip"), SpaceShip.class));
//		galaxyWorld.getPlayer(0).setScoreAndHeatTab(gson.fromJson(data.get("ScoreAndHeatTab"), ScoreAndHeatTab.class));
//		galaxyWorld.getPlayer(0).setInformationOfPlayerTab(gson.fromJson(data.get("InformationOfPlayerTab"), 
//				InformationOfPlayerTab.class));
//		
		byte[] dataOfGalaxyWorld = data.get("galaxyWorld");
		try {
			ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(dataOfGalaxyWorld));

			galaxyWorld = (GalaxyWorld) objectInputStream.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return galaxyWorld;
	}

	public ArrayList<PropertiesOfPlayer> getPropertiesOfPlayer() {
		ArrayList<PropertiesOfPlayer> propertiesOfPlayers = new ArrayList<>();
		for (HashMap<String, byte[]> dataOfPlayer : dataOfPlayers) {
			if (changeHashMapToGalaxyWorld(dataOfPlayer).getPlayers().isEmpty()) {
				propertiesOfPlayers
						.add(new PropertiesOfPlayer(playersName.get(dataOfPlayers.indexOf(dataOfPlayer)), 0, 0, 0));
			} else {
				propertiesOfPlayers
						.add(changeHashMapToGalaxyWorld(dataOfPlayer).getPlayers().get(0).getPropertiesOfPlayer());
			}
		}

		return propertiesOfPlayers;
	}

//	private ArrayList<Bullet> ChangeJsonToBullets(String string ,  Gson gson) {
//		ArrayList<String> stringBullets = gson.fromJson(string, ArrayList.class);
//		ArrayList<Bullet> bullets = new ArrayList<>();
//		for(int i=0 ; i<stringBullets.size() ; i++) {
//			bullets.add(gson.fromJson(stringBullets.get(i), Bullet.class));
//		}
//		return bullets;
//	}
}
