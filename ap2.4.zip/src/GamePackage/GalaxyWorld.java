package GamePackage;

import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import BossPackage.Boss;
import ChickenPackage.Chicken;
import Controllers.ControllerOfPlayer;
import Controllers.MyAdminister;
import GroupChicken.GroupChicken;
import GroupChicken.OriginalGroupChicken;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import PlayersData.PropertiesOfPlayer;
import StagesOfGame.HandlerOfEnemyAndChicken;
import Tool.SuperGameEngineThread;

public class GalaxyWorld
//	extends SuperGameEngineThread 
		implements Updatable, Paintable, Serializable {

	private BackgroundGame backgroundGame;

	private CopyOnWriteArrayList<Player> players = new CopyOnWriteArrayList<>();
	private transient CopyOnWriteArrayList<Player> waitingPlayers = new CopyOnWriteArrayList<>();
	private transient CopyOnWriteArrayList<ControllerOfPlayer> controllerOfPlayers = new CopyOnWriteArrayList<>();
	private transient CopyOnWriteArrayList<ScoresOfGame> scoresOfGames = new CopyOnWriteArrayList<>();

	private HandlerOfEnemyAndChicken handlerOfEnemyAndChicken;

	
	public GalaxyWorld() {
	
	}
	
	public GalaxyWorld(int levels, int waves) {

		handlerOfEnemyAndChicken = new HandlerOfEnemyAndChicken(levels, waves,
				MyAdminister.getInstance().isPlayingSinglePlayer());
		backgroundGame = new BackgroundGame();

	}

	public CopyOnWriteArrayList<Player> getWaitingPlayers() {
		return waitingPlayers;
	}

	public void setWaitingPlayers(CopyOnWriteArrayList<Player> waitingPlayers) {
		this.waitingPlayers = waitingPlayers;
	}

	public CopyOnWriteArrayList<Player> getPlayers() {
		return players;
	}

	public void setPlayers(CopyOnWriteArrayList<Player> players) {
		this.players = players;
	}

	public HandlerOfEnemyAndChicken getHandlerOfEnemyAndChicken() {
		return handlerOfEnemyAndChicken;
	}

	public void setHandlerOfEnemyAndChicken(HandlerOfEnemyAndChicken handlerOfEnemyAndChicken) {
		this.handlerOfEnemyAndChicken = handlerOfEnemyAndChicken;
	}

	@Override
	public void paint(Graphics2D g) {
		if (backgroundGame == null) {
			backgroundGame = new BackgroundGame();
		}
		backgroundGame.paint(g);
		handlerOfEnemyAndChicken.paint(g);
		for (Player player : players) {
			player.paint(g);
		}
	}

	@Override
	public void update() {
		if (backgroundGame == null) {
			backgroundGame = new BackgroundGame();
		}
		backgroundGame.move();

		for (Player player : players) {
			player.update();

			getScoreOfGame(player.getId()).setScore(player.getInformationOfPlayer().getScore().getScoreOfGame());

		}

		handlerOfEnemyAndChicken.update();
	}

	public Player getPlayer(int id) {
		if (players == null) {
			players = new CopyOnWriteArrayList<>();
		}
		for (Player player : players) {
			if (player.getId() == id) {
				return player;
			}
		}
		return null;
	}

	public Player getWaitingPlayer(int id) {
		if (waitingPlayers == null) {
			waitingPlayers = new CopyOnWriteArrayList<>();
		}

		for (Player player : waitingPlayers) {
			if (player.getId() == id) {
				return player;
			}
		}

		return null;
	}

	public void createWaitingPlayerToPlayer() {
		if (players == null) {
			players = new CopyOnWriteArrayList<>();
		}
		if (waitingPlayers == null) {
			waitingPlayers = new CopyOnWriteArrayList<>();
		}
		for (Player player : waitingPlayers) {
			players.add(player);
			waitingPlayers.remove(player);
		}
	}

	public void requestToJoinToMultiPlayer(Socket accept) {
		if (controllerOfPlayers == null) {
			controllerOfPlayers = new CopyOnWriteArrayList<>();
		}
		if (waitingPlayers == null) {
			waitingPlayers = new CopyOnWriteArrayList<>();
		}

		if (scoresOfGames == null) {
			scoresOfGames = new CopyOnWriteArrayList<>();
		}

		ControllerOfPlayer controllerOfPlayer = new ControllerOfPlayer(accept);

		if (getPlayers().size() == 0 || MyAdminister.getInstance().isPlayingSinglePlayer()) {
			MyAdminister.getInstance().setServerPlayerId(controllerOfPlayer.getPlayerId());
		}
		if ((!controllerOfPlayer.isSpectater() && !MyAdminister.getInstance().isPlayingSinglePlayer())
				|| (MyAdminister.getInstance().isPlayingSinglePlayer() && getPlayers().size() == 0)) {
			getWaitingPlayers().add(new Player(controllerOfPlayer.getPlayerId(), controllerOfPlayer.getPlayerName()));
		}
		controllerOfPlayers.add(controllerOfPlayer);
		scoresOfGames.add(new ScoresOfGame(controllerOfPlayer.getPlayerId()));
	}

	public CopyOnWriteArrayList<ControllerOfPlayer> getAllUsers() {
		return controllerOfPlayers;
	}

	public void changeWaitingPlayerToPlayer() {
		if (waitingPlayers == null) {
			waitingPlayers = new CopyOnWriteArrayList<>();
		}
		for (Player player : waitingPlayers) {
			if (players == null) {
				players = new CopyOnWriteArrayList<>();
			}
			players.add(player);
			waitingPlayers.remove(player);
		}
	}

	public void removePlayer(int id) {
		if (players == null) {
			players = new CopyOnWriteArrayList<>();
		}
		players.remove(getPlayer(id));
		if (waitingPlayers == null) {
			waitingPlayers = new CopyOnWriteArrayList<>();
		}
		waitingPlayers.remove(getWaitingPlayer(id));
		if (controllerOfPlayers == null) {
			controllerOfPlayers = new CopyOnWriteArrayList<>();
		}
		controllerOfPlayers.remove(getUser(id));

	}

	public ControllerOfPlayer getUser(int id) {
		for (ControllerOfPlayer controllerOfPlayer : getAllUsers()) {
			if (controllerOfPlayer.getId() == id) {
				return controllerOfPlayer;
			}
		}
		return null;
	}

	public ScoresOfGame getScoreOfGame(int id) {
		for (ScoresOfGame scoresOfGame : scoresOfGames) {
			if (scoresOfGame.getId() == id) {
				return scoresOfGame;
			}
		}
		return null;
	}

	public void readyLevels() {
		handlerOfEnemyAndChicken.readyLevels();
	}

	public String getInfoOfPlayers() {
		String info = "";
		for (ControllerOfPlayer controllerOfPlayer : getAllUsers()) {
			info += controllerOfPlayer.toString() + "\n";
		}

		return info;
	}
	
	public CopyOnWriteArrayList<ControllerOfPlayer> getControllerOfPlayer(){
		return controllerOfPlayers;
	}

	public Point getNearestEnemyForPlayer(int id) {

		Point locationTryingToShot = new Point(
				(int) (MyAdminister.getInstance().getPlayer(id).getLocationTryingToShotBullet().getX()),
				(int) (MyAdminister.getInstance().getPlayer(id).getLocationTryingToShotBullet().getY()));

		Chicken nearestChicken = getNearestChickenForPlayer(id, locationTryingToShot);
		Boss nearestBoss = getNearestBossForPlayer(id, locationTryingToShot);

		Point nearest = null;
		if (nearestChicken == null && nearestBoss != null) {
			nearest = nearestBoss.getMiddle();
		} else if (nearestChicken != null && nearestBoss == null) {
			nearest = nearestChicken.getMiddle();
		} else if (nearestBoss != null && nearestChicken != null) {
			if (Math.pow(nearestBoss.getMiddle().getX() - locationTryingToShot.getX(), 2)
					+ Math.pow(nearestBoss.getMiddle().getY() - locationTryingToShot.getY(), 2) < Math
							.pow(nearestChicken.getMiddle().getX() - locationTryingToShot.getX(), 2)
							+ Math.pow(nearestChicken.getMiddle().getY() - locationTryingToShot.getY(), 2)) {
				nearest = nearestBoss.getMiddle();
			} else {
				nearest = nearestChicken.getMiddle();
			}
		} else {
			nearest = new Point((int) locationTryingToShot.getX(), -200);
		}
		return nearest;
	}

	private Boss getNearestBossForPlayer(int id, Point locationTryingToShot) {
		Boss nearest = null;
		for (Boss boss : getHandlerOfEnemyAndChicken().getBosses()) {
			if (nearest == null) {
				nearest = boss;
			}
			if (Math.pow(boss.getMiddle().getX() - locationTryingToShot.getX(), 2)
					+ Math.pow(boss.getMiddle().getY() - locationTryingToShot.getY(), 2) < Math
							.pow(nearest.getMiddle().getX() - locationTryingToShot.getX(), 2)
							+ Math.pow(nearest.getMiddle().getY() - locationTryingToShot.getY(), 2)) {
				nearest = boss;
			}
		}

		return nearest;
	}

	private Chicken getNearestChickenForPlayer(int id, Point locationTryingToShot) {
		Chicken nearest = null;

		for (GroupChicken groupOfChicken : getHandlerOfEnemyAndChicken().getGroupChickens()) {
			Chicken chicken = groupOfChicken.getNearestChickenToPlayer(id);
			if (nearest == null) {
				nearest = chicken;
			}
			if (Math.pow(chicken.getMiddle().getX() - locationTryingToShot.getX(), 2)
					+ Math.pow(chicken.getMiddle().getY() - locationTryingToShot.getY(), 2) < Math
							.pow(nearest.getMiddle().getX() - locationTryingToShot.getX(), 2)
							+ Math.pow(nearest.getMiddle().getY() - locationTryingToShot.getY(), 2)) {
				nearest = chicken;
			}
		}
		return nearest;
	}

}
