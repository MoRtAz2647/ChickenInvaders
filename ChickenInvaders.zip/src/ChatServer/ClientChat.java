package ChatServer;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ClientChat extends Thread {

	private Socket socket;
	private String playerName;

	private ShowPanelOfChat showPanelOfChat;

	public ClientChat(int port, String ip, String playerName) {
		try {
			socket = new Socket(ip, port);
			showPanelOfChat = new ShowPanelOfChat(new PrintStream(socket.getOutputStream()), playerName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		start();

	}

	@Override
	public void run() {

		try {

			while (true) {

				Scanner scanner = new Scanner(socket.getInputStream());
				while (true) {
					String messenger = scanner.nextLine();
					String message = scanner.nextLine();
					showPanelOfChat.addToTextArea(messenger + ": \n  " + message);
				}
			}
		} catch (Exception e) {
		}

	}

	public void StopClientChat() {
		try {
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		showPanelOfChat.closePrinter();
		stop();
	}

}
