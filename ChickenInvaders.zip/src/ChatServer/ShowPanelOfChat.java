
package ChatServer;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ShowPanelOfChat extends JFrame {

	private JScrollPane scroll;
	private JTextArea textArea;
	private JTextField textField;
	private JButton sendButton;

	private JPanel contentPane;

	private PrintStream printer;

	private String playerName;

	public ShowPanelOfChat(PrintStream printer, String playerName) {
		this.printer = printer;
		this.playerName = playerName;

		printer.println(playerName);

		Initialize();

	}

	private void Initialize() {

		contentPane = new JPanel();

		textArea = new JTextArea();
		textField = new JTextField();
		sendButton = new JButton("Send");
		scroll = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED ,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		textArea.setSize(new Dimension(300, 600));
		textField.setSize(new Dimension(250, 150));
		sendButton.setSize(new Dimension(50, 150));


		textArea.setEditable(false);
		sendButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				sendMessage();
			}

		});
		textField.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				sendMessage();
			}
		});

		addLikeGrid();
//		textField.setMinimumSize(new Dimension(200, 50));

//		panelOfTextArea = new JPanel();
//		panelOfTextField = new JPanel();

//		panelOfTextArea.add(textArea , BorderLayout.CENTER);
//		panelOfTextArea.add(scroll);

//		panelOfTextField.add(textField , BorderLayout.CENTER);
//		panelOfTextField.add(sendButton ,BorderLayout.EAST);

//		add(panelOfTextField , BorderLayout.SOUTH);
//		add(panelOfTextArea , BorderLayout.NORTH);
//		add(textArea, BorderLayout.NORTH);

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setPreferredSize(new Dimension(400, 800));
		pack();
		setVisible(true);

	}

	private void sendMessage() {
		if (!ShowPanelOfChat.this.textField.getText().equals("")) {
			printer.println(ShowPanelOfChat.this.textField.getText());
			ShowPanelOfChat.this.textField.setText("");
		}
	}

	private void addLikeGrid() {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(textField, BorderLayout.CENTER);
		panel.add(sendButton, BorderLayout.EAST);

		contentPane.setLayout(new BorderLayout());

//		contentPane.add(textArea, BorderLayout.CENTER);
		contentPane.add(panel, BorderLayout.SOUTH);
		contentPane.add(scroll , BorderLayout.CENTER);

	}

	public void addToTextArea(String message) {
		String string = textArea.getText();
		string += "\n" + message;
		textArea.setText(string);
	}

	public void closePrinter() {
		sendButton.removeAll();
		printer.close();
	}

}
