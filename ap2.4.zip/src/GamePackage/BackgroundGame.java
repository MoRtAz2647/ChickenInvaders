package GamePackage;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.Serializable;

import Controllers.MyAdminister;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import ListOfAddress.MyObjectCollection;

public class BackgroundGame implements Paintable, Movable, Serializable {

	private int x1;
	private int y1;
	private int width1;
	private int height1;

	private int x2;
	private int y2;
	private int width2;
	private int height2;

	public BackgroundGame() {
		initialize();
	}

	private void initialize() {
		x1 = 0;
		y1 = 0;
		width1 = (int) MyAdminister.getInstance().getSizeOfFrame().getWidth();
		height1 = (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() + 20;

		x2 = 0;
		y1 = (int) -MyAdminister.getInstance().getSizeOfFrame().getHeight();
		width2 = (int) MyAdminister.getInstance().getSizeOfFrame().getWidth();
		height2 = (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() + 20;
	}

	@Override
	public void paint(Graphics2D g) {
		g.drawImage((BufferedImage) MyObjectCollection.getInstance().getImage("GalaxyWorldBackground"), x1, y1, width1,
				height1, null);
		g.drawImage((BufferedImage) MyObjectCollection.getInstance().getImage("GalaxyWorldBackground"), x2, y2, width2,
				height2, null);
	}

	@Override
	public void move() {
		y1 += 2;
		y2 += 2;
		if (y1 >= (int) MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			y1 = y2 - height1 + 20;
		}
		if (y2 >= (int) MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			y2 = y1 - height2 + 20;
		}
	}
}
