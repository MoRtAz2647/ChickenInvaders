package ActionEnum;

public enum FeatureEnum {
	Boss , GroupChicken
}
