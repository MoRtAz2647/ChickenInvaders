package Buttons.PausePanel;

import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.PrintStream;

import com.google.gson.Gson;

import ActionEnum.PlayerTask;
import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.BroadcastOfPlayerTask;
import ListOfAddress.MyObjectCollection;

public class ContinueButton extends OriginalButton implements BroadcastOfPlayerTask{

	private PrintStream printer;

	public ContinueButton() {
		super((BufferedImage) (MyObjectCollection.getInstance().getImage("ContinueInClick")),
				(BufferedImage) (MyObjectCollection.getInstance().getImage("ContinueOutClick")),
				(int) MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 250,
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 - 50 - 55, 500, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			synchronized (printer) {
				send(PlayerTask.Continue, printer);
				
			}
			MyAdminister.getInstance().showClientPanel();
		}
	}

	public void setPrinter(PrintStream printer) {
		this.printer = printer;
	}

}
