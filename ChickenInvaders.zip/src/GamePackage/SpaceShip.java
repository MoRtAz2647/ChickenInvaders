package GamePackage;

import java.awt.AWTException;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import ActionEnum.DirectionEnum;
import Controllers.MyAdminister;
import GroupChicken.CircleChickens;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class SpaceShip implements Paintable, Destroyable, Serializable, Updatable {

	private double x;
	private double y;
	public static final int width = 80;
	public  static final int heigth = 80;

	private int whichSpaceShipSelect = 4;
	private int whichColor = 0;

	private boolean moveLeft = false;
	private boolean moveRight = false;
	private boolean moveDown = false;
	private boolean moveUp = false;
	private int veloctyX = 5;
	private int veloctyY = 5;

	private int id;
	private boolean isDestroy = false;

	private boolean isHavingShield;
	private long howMuchHaveShield = 0;

	private transient CopyOnWriteArrayList<BufferedImage> blastImage = new CopyOnWriteArrayList<>();
	private long whenDestroy = 0;
	private long whenChangeBlastImage = 0;
	private boolean isBlasting = false;
	private int whichBlastSelected = 0;

	private String playerName;

	public SpaceShip(int id, String playerName) {
		whichBlastSelected = (int) (Math.random() * 8) ;
		whichColor = (int) (Math.random() * 4) ;
		this.playerName = playerName;
		isHavingShield = false;
		this.id = id;
		initialize();

	}

	private void initialize() {
		x = (int) ((MyAdminister.getInstance().getSizeOfFrame().getWidth() - width) / 2);
		y = (int) ((MyAdminister.getInstance().getSizeOfFrame().getHeight() - heigth - 28));

		isHavingShield = false;

	}

	public Point getLocation() {

		return new Point((int) x, (int) y);
	}

	public Dimension getDimension() {
		return new Dimension(width, heigth);
	}

	@Override
	public void paint(Graphics2D g) {
		if (!isDestroy) {
			g.drawImage(getImageSpaceShip(), (int) x, (int) y, width, heigth, null);
			g.setColor(new Color(id % 255, id % 255, id % 255));
			g.drawRect((int) x, (int) y, width, heigth);
			g.setColor(Color.WHITE);
			g.setFont(new Font("Arial", 1, 24));
			g.drawString(playerName, (int) x, (int) y);
//			AffineTransform at = AffineTransform.getTranslateInstance(x, y);
//			at.rotate(-90 * Math.PI / 180, width / 2, heigth / 2);
//			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
//			
//			g.drawImage(getImageSpaceShip(), at, null);
//			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

		}
		if (isHavingShield) {

			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g.setColor(Color.WHITE);
			g.fillOval((int) x, (int) y, width, heigth);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		}

		if (isBlasting) {
			g.drawImage(getImageBlasting(), (int) x, (int) y, width, heigth, null);

		}
	}

	private Image getImageBlasting() {

		return (BufferedImage) MyObjectCollection.getInstance().getImage("Blast" + whichBlastSelected + 1);
	}

	private Image getImageSpaceShip() {
		return (BufferedImage) MyObjectCollection.getInstance()
				.getImage("SpaceShip" + (whichSpaceShipSelect + 1) + (whichColor + 1));
	}

	public void setLocationOfSpaceShipWithMouse(double x, double y) {

		this.x = x - width / 2;
		this.y = y - heigth / 2;

	}

	private void checkSpaceShipIsInsideFrame() {
		if (x < 0) {
			x = 0;
		}
		if (x + width + 28 > (int) MyAdminister.getInstance().getSizeOfFrame().getWidth()) {
			x = (int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() - width - 28);
		}
		if (y + heigth + 28 > (int) MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			y = (int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - heigth - 28);
		}
		if (y < 5) {
			y = 5;
		}
	}

	@Override
	public boolean isDestroy() {

		return isDestroy;
	}

	public void setSpaceShipImage(int i, int j) {
		whichSpaceShipSelect = i;
		whichColor = j;
	}

	@Override
	public void update() {
		if (!MyAdminister.getInstance().isPlayingWithMouse()) {
			if (moveDown) {
				y += veloctyY;
			}
			if (moveLeft) {
				x -= veloctyX;
			}
			if (moveRight) {
				x += veloctyX;
			}
			if (moveUp) {
				y -= veloctyY;
			}
		}

		checkSpaceShipIsInsideFrame();

		if (isDestroy
				&& MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getLifeOfPlayer().getLife() > 0
				&& System.currentTimeMillis() - whenDestroy >= 5000) {

			MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getLifeOfPlayer().decreaseLife();
			isDestroy = false;
			whichBlastSelected = 0;
			MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getPowerOfBullet().decreasePower();

			try {
				new Robot().mouseMove((int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2),
						(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - 28));
			} catch (AWTException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			isHavingShield = true;
			howMuchHaveShield = System.currentTimeMillis();
		} else if (isDestroy
				&& MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getLifeOfPlayer().getLife() == 0) {
			MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getLifeOfPlayer()
					.setIsPossibleToContinue(false);
		}
		if (System.currentTimeMillis() - howMuchHaveShield >= 3000) {
			howMuchHaveShield = 0;
			isHavingShield = false;
		}

		if (isBlasting) {
			if (System.currentTimeMillis() - whenChangeBlastImage >= 100) {
				whichBlastSelected++;
			}
			if (whichBlastSelected >= 4) {
				isBlasting = false;
				whichBlastSelected = 0;
			}
		}

	}

	@Override
	public void setDestroy() {
		isDestroy = true;
		whenDestroy = System.currentTimeMillis();
		whenChangeBlastImage = System.currentTimeMillis();
		isBlasting = true;
		playingBlastSound();
	}

	public Rectangle getRectangle() {
		return new Rectangle((int) x, (int) y, width, heigth);
	}

	public boolean isHavingShield() {
		return isHavingShield;
	}

	public void setShieldForSpaceShip(boolean isHavingShield) {
		this.isHavingShield = isHavingShield;
		if (isHavingShield) {
			howMuchHaveShield = Long.MAX_VALUE;
		}
	}

	private static void playingBlastSound() {
		new Thread(() -> {
			try {
				Clip blastSound = AudioSystem.getClip();
				blastSound.open(MyObjectCollection.getInstance().getSound("BlastSound"));
				blastSound.start();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}).start();
	}

	public void setMove(DirectionEnum move) {
		switch (move) {
		case MoveDown:
			moveDown = move.getGoing();
			break;
		case MoveLeft:
			moveLeft = move.getGoing();
			break;
		case MoveRight:
			moveRight = move.getGoing();
			break;
		case MoveUp:
			moveUp = move.getGoing();
			break;
		default:
			break;
		}
	}

}
