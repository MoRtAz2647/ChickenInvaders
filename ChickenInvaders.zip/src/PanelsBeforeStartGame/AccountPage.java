package PanelsBeforeStartGame;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

import Buttons.PanelAccounts.*;
import Controllers.MyAdminister;
import GamePackage.GameEngine;
import InterfaceAble.Drawable;
import InterfaceAble.Paintable;
import ListOfAddress.MyObjectCollection;
import PlayersData.Players;

public class AccountPage extends JPanel implements Drawable {

	private BufferedImage backgroundGalaxy;
	private AddButton addButton;
	private LetsPlayButton enterButton;
	private RemoveButton removeButton;

	private ListOfAccounts listOfAccounts;

	public AccountPage() {
		intialize();

	}

	private void intialize() {
		try {
			backgroundGalaxy = (BufferedImage) MyObjectCollection.getInstance().getImage("GalaxyBackgroundAccount");

		} catch (Exception e) {
			e.printStackTrace();
		}
		//////////////////////////
		// add listener for buttons
		addButtons();
		/////////////////////////
		listOfAccounts = new ListOfAccounts();
		addKeyListener(listOfAccounts);
		addMouseListener(listOfAccounts);

		repaint();

		setVisible(true);
		new Thread(() -> {
			while (true) {

				repaint();
				revalidate();
				try {
					Thread.sleep(100);
				} catch (Exception e) {

				}
			}
		}).start();
	}

	private void addButtons() {
		try {
			addButton = new AddButton();
			enterButton = new LetsPlayButton();
			removeButton = new RemoveButton();
			addMouseMotionListener(addButton);
			addMouseMotionListener(enterButton);
			addMouseMotionListener(removeButton);
			addMouseListener(addButton);
			addMouseListener(enterButton);
			addMouseListener(removeButton);
		} catch (Exception e) {
			e.getStackTrace();
		}
	}

	@Override
	protected void paintComponent(Graphics g) {

		render((Graphics2D) g);

	}

	private void paintStringAccountsName(Graphics2D g) {

		g.setColor(new Color(255, 255, 255));
		g.setFont(new Font("Arial", 1, 56));
		g.drawString("Chicken Invaders", (int) (getSize().width / 2) - 250, 75);

		g.setColor(new Color(255, 255, 255));
		g.setFont(new Font("Arial", 1, 46));
		g.drawString("Accounts", 150, 175);

	}

	private void paintButtons(Graphics2D g) {
		addButton.paint(g);
		enterButton.paint(g);
		removeButton.paint(g);

	}

	@Override
	public void render(Graphics2D g) {
		g.drawImage(backgroundGalaxy, 0, 0, (int) (MyAdminister.getInstance().getSizeOfFrame().getWidth()),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight()), null);
		paintButtons(g);
		paintStringAccountsName(g);

		listOfAccounts.paint(g);

	}

	public void removePlayer() {
		listOfAccounts.removePlayer();
	}

	public void addNewPlayer() {
		listOfAccounts.addNewPlayer();
	}

	public String getPlayingAccount() {
		return listOfAccounts.getPlayingAccount();
	}

}

class ListOfAccounts implements Paintable, KeyListener, MouseListener {

	private BufferedImage checkInClick;
	private BufferedImage checkOutClick;

	private int checkBoxStartDrawX;
	private int checkBoxStartDrawY;
	private int checkBoxWidth;
	private int checkBoxHeight;

	private int distanceBetweenCheckBoxOrString;

	private int stringStartDrawX;
	private int stringStartDrawY;
	private int sizeOfString;

	private ArrayList<String> playersName;

	private int whichPlayerSelected;

	private String newPLayer = "";
	private boolean isTryingToTypeNewPlayerName;

	public ListOfAccounts() {
		initialize();
	}

	public String getPlayingAccount() {
		return playersName.get(whichPlayerSelected);
	}

	public void addNewPlayer() {
		if (isTryingToTypeNewPlayerName) {
			JOptionPane.showMessageDialog(null, "You Must At First Complete Adding Preocess", "Oh! You Can't.",
					JOptionPane.ERROR_MESSAGE);
		} else {
			if (playersName.size() > 10) {
				JOptionPane.showMessageDialog(null, "This is The Maximam Size You Can Have:))", "Oh! You Can't.",
						JOptionPane.ERROR_MESSAGE);
				
			} else {
				isTryingToTypeNewPlayerName = true;
			}
		}
	}

	public void removePlayer() {
		if (playersName.size() == 1) {
			JOptionPane.showMessageDialog(null, "You Must At Least Have One Player:)", "Oh! You Can't.",
					JOptionPane.ERROR_MESSAGE);
		} else {
			Players.getInstance().removePlayer(playersName.get(whichPlayerSelected));
			playersName = Players.getInstance().getPlayersName();
			whichPlayerSelected = 0;
		}
	}

	private void initialize() {
		checkInClick = (BufferedImage) MyObjectCollection.getInstance().getImage("CheckInClick");
		checkOutClick = (BufferedImage) MyObjectCollection.getInstance().getImage("CheckOutClick");

		checkBoxStartDrawX = 200;
		checkBoxStartDrawY = 210;
		checkBoxWidth = 50;
		checkBoxHeight = 50;
		distanceBetweenCheckBoxOrString = 60;

		stringStartDrawX = 250;
		stringStartDrawY = 250;
		sizeOfString = 40;

		whichPlayerSelected = 0;

		givePlayersName();
	}

	private void givePlayersName() {
		if (Players.getInstance().getPlayersName().size() == 0) {
			Players.getInstance().addPlayer("Guest",
					Players.getInstance().changeGalaxyWorldToHashMap(new GameEngine("Guest")));
		}
		playersName = Players.getInstance().getPlayersName();
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {
		int keyUserPressed = e.getKeyCode();
		if (isTryingToTypeNewPlayerName) {
			if (keyUserPressed == KeyEvent.VK_BACK_SPACE && newPLayer.length() >= 1) {
				newPLayer = newPLayer.substring(0, newPLayer.length() - 1);
			} else if (keyUserPressed == KeyEvent.VK_ENTER) {
				if (playersName.contains(newPLayer) || newPLayer.equals("")) {
					JOptionPane.showMessageDialog(null, "This Player Name Exist \n Or \n You Don't Right Anything-_-",
							"Oh! You Can't.", JOptionPane.ERROR_MESSAGE);

				} else {
					createNewPlayer();
				}
			} else if (checkIsRealKey(keyUserPressed)) {
				if (newPLayer.length() < 16) {
					newPLayer += e.getKeyChar();
				} else {
					JOptionPane.showMessageDialog(null, "This Is The Maximam Size:))", "Oops!",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}

	private boolean checkIsRealKey(int keyUserPressed) {
		return !(keyUserPressed == KeyEvent.VK_CAPS_LOCK || keyUserPressed == KeyEvent.VK_SHIFT
				|| keyUserPressed == KeyEvent.VK_CONTROL || keyUserPressed == KeyEvent.VK_ALT);
	}

	private void createNewPlayer() {
		Players.getInstance().addPlayer(newPLayer, Players.getInstance().changeGalaxyWorldToHashMap(new GameEngine(newPLayer)));
		playersName = Players.getInstance().getPlayersName();
		isTryingToTypeNewPlayerName = false;
		newPLayer = "";
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		for(int i=0 ; i<playersName.size() ; i++) {
			Rectangle rectangle = new Rectangle(checkBoxStartDrawX, checkBoxStartDrawY + i * distanceBetweenCheckBoxOrString,
					checkBoxWidth, checkBoxHeight);
			if(rectangle.contains(e.getPoint())) {
				whichPlayerSelected=i;
			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void paint(Graphics2D g) {
		g.setColor(Color.WHITE);
		for (int i = 0; i < playersName.size(); i++) {
			g.setFont(new Font("Arial", isBold(i), sizeOfString));
			g.drawString(" " + (i + 1) + "- " + playersName.get(i), stringStartDrawX,
					stringStartDrawY + i * distanceBetweenCheckBoxOrString);
			g.drawImage(getImage(i), checkBoxStartDrawX, checkBoxStartDrawY + i * distanceBetweenCheckBoxOrString,
					checkBoxWidth, checkBoxHeight, null);
		}

		if (isTryingToTypeNewPlayerName) {
			g.setFont(new Font("Arial", 0, sizeOfString));
			g.drawString(" " + (playersName.size() + 1) + "- " + newPLayer, stringStartDrawX,
					stringStartDrawY + playersName.size() * distanceBetweenCheckBoxOrString);
			g.drawImage(checkOutClick, checkBoxStartDrawX,
					checkBoxStartDrawY + playersName.size() * distanceBetweenCheckBoxOrString, checkBoxWidth,
					checkBoxHeight, null);
		}
	}

	private Image getImage(int i) {
		if (whichPlayerSelected == i)
			return checkInClick;
		return checkOutClick;
	}

	private int isBold(int i) {
		if (whichPlayerSelected == i)
			return 1;
		return 0;
	}

}
