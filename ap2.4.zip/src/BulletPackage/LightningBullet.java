package BulletPackage;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;

import Tool.IntersectsRotateRectangle;
import javafx.application.Application;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class LightningBullet extends OriginalBullet {

	private double xStartLight;
	private double yStartLight;
	private double xFinishLight;
	private double yFinishLight;

	private double distanceBetween2Point = 50;
	private int[] xLights;
	private int[] yLights;

	private long whenCreate;

	public LightningBullet(Point locationTryingToShotBullet, Point locationWantToShot, double power, int type) {
		super(OriginalBullet.getPower(type, power), type);

		xStartLight = locationTryingToShotBullet.getX();
		yStartLight = locationTryingToShotBullet.getY();
		xFinishLight = locationWantToShot.getX();
		yFinishLight = locationWantToShot.getY();

		whenCreate = System.currentTimeMillis();

		findRout();

		move();
	}

	private void findRout() {
		if (xStartLight == xFinishLight) {

			double distance = Math.abs(yStartLight - yFinishLight);
			findNumberOfLights(distance);

			setFirstAndEndLights();
			findAnotherLights(0, yFinishLight > yStartLight ? distanceBetween2Point : -distanceBetween2Point);

		} else {
			double d = (distanceBetween2Point
					/ Math.sqrt(1 + Math.pow((yStartLight - yFinishLight) / (xStartLight - xFinishLight), 2)));

			double x1 = d + xStartLight;
			double x2 = -d + xStartLight;
			double y1 = (x1 - xStartLight) * (yStartLight - yFinishLight) / (xStartLight - xFinishLight) + yStartLight;
			double y2 = (x2 - xStartLight) * (yStartLight - yFinishLight) / (xStartLight - xFinishLight) + yStartLight;

			double x;
			double y;
			if (Math.pow(x2 - xFinishLight, 2) + Math.pow(y2 - yFinishLight, 2) > Math.pow(x1 - xFinishLight, 2)
					+ Math.pow(y1 - yFinishLight, 2)) {
				x = x1;
				y = y1;
			} else {
				x = x2;
				y = y2;
			}
			double distance = Math
					.sqrt(Math.pow(xFinishLight - xStartLight, 2) + Math.pow(yFinishLight - yStartLight, 2));

			findNumberOfLights(distance);
			setFirstAndEndLights();

			double xDistanceBetween2Point = x - xStartLight;
			double yDistanceBetween2Point = y - yStartLight;

			findAnotherLights(xDistanceBetween2Point, yDistanceBetween2Point);
		}

	}

	private void findAnotherLights(double xDistanceBetween2Point, double yDistanceBetween2Point) {
		for (int i = 1; i < xLights.length - 1; i++) {
			xLights[i] = (int) (xLights[i - 1] + xDistanceBetween2Point);
			yLights[i] = (int) (yLights[i - 1] + yDistanceBetween2Point);
		}
//		System.out.println(Arrays.toString(xLights));
//		System.out.println(Arrays.toString(yLights));
	}

	private void setFirstAndEndLights() {
		xLights[0] = (int) xStartLight;
		yLights[0] = (int) yStartLight;
		xLights[xLights.length - 1] = (int) xFinishLight;
		yLights[yLights.length - 1] = (int) yFinishLight;

	}

	private void findNumberOfLights(double distance) {
		if (Math.floor(distance / distanceBetween2Point) == distance / distanceBetween2Point) {
			xLights = new int[(int) Math.floor(distance / distanceBetween2Point + 1)];
			yLights = new int[(int) Math.floor(distance / distanceBetween2Point + 1)];
		} else {
			xLights = new int[(int) Math.floor(distance / distanceBetween2Point + 2)];
			yLights = new int[(int) Math.floor(distance / distanceBetween2Point + 2)];

		}
	}

	@Override
	public void move() {
		for (int i = 1; i < xLights.length - 1; i++) {
			xLights[i] += (int) ((Math.random() * 3 - 1) * distanceBetween2Point / 5 * (getPower() * 25 * 2));
			yLights[i] += (int) ((Math.random() * 3 - 1) * distanceBetween2Point / 5 * (getPower() * 25 * 2));
//			yLights[i]++;
//			yLights[i] += (int) ((Math.random() * 3 - 1) * distanceBetween2Point);
		}
	}

	@Override
	public void update() {
		move();

		if (System.currentTimeMillis() - whenCreate > 10) {
			setDestroy();
		}
	}

	@Override
	public boolean isIntersect(Rectangle rectangle, double degree) {
		return IntersectsRotateRectangle.intersects(rectangle, degree,
				new Rectangle((int) xFinishLight, (int) yFinishLight, 1, 1), 0);
	}

	@Override
	public void paint(Graphics2D g) {
		Color color = new Color(160, 150, 230);
		Stroke defaultStroke = g.getStroke();
		g.setStroke(new BasicStroke(2f));
		for (int i = 0; i < xLights.length - 1; i++) {
			g.setColor(color);
			g.drawLine(xLights[i], yLights[i], xLights[i + 1], yLights[i + 1]);
			int red = color.getRed() == 255 ? 255 : color.getRed() + 1;
			int green = color.getGreen() == 255 ? 255 : color.getGreen() + 1;
			int blue = color.getBlue() == 255 ? 255 : color.getBlue() + 1;
			color = new Color(red, green, blue);
		}
		g.setStroke(defaultStroke);

//		for (int i = 0; i < xLights.length - 1; i++) {
//			g.setColor(g.getColor().darker());
//			g.drawLine(xLights[i], yLights[i], xLights[i + 1], yLights[i + 1]);
//		}
//		g.drawPolyline(xLights, yLights, xLights.length);

	}

}
