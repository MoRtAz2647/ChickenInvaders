package InterfaceAble;

public interface Movable {
	void move();
}
