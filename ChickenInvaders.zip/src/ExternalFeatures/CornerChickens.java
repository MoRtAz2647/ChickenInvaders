package ExternalFeatures;

import ActionEnum.DirectionEnum;
import ActionEnum.FeatureEnum;
import ChickenPackage.Chicken;
import ChickenPackage.ChickenLinear;
import Controllers.MyAdminister;
import GroupChicken.OriginalGroupChicken;
import InfoAnotation.WhichFeature;

@WhichFeature(feature = FeatureEnum.GroupChicken)
public class CornerChickens extends OriginalGroupChicken {

	private double xOfFirstChicken;
	private double yOfFirstChicken;

	private DirectionEnum direction;

	public CornerChickens(int levelPlayerPlay) {
		for (int i = 1; i <= 30; i++) {
			getChickens().add(new ChickenLinear(levelPlayerPlay, -100, 0));
		}
		xOfFirstChicken = -3000;
		yOfFirstChicken = 0;

		direction = DirectionEnum.MoveRight;
	}

	@Override
	public void move() {
		super.move();

		changeLocationOfFirstChicken();
	}

	private void changeLocationOfFirstChicken() {
		switch (direction) {
		case MoveRight:
			xOfFirstChicken++;
			break;
		case MoveDown:
			yOfFirstChicken++;
			break;
		case MoveLeft:
			xOfFirstChicken--;
			break;
		case MoveUp:
			yOfFirstChicken--;
			break;
		default:
			break;
		}
	}

	@Override
	public void update() {
		super.update();

		setLocationOfChicken();

		ifChangeDirectionOfFirstChicken();

	}

	private void setLocationOfChicken() {
		DirectionEnum directionOfSetChicken = direction;
		double xOfLastChicken = xOfFirstChicken;
		double yOfLastChicken = yOfFirstChicken;

		for (Chicken chicken : getChickens()) {
			chicken.setWhereMustBe(xOfLastChicken, yOfLastChicken);

			switch (directionOfSetChicken) {

			case MoveRight:
				if (MyAdminister.getInstance().getSizeOfFrame().getWidth() <= Chicken.width + xOfLastChicken + 100)
					directionOfSetChicken = DirectionEnum.MoveDown;
				break;
			case MoveDown:
				if (MyAdminister.getInstance().getSizeOfFrame().getHeight() <= Chicken.height + yOfLastChicken + 50)
					directionOfSetChicken = DirectionEnum.MoveLeft;
				break;
			case MoveLeft:
				if (0 + 100 >= xOfLastChicken)
					directionOfSetChicken = DirectionEnum.MoveUp;
				break;
			case MoveUp:
				if (0 + 50 >= yOfLastChicken)
					directionOfSetChicken = DirectionEnum.MoveRight;
				break;
			default:
				break;
			}

			switch (directionOfSetChicken) {
			case MoveRight:
				xOfLastChicken += Chicken.width;
				break;
			case MoveDown:
				yOfLastChicken += Chicken.height;
				break;
			case MoveLeft:
				xOfLastChicken -= Chicken.width;
				break;
			case MoveUp:
				yOfLastChicken -= Chicken.height;
				break;
			default:
				break;
			}

		}
	}

	private void ifChangeDirectionOfFirstChicken() {
		switch (direction) {
		case MoveRight:
			if (MyAdminister.getInstance().getSizeOfFrame().getWidth() <= Chicken.width + xOfFirstChicken + 100)
				direction = DirectionEnum.MoveDown;
			break;
		case MoveDown:
			if (MyAdminister.getInstance().getSizeOfFrame().getHeight() <= Chicken.height + yOfFirstChicken + 50)
				direction = DirectionEnum.MoveLeft;
			break;
		case MoveLeft:
			if (0 + 100 >= xOfFirstChicken)
				direction = DirectionEnum.MoveUp;
			break;
		case MoveUp:
			if (0 + 50 >= yOfFirstChicken)
				direction = DirectionEnum.MoveRight;
			break;
		default:
			break;
		}

	}
}
