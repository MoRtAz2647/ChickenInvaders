package GroupChicken;

import java.awt.Graphics2D;
import java.awt.Point;

import ChickenPackage.Chicken;
import ChickenPackage.ChickenLinear;
import Controllers.MyAdminister;

public class RectangleChickens extends OriginalGroupChicken {

	private long whenCreate;
	private int numberOfChickenFirstHave;
	private int numberOfChickenWeHave;
	private int length = 10;
	private  int height = 3;

	private double xOfFirstChicken;
	private double yOfFirstChicken;
	private double veloctyX;

	public RectangleChickens(int levelPlayerPlay) {
		numberOfChickenFirstHave = 30;
		whenCreate = System.currentTimeMillis();
		numberOfChickenWeHave = numberOfChickenFirstHave;
		for (int i = 1; i <= numberOfChickenFirstHave; i++) {
			getChickens().add(new ChickenLinear(levelPlayerPlay, -100, -100));
		}
		
		xOfFirstChicken = 20;
		yOfFirstChicken = 50;
		veloctyX = 1;

	}

	@Override
	public void move() {
		super.move();
		xOfFirstChicken += veloctyX;

	}

	@Override
	public void update() {
		super.update();
		numberOfChickenWeHave = getChickens().size();
		length = numberOfChickenWeHave / height + 1;

		if (checkIfChangeVelocty() && System.currentTimeMillis() - whenCreate >= 1000) {
			veloctyX *= -1;
		}

		int xChicken = 1;
		int yChicken = 1;
		for (Chicken chicken: getChickens()) {
			chicken.setWhereMustBe(
					xOfFirstChicken + (xChicken - 1) * 100, yOfFirstChicken + (yChicken - 1) * 100);
			if (xChicken >= length) {
				xChicken = 1;
				yChicken++;
			} else {
				xChicken++;
			}
		}

	}

	private boolean checkIfChangeVelocty() {
		return xOfFirstChicken + length * 100 >= MyAdminister.getInstance().getSizeOfFrame().getWidth()
				|| xOfFirstChicken <= 0;
	}

	@Override
	public void paint(Graphics2D g) {
//		System.out.println(xOfFirstChicken);
		super.paint(g);
	}

}
