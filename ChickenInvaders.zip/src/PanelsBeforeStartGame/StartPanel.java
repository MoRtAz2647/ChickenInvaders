package PanelsBeforeStartGame;


import Controllers.MyAdminister;

public class StartPanel  {
	
	public static void main(String[] args) {
		MyAdminister.getInstance().createShowFrame();
		

	}

}
