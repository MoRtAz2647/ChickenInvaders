package ChickenPackage;

import Controllers.MyAdminister;

public class ChickenPolar extends Chicken {

	private double radius;
	private double teta;

	private double radiusMustBe;
	private double tetaMustBe;

	public ChickenPolar(int level, int x, int y) {
		super(level, x, y);
		radius = MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 + 100;
	}

	@Override
	public void move() {
		super.move();
		if (Math.abs(radius - radiusMustBe) >= getVelocty()) {
			if (radius > radiusMustBe) {
				radius -= getVelocty();
			} else {
				radius += getVelocty();
			}
		} else {
			radius = radiusMustBe;
			if (Math.abs(teta - tetaMustBe) >= getVelocty()) {
				if (teta > tetaMustBe) {
					teta -= getVelocty();
				} else {
					teta += getVelocty();
					
				}
			} else {
				teta = tetaMustBe;
			}
		}

	}

	@Override
	public void update() {
		super.update();
		if (radius == radiusMustBe && Math.abs(radius - radiusMustBe) < 1 && Math.abs(teta - tetaMustBe) < 1) {
			setVelocty(1);
			setInPlace(true);
		} else {
			setInPlace(false);
		}

		setLocation(
				MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 + radius * Math.cos(teta * Math.PI / 180),
				MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 + radius * Math.sin(teta * Math.PI / 180));

	}
	public void setLocationPolarMustBe(double radius , double teta) {
		radiusMustBe = radius;
		tetaMustBe = teta;
	}
}
