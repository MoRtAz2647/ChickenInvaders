package GamePackage.InformationOfPlayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.Serializable;

import Controllers.MyAdminister;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class PowerOfBullet implements Updatable, Paintable, Movable, Serializable {

	private double power;
	private int level;
	private int typeOfBullet = 2;

	public PowerOfBullet(double power, int level, int type) {
		this.power = power;
		this.level = level;
		this.typeOfBullet = type;
	}

	@Override
	public void update() {

	}

	@Override
	public void paint(Graphics2D g) {
	}

	@Override
	public void move() {

	}

	public double getPower() {
		return power;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
		power = level > 3 ? 1 + (power - 3) * 0.25 : 1;

	}

	public int getTypeOfBullet() {
		return typeOfBullet;
	}

	public void setTypeOfBullet(int typeOfBullet) {
		if (typeOfBullet == this.typeOfBullet) {
			level++;
		}
		this.typeOfBullet = typeOfBullet;
	}

	public void increaseLevel() {
		level++;
		if (power >= 4) {
			power += 0.5;
		} else {

		}

	}

	public void decreasePower() {
		level /= 2;
		power = level > 3 ? 1 + (power - 3) * 0.25 : 1;

	}
}
