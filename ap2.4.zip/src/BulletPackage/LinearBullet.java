
package BulletPackage;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;

import Controllers.MyAdminister;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import Tool.IntersectsRotateRectangle;

public class LinearBullet extends OriginalBullet {

	private transient BufferedImage bullet;

	private double x;
	private double y;
	private double width;
	private double heigth;
	private double velocity;

	private double degree;

	public LinearBullet(Point location, double power, double degree, int type) {
	
		super(getPower(type, power), type);
		
		x = (int) location.getX();
		y = (int) location.getY();

		width = getDimension(type).getWidth();
		heigth = getDimension(type).getHeight();
		velocity = getVelocty(type);

		this.degree = degree;

		initialize();
	}

	private void initialize() {

	}

	private void getImage() {
		bullet = resize((BufferedImage) MyObjectCollection.getInstance().getImage("Bullet" + getType()), (int) heigth,
				(int) width);

	}

	private static BufferedImage resize(BufferedImage img, int height, int width) {
		Image tmp = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = resized.createGraphics();
		g2d.drawImage(tmp, 0, 0, null);
		g2d.dispose();
		return resized;
	}

	@Override
	public void move() {
		y += Math.cos(degree * Math.PI / 180) * velocity;
		x += Math.sin(-degree * Math.PI / 180) * velocity;

	}

	@Override
	public void paint(Graphics2D g) {
		AffineTransform at = AffineTransform.getTranslateInstance(x, y);
		at.rotate(degree * Math.PI / 180, width / 2, heigth / 2);
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
		if (bullet == null) {
			getImage();
		}
		g.drawImage(bullet, at, null);
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

	}

	public Rectangle getRectangle() {
		return new Rectangle((int) x, (int) y, (int) width, (int) heigth);
	}

	@Override
	public void update() {
		move();
		
		if (y + heigth <= 0 || y >= MyAdminister.getInstance().getSizeOfFrame().getHeight()) {
			setDestroy();
		}
		if (x + width <= 0 || x >= MyAdminister.getInstance().getSizeOfFrame().getWidth()) {
			setDestroy();
		}
	}

	public double getDegree() {
		return degree + 270;
	}

	@Override
	public boolean isIntersect(Rectangle rectangle, double degree) {
		return IntersectsRotateRectangle.intersects(rectangle, degree,
				getRectangle(), getDegree());
	}
}
