package StagesOfGame;

import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.imageio.ImageIO;

import ActionEnum.FeatureEnum;
import BossPackage.Boss;
import BossPackage.LinearBoss;
import Controllers.MyAdminister;
import ExternalFeatures.CornerBoss;
import ExternalFeatures.CornerChickens;
import Features.Features;
import GroupChicken.CircleChickens;
import GroupChicken.GroupChicken;
import GroupChicken.OriginalGroupChicken;
import GroupChicken.RectangleChickens;
import GroupChicken.RotationChickens;
import GroupChicken.SuicideChickens;
import InfoAnotation.WhichFeature;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class HandlerOfEnemyAndChicken implements Updatable, Paintable, Serializable {

	private MultiPlayerHandler multiPlayerHandler;
	private SinglePLayerHandler singlePLayerHandler;

	private transient CopyOnWriteArrayList<Class> groupChickensFeature;
	private transient CopyOnWriteArrayList<Class> bossFeatureClass;

	private boolean isSinglePlayer;

	public HandlerOfEnemyAndChicken(int levels, int waves, boolean isSinglePlayer) {
		this.isSinglePlayer = isSinglePlayer;

		if (MyAdminister.getInstance().isPlayingSinglePlayer()) {
			singlePLayerHandler = new SinglePLayerHandler();
		} else {
			multiPlayerHandler = new MultiPlayerHandler(levels, waves);
		}
	}


	@Override
	public void paint(Graphics2D g) {
		if (isSinglePlayer) {
			singlePLayerHandler.paint(g);
		} else {
			multiPlayerHandler.paint(g);
		}

	}

	@Override
	public void update() {
		if (MyAdminister.getInstance().isPlayingSinglePlayer()) {
			singlePLayerHandler.update();
		} else {
			multiPlayerHandler.update();
		}
	}

//	public void start() {
//		if (MyAdminister.getInstance().isPlayingSinglePlayer()) {
//
//			for (GroupOfChicken groupOfChicken : singlePLayerHandler.getEnemy()) {
//				groupOfChicken.start();
//			}
//		} else {
//			for (GroupOfChicken groupOfChicken : multiPlayerHandler.getEnemy()) {
//				groupOfChicken.start();
//				;
//			}
//		}
//	}
//
//	public void stop() {
//		if (MyAdminister.getInstance().isPlayingSinglePlayer()) {
//			for (GroupOfChicken groupOfChicken : singlePLayerHandler.getEnemy()) {
//				groupOfChicken.interrupt();
//			}
//		} else {
//			for (GroupOfChicken groupOfChicken : multiPlayerHandler.getEnemy()) {
//				groupOfChicken.interrupt();
//			}
//		}
//	}

	public void readyLevels() {
		singlePLayerHandler.readyLevels();
	}

	public CopyOnWriteArrayList<GroupChicken> getGroupChickens() {
		if (MyAdminister.getInstance().isPlayingSinglePlayer()) {
			return singlePLayerHandler.getEnemy();
		}
		return multiPlayerHandler.getEnemy();
	}
	
	public CopyOnWriteArrayList<Boss> getBosses(){
		if(MyAdminister.getInstance().isPlayingSinglePlayer()) {
			return singlePLayerHandler.getBosses();
		}
		return multiPlayerHandler.getBosses();
	}

	public Class getRandomFeature(FeatureEnum feature) {
		switch (feature) {
		case GroupChicken:
			return getRandomGroupChicken();
		case Boss:
			return getRandomBoss();
		default:
			return null;
		}
	}

	private Class getRandomGroupChicken() {
		if (groupChickensFeature == null) {
			createFeatureClass();
		}
		int whichGroup = (int) (Math.random() * groupChickensFeature.size());
		return groupChickensFeature.get(whichGroup);
	}

	private Class getRandomBoss() {
		if (bossFeatureClass == null) {
			createFeatureClass();
		}
		int whichGroup = (int) (Math.random() * bossFeatureClass.size());
		return bossFeatureClass.get(whichGroup);
	}

	private void createFeatureClass() {
		createChickenGroupFeatureClass();
		createBossFeatureClass();
	}

	private void createBossFeatureClass() {
		bossFeatureClass = new CopyOnWriteArrayList<>();
		bossFeatureClass.add(LinearBoss.class);
		bossFeatureClass.add(CornerBoss.class);
	}

	private void createChickenGroupFeatureClass() {
		groupChickensFeature = new CopyOnWriteArrayList<>();
		groupChickensFeature.add(RectangleChickens.class);
		groupChickensFeature.add(CircleChickens.class);
		groupChickensFeature.add(SuicideChickens.class);
		groupChickensFeature.add(RotationChickens.class);
		groupChickensFeature.add(CornerChickens.class);
	}

	public void addNewFeature(Class newFeature) {
		switch (((WhichFeature)(newFeature.getDeclaredAnnotation(WhichFeature.class))).feature()) {
		case Boss:
			bossFeatureClass.add(newFeature);
			break;
		case GroupChicken:
			groupChickensFeature.add(newFeature);
			
			break;

		default:
			break;
		}
	}

	public SinglePLayerHandler getSinglePLayerHandler() {
		return singlePLayerHandler;
	}

	public void setSinglePLayerHandler(SinglePLayerHandler singlePLayerHandler) {
		this.singlePLayerHandler = singlePLayerHandler;
	}
	
	

}
