package BossPackage;

import java.awt.Point;

import Controllers.MyAdminister;

public class LinearBoss extends OriginalBoss {

	private double xMustBe;
	private double yMustBe;

	private boolean isInPlace;
	private long whenBeInPlace;

	private double degree;
	private long lastShotFire;

	public LinearBoss(int levelPlayerPlay) {
		super(levelPlayerPlay);
		setX(MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - getDimension().getWidth() / 2);
		setY(-getDimension().getHeight());
		xMustBe = MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - getDimension().getWidth() / 2;
		yMustBe = MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 - getDimension().getHeight() / 2;

		lastShotFire = System.currentTimeMillis();

	}

	@Override
	public void move() {
		super.move();
		if (!isInPlace) {
			int speed = (Math.sqrt(
					Math.pow(getLocation().getX() - xMustBe, 2) + Math.pow(getLocation().getY() - yMustBe, 2)) < 2) ? 1
							: 2;
			setX(getLocation().getX()
					+ Math.cos(Math.atan2(yMustBe - getLocation().getY(), xMustBe - getLocation().getX())) * speed);
			setY(getLocation().getY()
					+ Math.sin(Math.atan2(yMustBe - getLocation().getY(), xMustBe - getLocation().getX())) * speed);
		}

	}

	@Override
	public void update() {
		super.update();
		move();

		if (System.currentTimeMillis() - lastShotFire >= 500) {
			lastShotFire = System.currentTimeMillis();
			degree = Math.random() * 360;
			for (int i = 1; i <= 8; i++) {
				if (Math.random() < 0.5) {
					getFires().add(new Fire(
							new Point((int) (getLocation().getX() + getDimension().getWidth() / 2),
									(int) (getLocation().getY() + getDimension().getHeight() / 2)),
							degree + i * 360 / 8));
				}
			}
		}

		if ((Math
				.sqrt(Math.pow(getLocation().getX() - xMustBe, 2) + Math.pow(getLocation().getY() - yMustBe, 2)) < 2)) {
			if (!isInPlace) {
				whenBeInPlace = System.currentTimeMillis();
				isInPlace = true;
			} else if (System.currentTimeMillis() - whenBeInPlace >= 5000) {
				xMustBe = Math.random()
						* (MyAdminister.getInstance().getSizeOfFrame().getWidth() - getDimension().getWidth());
				yMustBe = Math.random()
						* (MyAdminister.getInstance().getSizeOfFrame().getHeight() - getDimension().getHeight());
				isInPlace = false;

			}
		} else {
			isInPlace = false;
		}

	}

}
