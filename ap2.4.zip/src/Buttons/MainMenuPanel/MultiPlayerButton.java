package Buttons.MainMenuPanel;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.MultiPlayerButton.ClientButton;
import Buttons.MultiPlayerButton.ServerButton;
import Buttons.MultiPlayerButton.StartButton;
import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.Selectable;
import ListOfAddress.MyObjectCollection;

public class MultiPlayerButton extends OriginalButton implements Selectable {
	private ServerButton serverButton ;
	private ClientButton clientButton ;

	private boolean isSelected;

	public MultiPlayerButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("MultiPlayerInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("MultiPlayerOutClick"),
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 4 - 25 * 3, 400, 100);
		
		serverButton = new ServerButton();
		clientButton = new ClientButton();
		
		isSelected = false;
	}
	
	
	public ServerButton getServerButton() {
		return serverButton;
	}


	public ClientButton getClientButton() {
		return clientButton;
	}


	@Override
	public void paint(Graphics2D g) {
		super.paint(g);
		if (isSelected) {
			serverButton.paint(g);
			clientButton.paint(g);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().setSelectedOfMenuButton(false);
			isSelected = !isSelected;
		}
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public void setSelectedOfServerAndClient(boolean b) {
		serverButton.setSelected(b);
		clientButton.setSelected(b);
	}

}
