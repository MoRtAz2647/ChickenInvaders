package Controllers;

import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.google.gson.JsonElement;

import ActionEnum.FeatureEnum;
import ActionEnum.PlayerTask;
import ChatServer.ClientChat;
import ChatServer.ServerChat;
import ChickenPackage.Chicken;
import GamePackage.GalaxyWorld;
import GamePackage.GameEngine;
import GamePackage.PausePanel;
import GamePackage.Player;
import GamePackage.WaitingPanel;
import ListOfAddress.MyObjectCollection;
import PanelsBeforeStartGame.*;
import PlayersData.Players;
import PlayersData.PropertiesOfPlayer;
import ServerPackage.Connecter;
import ServerPackage.MultiPlayerGameEngine;
import Settings.MainSettingPanel;
import StagesOfGame.HandlerOfEnemyAndChicken;
import StagesOfGame.SinglePLayerHandler;

public class MyAdminister {
	private static MyAdminister myAdminister;
	private transient ShowFrame showFrame;
	private transient WelcomePage welcomePage;
	private transient AccountPage accountPage;
	private transient GameEngine gameEngine;
	private transient MainMenuPanel mainMenuPanel;
	private transient MainSettingPanel mainSettingPanel;

	private transient MultiPlayerGameEngine multiPlayerGameEngine;
	private transient ClientChat clientChat ;
	
	
	private Connecter connecter;
	private ServerChat serverChat;

	private Image cursorImage;
	private Toolkit toolkit;
	private Clip backgroundSound;
	private boolean isPlayingBackgroundSound;

	private String playingAccountName;
	private int playerId;
	private String whichBackgroundSoundSelected = "11";

	private boolean isPlayingWithMouse = true;

	private boolean isSinglePlayerMode = true;
	private int howManyPlayerCanPlay = 1;

	private MyAdminister() {
		isPlayingBackgroundSound = false;

	}

	public static MyAdminister getInstance() {
		if (myAdminister == null) {
			myAdminister = new MyAdminister();
		}
		return myAdminister;
	}

	public void createShowFrame() {
		showFrame = new ShowFrame();
		setCursorFork();
		createWelcomePage();
	}

	private void setContentPane(Container container) {
		showFrame.setContentPane(container);
		showFrame.pack();
		showFrame.repaint();
		showFrame.revalidate();
	}

	public void createWelcomePage() {
		welcomePage = new WelcomePage();
		setContentPane(welcomePage);

	}

	public void showAccountPage() {
		if (accountPage == null) {
			accountPage = new AccountPage();
		} else {
			updateDataOfPlayer();
		}
		setContentPane(accountPage);
		accountPage.requestFocus();
	}

	public Dimension getSizeOfFrame() {
		return showFrame.getPreferredSize();
	}

	public void showGalaxyWorld() {
		if (gameEngine == null) {
			createNewGalaxyWorld(4, 4);
		} else {
			gameEngine.start();
		}
		setPropertiesOfGalaxyWorld();

	}

	private void createNewGalaxyWorld(int levels, int waves) {
		gameEngine = new GameEngine(playingAccountName);
		gameEngine.setGalaxyWorld(new GalaxyWorld(levels, waves));
		setPropertiesOfGalaxyWorld();
	}

	private void setPropertiesOfGalaxyWorld() {
		setCursorHidden();
//		setContentPane(gameEngine);
//		gameEngine.requestFocus();
		pauseBackgroundSound();
		changeAllUserForSituationOfGame(PlayerTask.GamePanel);

	}

	public void changeAllUserForSituationOfGame(PlayerTask playerTask) {
		gameEngine.setWhichSituation(playerTask);
		if (getAllUsers() != null) {
			for (ControllerOfPlayer controllerOfPlayer : getAllUsers()) {
				synchronized (controllerOfPlayer) {

					controllerOfPlayer.setWhichPanelPaint(playerTask);
				}
			}
		}
	}

	//
	public void showPausePanel(PrintStream printer) {
		setContentPane(PausePanel.getInstance(printer));
		setCursorFork();
	}

	public void stopGameEngine() {

		gameEngine.stop();
	}

	public void setCursorHidden() {
		toolkit = Toolkit.getDefaultToolkit();
		Point point = new Point(0, 0);
		Cursor cursor = toolkit.createCustomCursor(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB), point,
				"hidden");
		showFrame.setCursor(cursor);
	}

	public void setCursorFork() {
		toolkit = Toolkit.getDefaultToolkit();
		cursorImage = toolkit.getImage("Pictures/fork.png");
		Point point = new Point(0, 0);
		Cursor cursor = toolkit.createCustomCursor(cursorImage, point, "fork");
		showFrame.setCursor(cursor);

	}

	public void showMainMenu() {

		if (mainMenuPanel == null) {
			mainMenuPanel = new MainMenuPanel();
		}
		if (!isPlayingBackgroundSound) {
			playingBackgroundSound();
		}
		setContentPane(mainMenuPanel);
		setCursorFork();

	}

	public void playingClickSound() {

		try {
			Clip clickSound = AudioSystem.getClip();
			clickSound.open(MyObjectCollection.getInstance().getSound("ClickSound"));
			clickSound.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void playingBackgroundSound() {
		isPlayingBackgroundSound = true;
		try {
			backgroundSound = AudioSystem.getClip();
			backgroundSound
					.open(MyObjectCollection.getInstance().getSound("BackgroundSound" + whichBackgroundSoundSelected));
			backgroundSound.loop(Clip.LOOP_CONTINUOUSLY);
			backgroundSound.start();
		} catch (Exception e) {

		}
	}

	public void pauseBackgroundSound() {
		isPlayingBackgroundSound = false;
		backgroundSound.stop();
	}

	public void removePlayer() {
		accountPage.removePlayer();
	}

	public void addNewPlayer() {
		accountPage.addNewPlayer();
	}

	public void updateDataOfPlayer() {
		Players.getInstance().updateDataOfPlayer(playingAccountName,
				Players.getInstance().changeGalaxyWorldToHashMap(gameEngine));
		Players.getInstance().saveGame();
	}

	public void getPlayingAccount() {
		playingAccountName = accountPage.getPlayingAccount();
		if (gameEngine == null) {
			gameEngine = new GameEngine(playingAccountName);
		}
		gameEngine.setGalaxyWorld(Players.getInstance()
				.changeHashMapToGalaxyWorld(Players.getInstance().getDataOfPlayer(playingAccountName)));
		Players.getInstance().saveGame();
	}

	public String getPlayingPlayerName() {
		return playingAccountName;
	}

	public void showMainSettingPanel() {
		if (mainSettingPanel == null) {
			mainSettingPanel = new MainSettingPanel();
		}
		setContentPane(mainSettingPanel);
	}

	public void setSelectedOfSettingButtons(boolean b) {
		mainSettingPanel.setSelectedOfSettingButtons(b);
	}

	public void setBackgroundSound(int i, int j) {
		whichBackgroundSoundSelected = "" + (i + 1) + (j + 1);
		pauseBackgroundSound();
		playingBackgroundSound();
	}

	public boolean isPlayingWithMouse() {
		return isPlayingWithMouse;
	}

	public void playingWithMouse(boolean isPlayingWithMouse) {
		this.isPlayingWithMouse = isPlayingWithMouse;
	}

	public boolean isPlayingSinglePlayer() {

		return isSinglePlayerMode;
	}

	public CopyOnWriteArrayList<Player> getPlayers() {
		return gameEngine.getGalaxyWorld().getPlayers();
	}

	public Player getPlayer(int id) {
		for (Player player : getPlayers()) {
			if (player.getId() == id) {
				return player;
			}
		}
		return null;
	}

	public GalaxyWorld getGalaxyWorld() {
		return gameEngine.getGalaxyWorld();
	}

	public void setGalaxyworld(GalaxyWorld fromJson) {
		gameEngine.setGalaxyWorld(fromJson);
	}

	public void gameFinish() {
		setCursorFork();
		showMainMenu();
		mainMenuPanel.getScoreButton().setSelected(true);
		gameEngine.getGalaxyWorld().getHandlerOfEnemyAndChicken().setSinglePLayerHandler(new SinglePLayerHandler());
		stopClientPlayer();
		gameEngine.stop();
	}

	public PropertiesOfPlayer getPropertiesOfPlayer(int id) {
		return getPlayer(id).getPropertiesOfPlayer();
	}

	public void setPropertiesOfPlayer(PropertiesOfPlayer propertiesOfPlayer, int id) {
		getPlayer(id).setPropertiesOfPlayer(propertiesOfPlayer);
	}

	public void requestToJoinToMultiPlayer(Socket accept) {
		gameEngine.getGalaxyWorld().requestToJoinToMultiPlayer(accept);
	}

	public void createGalaxyWorld(boolean isSinglePlayerMode, boolean isCreateNewGame, int howManyPlayerCanPlay,
			int levels, int waves) {
		this.isSinglePlayerMode = isSinglePlayerMode;
		this.howManyPlayerCanPlay = howManyPlayerCanPlay;
		if (isCreateNewGame) {
			createNewGalaxyWorld(levels, waves);
		} else {
			gameEngine.getGalaxyWorld().readyLevels();
//			showGalaxyWorld();
		}

		createWaitingPanel(levels, waves);
		
	}

	private void createWaitingPanel(int levels, int waves) {
		gameEngine.setWaitingPanel(new WaitingPanel(levels, waves));
	}

	public boolean runServerConnecter(int port) {
		if(serverChat != null) {
			serverChat.StopServerChat();
		}
		serverChat = new ServerChat(port - 1);
		
		
		
		if (connecter != null) {
			connecter.stopServer();
		}
		connecter = new Connecter(port);
		return connecter.isServerRun();
	}

	public void closeServerConnecter() {
		connecter.stopServer();
	}

	public void createClientPlayer(String ip, int port, boolean isSpectater) {
		multiPlayerGameEngine = new MultiPlayerGameEngine(playingAccountName, ip, port, isSpectater);
		showClientPanel();
		clientChat = new ClientChat(port - 1, ip, playingAccountName);
		
		
	}

	public void stopClientPlayer() {
		clientChat.StopClientChat();
		multiPlayerGameEngine.interrupt();
		
	}

	public void setServerPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getServerPlayerId() {
		return playerId;
	}

	public void setSelectedOfMenuButton(boolean b) {
		mainMenuPanel.setSelectedOfMenuButton(b);
	}

	public void setSelectedOfServerAndClient(boolean b) {
		mainMenuPanel.setSelectedOfServerAndClient(b);
	}

	public int getMaxPlayer() {
		return howManyPlayerCanPlay;
	}

	public CopyOnWriteArrayList<ControllerOfPlayer> getAllUsers() {
		return gameEngine.getGalaxyWorld().getAllUsers();
	}

	public boolean isGameStart() {
		return gameEngine.isStartGame();
	}

	public WaitingPanel getWaitingPanel() {
		return gameEngine.getWaitingPanel();
	}

	public void showClientPanel() {
		setCursorHidden();
		setContentPane(multiPlayerGameEngine);
		multiPlayerGameEngine.requestFocus();
	}

	public void runGameEngine() {
		gameEngine.start();
	}

	public MultiPlayerGameEngine getMultiPlayerGameEngine() {
		return multiPlayerGameEngine;
	}

	public void MultiPlayerGameFinish(long score, boolean isSinglePlayer) {
		if (isSinglePlayer) {
			gameFinish();
		} else {
			showMainMenu();
			new Thread(()->{
				JOptionPane.showMessageDialog(null, "Your Score is " + score, "GameOver", JOptionPane.INFORMATION_MESSAGE);
				
			}).start();
			getPlayingAccount();
			stopClientPlayer();
		}
	}

	public Class getRandomFeature(FeatureEnum feature) {
		return gameEngine.getGalaxyWorld().getHandlerOfEnemyAndChicken().getRandomFeature(feature);
	}

	public void addNewFeature(Class newFeature) {
		gameEngine.getGalaxyWorld().getHandlerOfEnemyAndChicken().addNewFeature(newFeature);
	}

	public PlayerTask getSituationOfGame() {
		return gameEngine.getWhichSituation();
	}

}
