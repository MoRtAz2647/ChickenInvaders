package ServerPackage;

import java.awt.List;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import com.sun.security.ntlm.Server;

import Controllers.MyAdminister;

public class Connecter extends Thread {

	private int port;
	private ServerSocket serverSocket;
	private boolean isServerRun = false;

	public Connecter(int port) {
		this.port = port;
		try {
			serverSocket = new ServerSocket(this.port);

			isServerRun = true;
			start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Sorry! We Can't Create Server", "ServerError",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public boolean isServerRun() {
		return isServerRun;
	}

	@Override
	public void run() {
		try {

			a: while (true) {
				if (MyAdminister.getInstance().getMaxPlayer() > MyAdminister.getInstance().getGalaxyWorld().getPlayers()
						.size() || MyAdminister.getInstance().isPlayingSinglePlayer())
					MyAdminister.getInstance().requestToJoinToMultiPlayer(serverSocket.accept());

			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Sorry! Server Disconnected.", "ServerError",
					JOptionPane.ERROR_MESSAGE);
			}
	}

	public void stopServer() {
		try {
			if (serverSocket != null) {
				serverSocket.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop();
	}

}
