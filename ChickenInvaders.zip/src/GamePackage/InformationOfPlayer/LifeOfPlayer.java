package GamePackage.InformationOfPlayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.Serializable;

import Controllers.MyAdminister;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class LifeOfPlayer implements Updatable, Paintable, Serializable {

	private int life = 5;
	private boolean isPossibleToContinue =true;
	
	
	public LifeOfPlayer() {
	}

	@Override
	public void update() {
		
	}

	@Override
	public void paint(Graphics2D g) {
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public void increaseLife() {
		life++;
	}

	public void decreaseLife() {
		life--;
	}

	public boolean isPossibleToContinue() {
		return isPossibleToContinue;
	}

	public void setIsPossibleToContinue(boolean isPossibleToContinue) {
		this.isPossibleToContinue = isPossibleToContinue;
	}

}
