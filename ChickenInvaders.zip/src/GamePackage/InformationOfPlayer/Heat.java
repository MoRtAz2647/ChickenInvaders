
package GamePackage.InformationOfPlayer;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.TransferHandler.TransferSupport;

import com.google.gson.Gson;

import BulletPackage.LinearBullet;
import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class Heat implements Paintable, Updatable, Serializable {

	private GasBoiling gasBoiling;
	private boolean isGasCreated = false;

	private double degreeHeat = 0;
	private double maxHeat = 100;

	private boolean boiling = false;
	private long lastBoiling = 0;

	private boolean degreeIncreasing;
	private double veloctyDegreeIncreasing = 15;
	private long lastCoolDown = 0;
	private double veloctyDegreeDecreasing = -10;

	private int id;

	public Heat(int id) {
		this.id = id;
		initialize();
	}

	private void initialize() {

	}

	
	
	public double getVeloctyDegreeIncreasing() {
		return veloctyDegreeIncreasing;
	}

	public void setVeloctyDegreeIncreasing(double veloctyDegreeIncreasing) {
		this.veloctyDegreeIncreasing = veloctyDegreeIncreasing;
	}

	public double getVeloctyDegreeDecreasing() {
		return veloctyDegreeDecreasing;
	}

	public void setVeloctyDegreeDecreasing(double veloctyDegreeDecreasing) {
		this.veloctyDegreeDecreasing = veloctyDegreeDecreasing;
	}

	@Override
	public void paint(Graphics2D g) {

		if (gasBoiling != null && isGasCreated) {
			gasBoiling.paint(g);
		} else {
			gasBoiling = null;
		}
	}

	@Override
	public void update() {
		if (!boiling) {
			if (System.currentTimeMillis() - lastCoolDown > 250) {
				lastCoolDown = System.currentTimeMillis();
				degreeHeat += veloctyDegreeDecreasing;
			}
			if (degreeIncreasing) {
				degreeHeat += LinearBullet.getVeloctyOfHeatIncreasing(MyAdminister.getInstance().getPlayer(id)
						.getInformationOfPlayer().getPowerOfBullet().getTypeOfBullet(), veloctyDegreeIncreasing);
				setDegreeIncreasing(false);
			}
			if (degreeHeat < 0) {
				degreeHeat = 0;
			}
			if (degreeHeat >= maxHeat) {
				boiling = true;
				createGasBoiling();
				playingSoundBoiling();
				degreeHeat = maxHeat;
				lastBoiling = System.currentTimeMillis();
			}
		} else {
			if (System.currentTimeMillis() - lastBoiling > 500) {
				lastBoiling = System.currentTimeMillis();
				degreeHeat -= (int) (25 / 2);
			}
			if (degreeHeat <= 0) {
				degreeHeat = 0;
				boiling = false;
			}

		}
		if (gasBoiling != null && isGasCreated) {
			gasBoiling.update();
		}
	}

	private void createGasBoiling() {
		isGasCreated = true;
		gasBoiling = new GasBoiling(id);

	}

	private void playingSoundBoiling() {

		try {
			Clip OverHeat = AudioSystem.getClip();
			OverHeat.open(MyObjectCollection.getInstance().getSound("OverHeat"));
			OverHeat.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void setDegreeIncreasing(boolean b) {
		degreeIncreasing = b;
	}

	public boolean isBoiling() {
		return boiling;
	}

	public void increaseMaxHeat() {
		maxHeat += 15;
	}

	public double getMaxHeat() {
		return maxHeat;
	}
	public double getDegreeHeat() {
		return degreeHeat;
	}

}

class GasBoiling implements Paintable, Destroyable, Serializable, Updatable {

	private transient ArrayList<BufferedImage> gases = new ArrayList<>();
	private int whichImagePaint = 0;
	private long lastChangeOfGas = 0;

	private int width;
	private int height;

	private boolean isDestroy;

	private int id;
	private Point locationSpaceShip;
	
	
	public GasBoiling(int id) {

		this.id = id;
		isDestroy = false;

		locationSpaceShip = MyAdminister.getInstance().getPlayer(id).getSpaceShip().getLocation();
		
		
//		x = (int) MyAdminister.getInstance().getLocationSpaceShip().getX() - 20;
//		y = (int) MyAdminister.getInstance().getLocationSpaceShip().getY();
		width = 100;
		height = 100;

		setImages();
	}

	private void setImages() {
		gases = new ArrayList<>();
		for (int i = 1; i <= 6; i++) {
			gases.add((BufferedImage) MyObjectCollection.getInstance().getImage("Gas" + i));
		}
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void paint(Graphics2D g) {
		if (!isDestroy) {
			g.drawImage(getImage(),
					(int) locationSpaceShip.getX() - 15,
					(int) locationSpaceShip.getY(), width, height,
					null);
		}
	}

	private Image getImage() {
		if (gases == null) {
			setImages();
		}
		return gases.get(whichImagePaint);
	}

	@Override
	public void setDestroy() {
		isDestroy = true;

	}

	@Override
	public void update() {
		locationSpaceShip = MyAdminister.getInstance().getPlayer(id).getSpaceShip().getLocation();

		if (System.currentTimeMillis() - lastChangeOfGas >= 300) {
			lastChangeOfGas = System.currentTimeMillis();
			whichImagePaint++;
			if (whichImagePaint >= 5) {
				setDestroy();
			}
		}

	}

}
