package ListOfAddress;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

import javax.imageio.ImageIO;
import javax.print.attribute.standard.Media;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class MyObjectCollection {

	private static MyObjectCollection myHashMap;
	private HashMap<String, Object> myCollection;

	private MyObjectCollection() {
		load();
	}

	private void load() {
		myCollection = new HashMap<>();
		try {
			//////////////////////////////////////////////////////////////////////////////////////
			/////////// images
			myCollection.put("AddInClick", ImageIO.read(new File("Pictures/Buttons/AddInClick.png")));
			myCollection.put("AddOutClick", ImageIO.read(new File("Pictures/Buttons/AddOutClick.png")));
			myCollection.put("LetsPlayInClick", ImageIO.read(new File("Pictures/Buttons/LetsPlayInClick.png")));
			myCollection.put("LetsPlayOutClick", ImageIO.read(new File("Pictures/Buttons/LetsPlayOutClick.png")));
			myCollection.put("RemoveInClick", ImageIO.read(new File("Pictures/Buttons/RemoveInClick.png")));
			myCollection.put("RemoveOutClick", ImageIO.read(new File("Pictures/Buttons/RemoveOutClick.png")));

			myCollection.put("ContinueInClick", ImageIO.read(new File("Pictures/Buttons/ContinueInClick.png")));
			myCollection.put("ContinueOutClick", ImageIO.read(new File("Pictures/Buttons/ContinueOutClick.png")));
			myCollection.put("QuitInClick", ImageIO.read(new File("Pictures/Buttons/QuitInClick.png")));
			myCollection.put("QuitOutClick", ImageIO.read(new File("Pictures/Buttons/QuitOutClick.png")));
			myCollection.put("NewFeatureInClick", ImageIO.read(new File("Pictures/Buttons/NewFeatureInClick.png")));
			myCollection.put("NewFeatureOutClick", ImageIO.read(new File("Pictures/Buttons/NewFeatureOutClick.png")));

			myCollection.put("SettingInClick", ImageIO.read(new File("Pictures/Buttons/SettingInClick.png")));
			myCollection.put("SettingOutClick", ImageIO.read(new File("Pictures/Buttons/SettingOutClick.png")));
			myCollection.put("ScoresInClick", ImageIO.read(new File("Pictures/Buttons/ScoresInClick.png")));
			myCollection.put("ScoresOutClick", ImageIO.read(new File("Pictures/Buttons/ScoresOutClick.png")));
			myCollection.put("LoadGameInClick", ImageIO.read(new File("Pictures/Buttons/LoadGameInClick.png")));
			myCollection.put("LoadGameOutClick", ImageIO.read(new File("Pictures/Buttons/LoadGameOutClick.png")));
			myCollection.put("NewGameInClick", ImageIO.read(new File("Pictures/Buttons/NewGameInClick.png")));
			myCollection.put("NewGameOutClick", ImageIO.read(new File("Pictures/Buttons/NewGameOutClick.png")));
			myCollection.put("MultiPlayerInClick", ImageIO.read(new File("Pictures/Buttons/MultiPlayerInClick.png")));
			myCollection.put("MultiPlayerOutClick", ImageIO.read(new File("Pictures/Buttons/MultiPlayerOutClick.png")));
			myCollection.put("ExitInClick", ImageIO.read(new File("Pictures/Buttons/ExitInClick.png")));
			myCollection.put("ExitOutClick", ImageIO.read(new File("Pictures/Buttons/ExitOutClick.png")));
			
			myCollection.put("ServerInClick" , ImageIO.read(new File("Pictures/Buttons/ServerInClick.png")));
			myCollection.put("ServerOutClick" , ImageIO.read(new File("Pictures/Buttons/ServerOutClick.png")));
			myCollection.put("ClientInClick" , ImageIO.read(new File("Pictures/Buttons/ClientInClick.png")));
			myCollection.put("ClientOutClick" , ImageIO.read(new File("Pictures/Buttons/ClientOutClick.png")));
			myCollection.put("StartInClick", ImageIO.read(new File("Pictures/Buttons/StartInClick.png")));
			myCollection.put("StartOutClick", ImageIO.read(new File("Pictures/Buttons/StartOutClick.png")));
 
			myCollection.put("ControlsInClick", ImageIO.read(new File("Pictures/Buttons/ControlsInClick.png")));
			myCollection.put("ControlsOutClick", ImageIO.read(new File("Pictures/Buttons/ControlsOutClick.png")));
			myCollection.put("TuneInClick", ImageIO.read(new File("Pictures/Buttons/TuneInClick.png")));
			myCollection.put("TuneOutClick", ImageIO.read(new File("Pictures/Buttons/TuneOutClick.png")));
			myCollection.put("SoundsInClick", ImageIO.read(new File("Pictures/Buttons/SoundsInClick.png")));
			myCollection.put("SoundsOutClick", ImageIO.read(new File("Pictures/Buttons/SoundsOutClick.png")));
			myCollection.put("Log OutInClick", ImageIO.read(new File("Pictures/Buttons/Log OutInClick.png")));
			myCollection.put("Log OutOutClick", ImageIO.read(new File("Pictures/Buttons/Log OutOutClick.png")));
			myCollection.put("CreditsInClick", ImageIO.read(new File("Pictures/Buttons/CreditsInClick.png")));
			myCollection.put("CreditsOutClick", ImageIO.read(new File("Pictures/Buttons/CreditsOutClick.png")));
			myCollection.put("BackInClick", ImageIO.read(new File("Pictures/Buttons/BackInClick.png")));
			myCollection.put("BackOutClick", ImageIO.read(new File("Pictures/Buttons/BackOutClick.png")));

			myCollection.put("CheckInClick", ImageIO.read(new File("Pictures/CheckBox/CheckInClick.png")));
			myCollection.put("CheckOutClick", ImageIO.read(new File("Pictures/CheckBox/CheckOutClick.png")));

			myCollection.put("ChickenTitle", ImageIO.read(new File("Pictures/ChickenTitle.png")));
			myCollection.put("iconImage", ImageIO.read(new File("pictures/iconImage.png")));
			myCollection.put("SoundIcon", ImageIO.read(new File("Pictures/SoundIcon.png")));

			myCollection.put("Galaxy2", ImageIO.read(new File("Pictures/Galaxy2.jpg")));
			myCollection.put("GalaxyWorldBackground", ImageIO.read(new File("Pictures/GalaxyWorldBackground.jpg")));
			myCollection.put("GalaxyBackgroundPause", ImageIO.read(new File("Pictures/GalaxyBackgroundPause.jpg")));
			myCollection.put("GalaxyBackgroundMainMenu", ImageIO.read(new File("Pictures/MenuBackground.jpg")));
			myCollection.put("GalaxyBackgroundMainMenu2", ImageIO.read(new File("Pictures/MenuBackground2.jpg")));
			myCollection.put("GalaxyBackgroundMainMenu3", ImageIO.read(new File("Pictures/MenuBackground3.jpg")));
			myCollection.put("GalaxyBackgroundMainMenu4", ImageIO.read(new File("Pictures/MenuBackground4.jpg")));
			myCollection.put("GalaxyBackgroundAccount", ImageIO.read(new File("Pictures/GalaxyBackgroundAccount.jpg")));
			myCollection.put("BackgroundLoading", ImageIO.read(new File("Pictures/BackgroundLoading.png")));

			for (int i = 1; i <= 3; i++) {
				myCollection.put("Bullet" + i, ImageIO.read(new File("Pictures/Bullets/Bullet" + i + ".png")));
			}
			myCollection.put("SpaceShipCenter",
					ImageIO.read(new File("Pictures/SpaceShips/Classic/SpaceShipCenter.png")));
			myCollection.put("SpaceShipRight",
					ImageIO.read(new File("Pictures/SpaceShips/Classic/SpaceShipRight.png")));
			myCollection.put("SpaceShipLeft", ImageIO.read(new File("Pictures/SpaceShips/Classic/SpaceShipLeft.png")));

			for (int i = 1; i <= 8; i++) {
				for (int j = 1; j <= 4; j++) {
					myCollection.put("SpaceShip" + i + j,
							ImageIO.read(new File("Pictures/SpaceShips/" + i + "/" + j + ".png")));
				}
			}

			myCollection.put("ScoreAndHeatTab", ImageIO.read(new File("Pictures/Tabs/ScoreAndHeatTab.png")));
			myCollection.put("InformationOfPlayerTab",
					ImageIO.read(new File("Pictures/Tabs/InformationOfPlayerTab.png")));

			myCollection.put("KeyboardIcon", ImageIO.read(new File("Pictures/keyboardIcon.png")));
			myCollection.put("MouseIcon", ImageIO.read(new File("Pictures/MouseIcon.png")));

			for (int i = 1; i <= 14; i++) {
				myCollection.put("Bomb" + i, ImageIO.read(new File("Pictures/Bombs/" + i + ".png")));
			}

			for (int i = 1; i <= 4; i++) {
				myCollection.put("Blast" + i, ImageIO.read(new File("Pictures/Blast/" + i + ".png")));
			}
			for (int i = 1; i <= 6; i++) {
				myCollection.put("Gas" + i, ImageIO.read(new File("Pictures/Gas/" + i + ".png")));
			}

			myCollection.put("SpaceShipWithBomb", ImageIO.read(new File("Pictures/Bombs/SpaceShipWithBomb.png")));

			for (int j = 1; j <= 4; j++) {
				for (int i = 1; i <= 7; i++) {
					myCollection.put("Chicken" + j + "" + i,
							ImageIO.read(new File("Pictures/Chickens/" + j + "/" + i + ".png")));
				}
			}

			myCollection.put("Egg", ImageIO.read(new File("Pictures/Chickens/Egg.png")));

			myCollection.put("Fire", ImageIO.read(new File("Pictures/Boss/Fire.png")));
			
			myCollection.put("Boss" , ImageIO.read(new File("Pictures/Boss/1.png")));

			
			for (int i = 1; i <= 4; i++) {
				for (int j = 1; j <= 14; j++) {
					myCollection.put("Gift" + i + "" + j,
							ImageIO.read(new File("Pictures/PowerUps/Type/" + i + "/" + j + ".png")));
				}
			}
			
			for(int i=1 ; i<=25 ; i++) {
				myCollection.put("PowerUpLevel" + i, ImageIO.read(new File("Pictures/PowerUps/Level/" + i + ".png")));
			}
			
			for(int i=1 ; i<=5 ; i++) {
				myCollection.put("PowerUpHeat" + i, ImageIO.read(new File("Pictures/PowerUps/Heat/" + i + ".png")));
			}
			
			for(int i=1 ; i<=17 ; i++) {
				myCollection.put("Coin"+ i, ImageIO.read(new File("Pictures/Coins/" + i + ".png")));
			}
			
			for(int i=1 ; i<=29 ; i++) {
				myCollection.put("LoadBar" + i, ImageIO.read(new File("Pictures/LoadBar/" + i + ".png")));
			}
			
			

			////////////////////////////////////////////////////////////////////////////////////////
			//////////// sounds

			myCollection.put("FireSound", new File("Sounds/Fire.wav"));
			myCollection.put("OverHeat", new File("Sounds/OverHeat.wav"));
			myCollection.put("BlastSound", new File("Sounds/BlastSound.wav"));
			myCollection.put("ClickSound", new File("Sounds/ClickSound.wav"));
			myCollection.put("EngineSound", new File("Sounds/EngineSound.wav"));

			for (int i = 1; i <= 6; i++) {
				for (int j = 1; j <= 6; j++) {
					myCollection.put("BackgroundSound" + i + j,
							new File("Sounds/BackgroundSound/BackgroundSound" + i + j + ".wav"));
				}
			}

			myCollection.put("DamagingChicken", new File("Sounds/DamagingChicken.wav"));

			myCollection.put("InGameSound", new File("Sounds/InGame.wav"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static MyObjectCollection getInstance() {
		if (myHashMap == null) {
			myHashMap = new MyObjectCollection();
		}
		return myHashMap;
	}

	public AudioInputStream getSound(String key) {
		try {
			return AudioSystem.getAudioInputStream((File) myCollection.get(key));
		} catch (UnsupportedAudioFileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public Object getImage(String key) {

		return myCollection.get(key);

	}
}
