package GameListeners;

import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.PrintStream;
import java.util.Scanner;

import javax.swing.SwingUtilities;

import com.google.gson.Gson;

import ActionEnum.PlayerTask;
import Controllers.MyAdminister;
import InterfaceAble.BroadcastOfPlayerTask;
import InterfaceAble.CheckIfInGame;

public class BulletsListener
		implements MouseListener, MouseMotionListener, KeyListener, BroadcastOfPlayerTask, CheckIfInGame {

	private PrintStream printer;
	private boolean isSpectater;
	private Scanner reader;

	public BulletsListener(PrintStream printer, Scanner reader, boolean isSpectater) {
		this.isSpectater = isSpectater;
		this.printer = printer;
		this.reader = reader;
	}

	public void setIsSpectater(boolean isSpectater) {
		this.isSpectater = isSpectater;

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkIfTryingToShotBulletWithKeyboard(true, e);

	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkIfTryingToShotBulletWithKeyboard(false, e);
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkIfTryingToShotBulletWithMouse(true, e);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkIfTryingToShotBulletWithMouse(true, e);

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkIfTryingToShotBulletWithMouse(false, e);

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	private void checkIfTryingToShotBulletWithMouse(boolean b, MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e) && MyAdminister.getInstance().isPlayingWithMouse()) {
			PlayerTask playerTask = PlayerTask.ShootBullet;
			playerTask.setIsShootingBullet(b);
			send(playerTask, printer);
		}
	}

	private void checkIfTryingToShotBulletWithKeyboard(boolean b, KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_SPACE && !MyAdminister.getInstance().isPlayingWithMouse()) {
			PlayerTask playerTask = PlayerTask.ShootBullet;
			playerTask.setIsShootingBullet(b);
			send(playerTask, printer);
		}

	}

}
