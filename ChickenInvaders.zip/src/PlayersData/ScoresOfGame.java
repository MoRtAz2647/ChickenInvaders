package PlayersData;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.ArrayList;

import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class ScoresOfGame implements Paintable, Updatable {

	private static ScoresOfGame scoresOfGame;
	private ArrayList<PropertiesOfPlayer> propertiesOfPlayers = new ArrayList<>();

	private ScoresOfGame() {

	}

	public static ScoresOfGame getInstance() {
		if (scoresOfGame == null) {
			scoresOfGame = new ScoresOfGame();
		}
		return scoresOfGame;
	}

	@Override
	public void update() {
		propertiesOfPlayers = Players.getInstance().getPropertiesOfPlayer();
		sortPlayer();
	}

	private void sortPlayer() {
		for(int i=0 ; i<propertiesOfPlayers.size() ; i++) {
			a:for(int j=i+1 ; j<propertiesOfPlayers.size() ; j++) {
				if(propertiesOfPlayers.get(j).compareTo(propertiesOfPlayers.get(i)) > 0) {
					propertiesOfPlayers.add(i, propertiesOfPlayers.get(j));
					propertiesOfPlayers.remove(j+1);
				}
			}
		}
	}

	@Override
	public void paint(Graphics2D g) {
		g.setColor(Color.WHITE);

		paintTitle(g);
		
		g.setFont(new Font("Ariel", 0, 40));
		for (int i = 0; i < propertiesOfPlayers.size(); i++) {
			g.drawString((i + 1) + " - " + propertiesOfPlayers.get(i).getPlayer(), 500, i * 60 + 200);
			g.drawString(propertiesOfPlayers.get(i).toStringOfWaveAndScore(), 900, i * 60 + 200);
			g.drawString(propertiesOfPlayers.get(i).getTime(), 1350, i*60 + 200);
		}
	}

	private void paintTitle(Graphics2D g) {
		g.setFont(new Font("Ariel", 1, 45));
		g.drawString( "# - Player" , 500 ,  120);
		g.drawString(StringOfWaveAndScore(), 860,  120);
		
	}

	private String StringOfWaveAndScore() {
		String result = "";
		result += "Waves";
		for(int i = 1 ; i<= 8 ; i++) {
			result+= " ";
		}
		result += "Score";
		for(int i = 1 ; i<= 12 ; i++) {
			result+= " ";
		}
		result += "Time";
		return result;
	}

}
