package GamePackage.InformationOfPlayer;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.io.Serializable;

import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class InformationOfPlayer implements Updatable, Paintable, Serializable {

	private LifeOfPlayer lifeOfPlayer;
	private PowerOfBullet powerOfBullet;
	private BombsOfPlayer bombsOfPlayer;
	private ChickenLeg chickenLeg;

	private Score score;
	private Heat heat;

	private int id;

	public InformationOfPlayer(int id) {
		this.id = id;
		initialize();
	}

	private void initialize() {
		powerOfBullet = new PowerOfBullet(1, 0, 2);
		bombsOfPlayer = new BombsOfPlayer(id);
		chickenLeg = new ChickenLeg(id);
		lifeOfPlayer = new LifeOfPlayer();

		score = new Score();
		heat = new Heat(id);

	}

	public LifeOfPlayer getLifeOfPlayer() {
		return lifeOfPlayer;
	}

	public void setLifeOfPlayer(LifeOfPlayer lifeOfPlayer) {
		this.lifeOfPlayer = lifeOfPlayer;
	}

	public PowerOfBullet getPowerOfBullet() {
		return powerOfBullet;
	}

	public void setPowerOfBullet(PowerOfBullet powerOfBullet) {
		this.powerOfBullet = powerOfBullet;
	}

	public BombsOfPlayer getBombsOfPlayer() {

		return bombsOfPlayer;
	}

	public void setBombsOfPlayer(BombsOfPlayer bombsOfPlayer) {
		this.bombsOfPlayer = bombsOfPlayer;
	}

	public ChickenLeg getChickenLeg() {
		return chickenLeg;
	}

	public void setChickenLeg(ChickenLeg chickenLeg) {
		this.chickenLeg = chickenLeg;
	}

	public Score getScore() {
		return score;
	}

	public void setScore(Score score) {
		this.score = score;
	}

	public Heat getHeat() {
		return heat;
	}

	public void setDegreeIncreasing(boolean ifDegreeIncreasing) {
		heat.setDegreeIncreasing(ifDegreeIncreasing);
	}

	public boolean isBoiling() {
		return heat.isBoiling();
	}

	public void TryingToShotBombs(boolean isTrying) {
		bombsOfPlayer.TryingToShotBombs(isTrying);
	}

	public void increaseBomb() {
		bombsOfPlayer.increaseBomb();
	}

	@Override
	public void paint(Graphics2D g) {
		bombsOfPlayer.paint(g);
		heat.paint(g);

	}

	@Override
	public void update() {

		powerOfBullet.update();
		chickenLeg.update();
		bombsOfPlayer.update();
		lifeOfPlayer.update();

		score.update();
		heat.update();
	}

}
