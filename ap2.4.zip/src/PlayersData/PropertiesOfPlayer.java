package PlayersData;

import java.io.Serializable;

public class PropertiesOfPlayer implements Serializable{

	private String player = "";
	private int wavesPlay;
	private long howMuchTimeTake;
	private long score;

	private int hours;
	private int minutes;
	private int seconds;
	private int days;

	public PropertiesOfPlayer(String player, int wavesPlay, long score, long howMuchTimeTake) {
		this.player = player;
		this.wavesPlay = wavesPlay;
		this.howMuchTimeTake = howMuchTimeTake;
		this.score = score;

		countTime();
	}

	private void countTime() {
		days = (int) (howMuchTimeTake / 36000000 / 24);
		hours = (int) (howMuchTimeTake / 3600000);
		minutes = (int) ((howMuchTimeTake / 1000 - hours * 3600) / 60);
		seconds = (int) (howMuchTimeTake / 1000 - 3600 * hours - 60 * minutes);
	}

	public String getTime() {
		String result = "";
		if(days < 10) {
			result+=0;
		}
		result+= days + ":";
		if (hours < 10) {
			result += 0;
		}
		result += hours + ":";
		if (minutes < 10) {
			result += 0;

		}
		result += minutes + ":";
		if (seconds < 10) {
			result += 0;

		}
		result += seconds;
		return result;
	}

	public long getScore() {
		return score;
	}

	public void setScore(long score) {
		this.score = score;
	}

	public String getPlayer() {
		return player;
	}

	public void setPlayer(String player) {
		this.player = player;
	}

	public int getWavesPlay() {
		return wavesPlay;
	}

	public void setWavesPlay(int wavesPlay) {
		this.wavesPlay = wavesPlay;
	}

	public long getHowMuchTimeTake() {
		return howMuchTimeTake;
	}

	public void setHowMuchTimeTake(long howMuchTimeTake) {
		this.howMuchTimeTake = howMuchTimeTake;
	}

	public int compareTo(PropertiesOfPlayer player) {
		if (player.getWavesPlay() != getWavesPlay()) {
			if (player.getWavesPlay() > getWavesPlay()) {
				return -1;
			} else {
				return 1;
			}
		} else {
			if (player.getScore() != getScore()) {
				if (player.getScore() > getScore()) {
					return -1;
				} else {
					return 1;
				}
			} else {
				if (player.getHowMuchTimeTake() != getHowMuchTimeTake()) {
					if (player.getHowMuchTimeTake() > getHowMuchTimeTake()) {
						return -1;
					} else {
						return 1;
					}

				} else {
					return -getPlayer().compareTo(player.getPlayer());
				}
			}
		}

	}

	public String toStringOfWaveAndScore() {
		String result = "";

		if (wavesPlay < 10) {
			result += "0";
		}

		result += wavesPlay;

		for (int i = 1; i <= 15; i++) {
			result += " ";
		}

		result += score;

//		for(int i=1 ; i<= 15 - Long.toString(score).length() ; i++) {
//			result += " ";
//		}
//		
//		result += days+ ":" + hours + ":" + minutes + ":" + seconds;
		return result;
	}
}
