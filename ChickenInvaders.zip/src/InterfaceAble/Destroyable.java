package InterfaceAble;

public interface Destroyable {
	public boolean isDestroy();
	public void setDestroy();
}
