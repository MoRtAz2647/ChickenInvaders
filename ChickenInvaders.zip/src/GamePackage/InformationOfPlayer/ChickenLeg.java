package GamePackage.InformationOfPlayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.Serializable;

import Controllers.MyAdminister;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;

public class ChickenLeg implements Updatable, Paintable, Movable, Serializable {

	private int chickenLegs = 0;
	private int id;

	public ChickenLeg(int id) {
		this.id = id;
	}

	@Override
	public void update() {
		if (chickenLegs >= 50) {
			chickenLegs -= 50;
			MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().increaseBomb();
		}
	}

	@Override
	public void paint(Graphics2D g) {
	}

	@Override
	public void move() {

	}

	public int getNumberOfChicken() {
		return chickenLegs;
	}

}
