package InterfaceAble;

public interface Updatable {
	public void update();
}
