package Features;

import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import sun.awt.www.content.image.gif;

public class Features implements Updatable, Paintable , Serializable {

	private CopyOnWriteArrayList<Gift> gifts = new CopyOnWriteArrayList<>();
	private CopyOnWriteArrayList<PowerUpsOfHeat> heats = new CopyOnWriteArrayList<>();
	private CopyOnWriteArrayList<PowerUpsOfLevel> levels = new CopyOnWriteArrayList<>();
	private CopyOnWriteArrayList<Coin> coins = new CopyOnWriteArrayList<>();

	public Features() {

	}

	@Override
	public void paint(Graphics2D g) {
		for (Coin coin : coins) {
			coin.paint(g);
		}
		for (PowerUpsOfHeat heat : heats) {
			heat.paint(g);
		}
		for (PowerUpsOfLevel level : levels) {
			level.paint(g);
		}
		for (Gift gift : gifts) {
			gift.paint(g);
		}
	}

	@Override
	public void update() {
		for (Coin coin : coins) {
			coin.update();
			coin.move();
			if (coin.isDestroy()) {
				coins.remove(coin);
			}
		}
		for (PowerUpsOfHeat heat : heats) {
			heat.update();
			heat.move();
			if (heat.isDestroy()) {
				heats.remove(heat);
			}
		}
		for (PowerUpsOfLevel level : levels) {
			level.update();
			level.move();
			if (level.isDestroy()) {
				levels.remove(level);
			}
		}
		for (Gift gift : gifts) {
			gift.update();
			gift.move();
			if (gift.isDestroy()) {
				gifts.remove(gift);
			}
		}
	}

	private void chickenDestroyed(double x, double y) {
		if (Math.random() <= 0.06) {
			coins.add(new Coin(x - 10, y + 10));
		}
		double probablty = Math.random();
		if (probablty <= 0.01) {
			levels.add(new PowerUpsOfLevel(x + 10, y - 10));
		} else if (probablty <= 0.03) {
			heats.add(new PowerUpsOfHeat(x + 10, y - 10));
		} else if (probablty <= 0.06) {
			gifts.add(new Gift(x + 10, y - 10, (int) (Math.random() * 4) + 1));
		}
	}

	public void BossDestroyed(double x, double y) {
		for (int i = 1; i <= 5; i++) {
			double probablty = Math.random();
			if (probablty <= 0.01) {
				levels.add(new PowerUpsOfLevel(x - i * 50, y - i * 50));
			} else if (probablty <= 0.03) {
				heats.add(new PowerUpsOfHeat(x + i * 50, y - i * 50));
			} else {
				gifts.add(new Gift(x + i * 50, y - i * 50, (int) (Math.random() * 3) + 1));
			}

		}
	}

	public void getPointsThrowGift(CopyOnWriteArrayList<Point> wherePosibleThrowGift) {
		synchronized (wherePosibleThrowGift) {

			for (Point point : wherePosibleThrowGift) {
				chickenDestroyed(point.getX(), point.getY());
			}
		}
	}

}
