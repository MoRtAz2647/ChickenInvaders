package ServerPackage;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.net.Socket;
import java.util.Scanner;

import javax.swing.JOptionPane;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.JsonAdapter;

import ActionEnum.PlayerTask;
import Controllers.MyAdminister;
import GameListeners.BombListener;
import GameListeners.BulletsListener;
import GameListeners.CheatListener;
import GameListeners.SpaceShipListener;
import GameListeners.ToolKeyListener;
import GamePackage.GalaxyWorld;
import GamePackage.PausePanel;
import GamePackage.Player;
import GamePackage.WaitingPanel;
import GamePackage.Tabs.InformationOfPlayerTab;
import GamePackage.Tabs.ScoreAndHeatTab;
import GroupChicken.OriginalGroupChicken;
import Tool.AbstractElementAdapter;
import Tool.SuperGameEnginePanel;
import Tool.SuperGameEngineThread;

public class MultiPlayerGameEngine extends SuperGameEnginePanel {

	private transient SpaceShipListener spaceShipListener;
	private transient BulletsListener bulletsListener;
	private transient BombListener bombListener;
	private transient CheatListener cheatListener;
	private transient ToolKeyListener toolKeyListener;

	private transient InformationOfPlayerTab informationOfPlayerTab;
	private transient ScoreAndHeatTab scoreAndHeatTab;

	private transient PlayerTask whichPanelPaint;

	private Gson gson;

	private Socket socket;
	private PrintStream printer;
	private Scanner reader;

	private boolean isSpectater;

	private String playerName;
	private int id;

	public MultiPlayerGameEngine(String playerName, String ip, int port, boolean isSpectater) {
		try {
			socket = new Socket(ip, port);

			this.playerName = playerName;
			id = socket.getLocalPort();

			printer = new PrintStream(socket.getOutputStream());
			reader = new Scanner(socket.getInputStream());
			printer.println(playerName);

			if (Boolean.parseBoolean(reader.nextLine())) {
				id = 0;
			}

			printer.println(id);
			printer.println(isSpectater);

			this.isSpectater = true;

			whichPanelPaint = PlayerTask.WaitingPanel;

			informationOfPlayerTab = new InformationOfPlayerTab(id);
			scoreAndHeatTab = new ScoreAndHeatTab(id);

//			GsonBuilder gsonBilder = new GsonBuilder();
//			gsonBilder.registerTypeAdapter(Object.class, new AbstractElementAdapter<Object>());
//			gson = gsonBilder.create();
			gson = new Gson();

		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Sorry! We Can't Find Server", "ServerError",
					JOptionPane.ERROR_MESSAGE);
		}

		initialize();

		new Thread(() -> {
			while (true) {
				repaint();
			}
		}).start();

		setVisible(true);
	}

	private void initialize() {
		setBackground(Color.BLACK);

		spaceShipListener = new SpaceShipListener(printer, reader ,isSpectater);
		bombListener = new BombListener(printer, reader , isSpectater);
		bulletsListener = new BulletsListener(printer, reader ,isSpectater);
		cheatListener = new CheatListener(printer, reader , isSpectater);
		toolKeyListener = new ToolKeyListener(printer);

		addMouseMotionListener(spaceShipListener);
		addMouseListener(spaceShipListener);
		addMouseListener(bulletsListener);
		addMouseMotionListener(bulletsListener);
		addMouseListener(bombListener);
		addMouseMotionListener(bombListener);

		addKeyListener(spaceShipListener);
		addKeyListener(bulletsListener);
		addKeyListener(bombListener);
		addKeyListener(cheatListener);
		addKeyListener(toolKeyListener);

	}

	@Override
	public void render(Graphics2D g) {
		try {
			synchronized (printer) {
//			synchronized (printer) {
//			}
//			synchronized (reader) {
//				gson.fromJson(reader.nextLine(), GalaxyWorld.class).paint(g);
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
				PlayerTask playerTask = PlayerTask.Paint;
				objectOutputStream.writeObject(playerTask);
				objectOutputStream.writeObject(playerTask.getCheat());
				objectOutputStream.writeObject(playerTask.getCheat().getTypeOfBullet());
				objectOutputStream.writeObject(playerTask.getDirection());
				objectOutputStream.writeObject(playerTask.getIsShootingBullet());
				objectOutputStream.writeObject(playerTask.getX());
				objectOutputStream.writeObject(playerTask.getY());
				printer.println(gson.toJson(byteArrayOutputStream.toByteArray()));
				
				PlayerTask whichPanelPaint = gson.fromJson(reader.nextLine(), PlayerTask.class);
				switch (whichPanelPaint) {
				case GamePanel:
//					if(whichPanelPaint != playerTask) {
//						MyAdminister.getInstance().showClientPanel();;
//					}
					ObjectInputStream objectInputStream = new ObjectInputStream(
							new ByteArrayInputStream(new Gson().fromJson(reader.nextLine(), byte[].class)));

					GalaxyWorld galaxyWorld = (GalaxyWorld) objectInputStream.readObject();
					if (!(galaxyWorld.getPlayer(id) == null)) {
						setSpectater(false);
					} else {
						setSpectater(true);
					}
					galaxyWorld.paint(g);
					if (!isSpectater) {
						informationOfPlayerTab.paint(g, galaxyWorld.getPlayer(id));
						scoreAndHeatTab.paint(g, galaxyWorld.getPlayer(id));
					}

					break;
				case WaitingPanel:
//					if(whichPanelPaint != playerTask) {
//						MyAdminister.getInstance().showClientPanel();
//					}
					String waitingString = reader.nextLine();
					WaitingPanel waitingPanel = gson.fromJson(waitingString, WaitingPanel.class);

					waitingPanel.paint(g);

					break;

				case PauseGame:
					if (this.whichPanelPaint != PlayerTask.PauseGame) {
						
						MyAdminister.getInstance().showPausePanel(printer);
					}
					break;

				case Quit:
					MyAdminister.getInstance().MultiPlayerGameFinish(Long.parseLong(reader.nextLine()),
							Boolean.parseBoolean(reader.nextLine()));
					break;
				default:

					break;
				}
				this.whichPanelPaint = whichPanelPaint;
			}
		} catch (Exception e) {
			endConnection();
		}
	}

	private void endConnection() {
		reader.close();
		printer.close();
		interrupt();
		MyAdminister.getInstance().showMainMenu();
		new Thread(() -> {
			JOptionPane.showMessageDialog(null, "Sorry! Connection Lost :)", "ConnectionError",
					JOptionPane.ERROR_MESSAGE);

		}).start();
	}

	private void setSpectater(boolean b) {
		isSpectater = b;
		bombListener.setIsSpectater(b);
		bulletsListener.setIsSpectater(b);
		spaceShipListener.setIsSpectater(b);
		cheatListener.setIsSpectater(b);
	}

	public PlayerTask getWhichPanelPaint() {
		return whichPanelPaint;
	}

	public void setWhichPanelPaint(PlayerTask whichPanelPaint) {
		this.whichPanelPaint = whichPanelPaint;
	}

}
