package Buttons.MainMenuPanel;

import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class NewGameButton extends OriginalButton {

	public NewGameButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("NewGameInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("NewGameOutClick"),
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 6 - 25 * 5, 400, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().createGalaxyWorld(true, true, 1, 4, 4);
			MyAdminister.getInstance().runServerConnecter(8888);
			MyAdminister.getInstance().createClientPlayer("127.0.0.1", 8888, false);
			MyAdminister.getInstance().showGalaxyWorld();
		}
	}
}
