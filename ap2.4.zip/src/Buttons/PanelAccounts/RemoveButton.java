package Buttons.PanelAccounts;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class RemoveButton extends OriginalButton {
	public RemoveButton() throws Exception {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("RemoveInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("RemoveOutClick"),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 + 200),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - 200 - 100), 500, 100);

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().removePlayer();
			/////////////////////////
			// name ro badan get kon
		}
	}

}
