package InterfaceAble;

import java.awt.Graphics2D;

public interface Paintable {
	void paint(Graphics2D g);
}
