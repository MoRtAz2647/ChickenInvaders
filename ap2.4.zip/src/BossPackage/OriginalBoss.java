package BossPackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;

import BulletPackage.Bullet;
import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class OriginalBoss implements Updatable, Movable, Paintable, Destroyable, Serializable {

	private int width = 400;
	private int height = 400;
	private double x;
	private double y;

	private boolean isDestroy;

	private double hp;
	private int levelPlayerPlay;

	private CopyOnWriteArrayList<Fire> fires = new CopyOnWriteArrayList<>();

	public OriginalBoss(int levelPlayerPlay) {

		hp = 250 * levelPlayerPlay;
		this.levelPlayerPlay = levelPlayerPlay;

	}

	@Override
	public void paint(Graphics2D g) {
		for (int i = 0; i < fires.size(); i++) {
			fires.get(i).paint(g);
		}
		g.drawImage((Image) MyObjectCollection.getInstance().getImage("Boss"), (int) x, (int) y, width, height, null);

		drawBarLife(g);

	}

	private void drawBarLife(Graphics2D g) {
		GradientPaint gradientPaintSide = new GradientPaint(
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 250), 75, Color.GREEN,
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2), 75, Color.RED);
		g.setPaint(gradientPaintSide);

		g.drawRect((int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 250), 75, 500, 25);
		g.fillRect((int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 250), 75,
				(int) (hp / levelPlayerPlay * 2), 25);

	}

	@Override
	public void move() {

		for (int i = 0; i < fires.size(); i++) {
			fires.get(i).move();
		}

	}

	@Override
	public void update() {

		for (Fire fire : fires) {
			fire.update();
			if (fire.isDestroy()) {
				fires.remove(fire);
			}
		}

		for (Player player : MyAdminister.getInstance().getPlayers()) {
			if (player.getInformationOfPlayer().getBombsOfPlayer().isBlasting()) {
				hp -= 50;
			}

			if (new Rectangle((int) x, (int) y, width, height).intersects(player.getSpaceShip().getRectangle())
					&& !player.getSpaceShip().isDestroy() && !player.getSpaceShip().isHavingShield()) {
				hp -= 20;
				player.getSpaceShip().setDestroy();
			}
			for (Bullet bullet : player.getBullets()) {

				if (bullet.isIntersect(new Rectangle((int) x, (int) y, width, height), 0)) {
					hp -= bullet.getPower();
					bullet.setDestroy();

				}
			}
		}
		if (hp <= 0) {
			isDestroy = true;
		}
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	public Point getLocation() {
		return new Point((int) x, (int) y);
	}

	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public Dimension getDimension() {
		return new Dimension(width, height);
	}

	public CopyOnWriteArrayList<Fire> getFires() {
		return fires;
	}

	public Point getMiddle() {
		return new Point((int) (x + width / 2), (int) (y + height / 2));
	}
}
