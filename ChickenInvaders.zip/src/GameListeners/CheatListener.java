package GameListeners;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.PrintStream;
import java.util.Scanner;

import com.google.gson.Gson;

import ActionEnum.CheatEnum;
import ActionEnum.PlayerTask;
import Controllers.MyAdminister;
import InterfaceAble.BroadcastOfPlayerTask;
import InterfaceAble.CheckIfInGame;

public class CheatListener implements KeyListener, BroadcastOfPlayerTask, CheckIfInGame {

	private PrintStream printer;
	private boolean isSpectater;
	private Scanner reader;

	public CheatListener(PrintStream printer, Scanner reader, boolean isSpectater) {

		this.printer = printer;
		this.isSpectater = isSpectater;
		this.reader = reader;

	}

	public void setIsSpectater(boolean isSpectater) {
		this.isSpectater = isSpectater;
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer)) {
			PlayerTask playerTask = PlayerTask.Cheating;
			if (e.getKeyCode() == KeyEvent.VK_F1) {
				playerTask.setCheat(CheatEnum.Bomb);
				send(playerTask, printer);
			} else if (e.getKeyCode() == KeyEvent.VK_F2) {
				playerTask.setCheat(CheatEnum.Life);
				send(playerTask, printer);

			} else if (e.getKeyCode() == KeyEvent.VK_F3) {
				playerTask.setCheat(CheatEnum.Shield);
				send(playerTask, printer);

			} else if (e.getKeyCode() == KeyEvent.VK_F4) {
				playerTask.setCheat(CheatEnum.LevelOfBullet);
				send(playerTask, printer);
			} else if (e.getKeyCode() >= KeyEvent.VK_1 && e.getKeyCode() <= KeyEvent.VK_4) {
				CheatEnum cheat = CheatEnum.TypeOfBullet;
				cheat.setTypeOfBullet(e.getKeyCode() - (KeyEvent.VK_0));
				playerTask.setCheat(cheat);
				send(playerTask, printer);
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

}
