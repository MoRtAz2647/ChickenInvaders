package GroupChicken;

import java.awt.Point;

import ChickenPackage.Chicken;
import ChickenPackage.ChickenLinear;
import Controllers.MyAdminister;

public class SuicideChickens extends OriginalGroupChicken {

	private long whenAttack;

	private int whichAttack = 20;
	private int whichPlayer = 0;

	public SuicideChickens(int levelPlayerPlay) {
		whenAttack = System.currentTimeMillis();
		for (int i = 0; i < 10; i++) {
			getChickens().add(new ChickenLinear(levelPlayerPlay, -200, -200));
		}
	}


	@Override
	public void update() {
		super.update();
		if (System.currentTimeMillis() - whenAttack >= 5000) {
			whichAttack = (int) (Math.random() * getChickens().size());
			whichPlayer = (int) (Math.random() * MyAdminister.getInstance().getPlayers().size()) ;
			whichPlayer = MyAdminister.getInstance().getPlayers().get(whichPlayer).getId();
		}
		for (Chicken chicken : getChickens()) {
			int i = getChickens().indexOf(chicken);
			if (i == whichAttack) {
				if (System.currentTimeMillis() - whenAttack >= 5000) {
					whenAttack = System.currentTimeMillis();
					
					chicken
							.setWhereMustBe(MyAdminister.getInstance().getPlayer(whichPlayer).getSpaceShip().getLocation().getX() , 
									MyAdminister.getInstance().getPlayer(whichPlayer).getSpaceShip().getLocation().getY());
					getChickens().get(i).setVelocty(3);
					
						
					

				}
			} else {
				chicken.setVelocty(1);
				if (chicken.isInPLace()
						&& System.currentTimeMillis() - chicken.getWhenBeInPlace() >= 3000) {
					chicken.setWhereMustBe(
							(int) (Math.random() * (MyAdminister.getInstance().getSizeOfFrame().getWidth() - 150)),
							(int) (Math.random() * (MyAdminister.getInstance().getSizeOfFrame().getHeight() - 150)));
				}
			}
		}

	}

	
}
