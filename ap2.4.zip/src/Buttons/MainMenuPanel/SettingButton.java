package Buttons.MainMenuPanel;

import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class SettingButton extends OriginalButton {

	public SettingButton() {
		super((BufferedImage)MyObjectCollection.getInstance().getImage("SettingInClick"),
				(BufferedImage)MyObjectCollection.getInstance().getImage("SettingOutClick"), 
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50,
				(int)MyAdminister.getInstance().getSizeOfFrame().getHeight()-50 - 100*2 - 25, 400, 100);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if(rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().showMainSettingPanel();
		}
	}
}
