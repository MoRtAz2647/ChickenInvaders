package Buttons.MainMenuPanel;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.Selectable;
import ListOfAddress.MyObjectCollection;
import PlayersData.ScoresOfGame;

public class ScoresButton extends OriginalButton implements Selectable {

	private boolean isSelected = false;

	public ScoresButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("ScoresInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("ScoresOutClick"),
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 3 - 25 * 2, 400, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().setSelectedOfMenuButton(false);
			setSelected(!isSelected);
		}

	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);

		if (isSelected) {
			ScoresOfGame.getInstance().paint(g);
		}
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
		ScoresOfGame.getInstance().update();
	}
}
