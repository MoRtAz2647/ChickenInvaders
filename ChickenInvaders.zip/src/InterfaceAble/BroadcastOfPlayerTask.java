package InterfaceAble;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.lang.invoke.DirectMethodHandle.Interface;

import com.google.gson.Gson;

import ActionEnum.PlayerTask;

public interface BroadcastOfPlayerTask {
	default void send(PlayerTask playerTask, PrintStream printer) {
		synchronized (printer) {
			try {
				BroadcastOfPlayerTask a = new BroadcastOfPlayerTask() {
					
					while(true) {
						Thread 
						
					}
				};
				
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
				objectOutputStream.writeObject(playerTask);
				objectOutputStream.writeObject(playerTask.getCheat());
				objectOutputStream.writeObject(playerTask.getCheat().getTypeOfBullet());
				objectOutputStream.writeObject(playerTask.getDirection());
				objectOutputStream.writeObject(playerTask.getIsShootingBullet());
				objectOutputStream.writeObject(playerTask.getX());
				objectOutputStream.writeObject(playerTask.getY());
				printer.println(new Gson().toJson(byteArrayOutputStream.toByteArray()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
