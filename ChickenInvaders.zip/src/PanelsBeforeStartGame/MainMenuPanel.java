package PanelsBeforeStartGame;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import Buttons.MainMenuPanel.*;
import Buttons.MultiPlayerButton.StartButton;
import Controllers.MyAdminister;
import InterfaceAble.Drawable;
import InterfaceAble.Paintable;
import ListOfAddress.MyObjectCollection;

public class MainMenuPanel extends JPanel implements Drawable {
	
	private BufferedImage backgroundOfMainMenu;
	
	private ExitButton exitButton;
	private LoadGameButton loadGameButton;
	private NewGameButton newGameButton;
	private ScoresButton scoreButton;
	private SettingButton settingButton;
	private MultiPlayerButton multiPlayer;
	
	public MainMenuPanel() {
		initialize();
	}

	
	private void initialize() {
		backgroundOfMainMenu = (BufferedImage) MyObjectCollection.getInstance().getImage("GalaxyBackgroundMainMenu2");
		
		
		exitButton =  new ExitButton();
		loadGameButton = new LoadGameButton();
		newGameButton = new NewGameButton();
		settingButton = new SettingButton();
		scoreButton = new ScoresButton();
		multiPlayer = new MultiPlayerButton();
		
		addMouseListener(exitButton);
		addMouseListener(loadGameButton);
		addMouseListener(newGameButton);
		addMouseListener(settingButton);
		addMouseListener(scoreButton);
		addMouseListener(multiPlayer);
		addMouseListener(multiPlayer.getClientButton());
		addMouseListener(multiPlayer.getServerButton());
		addMouseListener(StartButton.getInstance(true));
		
		addMouseMotionListener(exitButton);
		addMouseMotionListener(loadGameButton);
		addMouseMotionListener(newGameButton);
		addMouseMotionListener(settingButton);
		addMouseMotionListener(scoreButton);
		addMouseMotionListener(multiPlayer);
		addMouseMotionListener(multiPlayer.getClientButton());
		addMouseMotionListener(multiPlayer.getServerButton());
		addMouseMotionListener(StartButton.getInstance(true));
	}

	@Override
	protected void paintComponent(Graphics g) {
		render((Graphics2D) g);
		}
	@Override
	public void render(Graphics2D g) {
		g.drawImage(backgroundOfMainMenu, 0, 0,
			(int)MyAdminister.getInstance().getSizeOfFrame().getWidth(), 
			(int)MyAdminister.getInstance().getSizeOfFrame().getHeight(),null);
		
		exitButton.paint(g);
		loadGameButton.paint(g);
		newGameButton.paint(g);
		scoreButton.paint(g);
		settingButton.paint(g);
		multiPlayer.paint(g);
	}


	public ScoresButton getScoreButton() {
		return scoreButton;
	}


	public void setSelectedOfMenuButton(boolean b) {
		scoreButton.setSelected(b);
		multiPlayer.setSelected(b);
	}


	public void setSelectedOfServerAndClient(boolean b) {
		multiPlayer.setSelectedOfServerAndClient(b);
	}
	
}
