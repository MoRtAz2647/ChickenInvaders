package GroupChicken;

import java.awt.Point;

import ChickenPackage.Chicken;
import ChickenPackage.ChickenLinear;
import Controllers.MyAdminister;

public class CircleChickens extends OriginalGroupChicken {

	private double xCentre;
	private double yCentre;
	private boolean isInPlace;
	private int xCentreMustBe;
	private int yCentreMustBe;

	private double degreeOfFirst = 0;
	private long lastChange = 0;

	public CircleChickens(int levelPlayerPlay) {
		for (int i = 0; i < 35; i++) {
			getChickens().add(new ChickenLinear(levelPlayerPlay, -100, -100));
		}

		isInPlace = false;
		xCentre = 0;
		yCentre = 0;
		xCentreMustBe = (int) (Math.random() * MyAdminister.getInstance().getSizeOfFrame().getWidth());
		yCentreMustBe = (int) (Math.random() * MyAdminister.getInstance().getSizeOfFrame().getHeight());

	}

	@Override
	public void move() {
		super.move();
//		double speed = (Math.sqrt(Math.pow(xCentre - xCentreMustBe, 2) + Math.pow(yCentre - yCentreMustBe, 2)) < 2) ? 1: 1;
		if (xCentre != xCentreMustBe) {
			if (xCentre < xCentreMustBe) {
				xCentre += 0.5;
			} else {
				xCentre -= 0.5;
			}
		}
		if (yCentre != yCentreMustBe) {
			if (yCentre < yCentreMustBe) {
				yCentre += 0.5;
			} else {
				yCentre -= 0.5;
			}
		}
		
//		xCentre+= Math.cos(Math.atan2(yCentreMustBe- yCentre, xCentreMustBe- xCentre))*speed ;
//		yCentre+= Math.sin(Math.atan2(yCentreMustBe - yCentre, xCentreMustBe- xCentre))*speed ;
	}

	@Override
	public void update() {
		super.update();

		if (System.currentTimeMillis() - lastChange >= 30) {
			degreeOfFirst += 4;
			lastChange = System.currentTimeMillis();
		}

		if (xCentre == xCentreMustBe && yCentre == yCentreMustBe) {
			isInPlace = true;
		}

		if (isInPlace) {
			isInPlace = false;
			xCentreMustBe = (int) (Math.random() * MyAdminister.getInstance().getSizeOfFrame().getWidth());
			yCentreMustBe = (int) (Math.random() * MyAdminister.getInstance().getSizeOfFrame().getHeight());

		}

		for (Chicken chicken : getChickens()) {
			int i = getChickens().indexOf(chicken);
			if (i < 5) {
				chicken
						.setWhereMustBe(
								(int) (1.0 * 100
										* Math.cos((degreeOfFirst + 1.0 * i * 360 / (5)) * Math.PI
												/ 180)
										+ xCentre),
								(int) (1.0 * 100 * Math
										.sin((degreeOfFirst + 1.0 * i * 360 / (5)) * Math.PI / 180)
										+ yCentre));
				chicken.setVelocty(1.5);
			} else if (i < 15) {
				chicken
						.setWhereMustBe(
								(int) (1.0 * 200
										* Math.cos((degreeOfFirst + 1.0 * i * 360 / (10)) * Math.PI
												/ 180)
										+ xCentre),
								(int) (1.0 * 200 * Math
										.sin((degreeOfFirst + 1.0 * i * 360 / (10)) * Math.PI / 180)
										+ yCentre));
				chicken.setVelocty(1 * 2);
			} else {
				chicken
						.setWhereMustBe(
								(int) (1.0 * 300
										* Math.cos((degreeOfFirst + 1.0 * i * 360 / (getChickens().size() - 15)) * Math.PI
												/ 180)
										+ xCentre),
								(int) (1.0 * 300 * Math
										.sin((degreeOfFirst + 1.0 * i * 360 / (getChickens().size() - 15)) * Math.PI / 180)
										+ yCentre));
				chicken.setVelocty(1* 3);
			}
		}
	}

}
