package InterfaceAble;

public interface Selectable {
	public boolean isSelected();
	public void setSelected(boolean isSelected);
}
