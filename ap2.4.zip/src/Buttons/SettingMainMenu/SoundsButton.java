package Buttons.SettingMainMenu;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.Paintable;
import InterfaceAble.Selectable;
import ListOfAddress.MyObjectCollection;

public class SoundsButton extends OriginalButton implements Selectable {

	private boolean isSelected;

	public SoundsButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("SoundsInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("SoundsOutClick"),
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 4 - 25 * 3, 400, 100);
	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);
		if (isSelected()) {
			SoundsImage.getInstance().paint(g);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().setSelectedOfSettingButtons(false);
			setSelected(true);
		}
		if (isSelected) {
			SoundsImage.getInstance().checkIfSelectedSound(e);
		}
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;

	}
}

class SoundsImage implements Paintable {

	private static SoundsImage soundsImage;
	private BufferedImage soundBufferedimage;

	private int soundStartX;
	private int soundStartY;
	private int distanceInX;
	private int distanceInY;
	private int widthImage;
	private int heightImage;

	private SoundsImage() {
		initialize();
	}

	public void checkIfSelectedSound(MouseEvent e) {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				Rectangle rectangle = new Rectangle(soundStartX + i * distanceInX + i * widthImage,
						soundStartY + j * distanceInY + j * heightImage, widthImage, heightImage);
				if (rectangle.contains(e.getPoint())) {
					MyAdminister.getInstance().setBackgroundSound(i, j);
					MyAdminister.getInstance().setSelectedOfSettingButtons(false);
				}
			}
		}
	}

	public static SoundsImage getInstance() {
		if (soundsImage == null) {
			soundsImage = new SoundsImage();
		}
		return soundsImage;
	}

	private void initialize() {
		soundBufferedimage = (BufferedImage) MyObjectCollection.getInstance().getImage("SoundIcon");
		widthImage = 100;
		heightImage = 80;
		distanceInX = 50;
		distanceInY = 50;
		soundStartY = 100;//(int) ((MyAdminister.getInstance().getSizeOfFrame().getHeight() - heightImage) / 2);
		soundStartX = (int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 200);
	}

	@Override
	public void paint(Graphics2D g) {
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				g.drawImage(soundBufferedimage, soundStartX + i * distanceInX + i * widthImage,
						soundStartY + j * distanceInY + j * heightImage, widthImage, heightImage, null);
			}
		}
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
	}

}
