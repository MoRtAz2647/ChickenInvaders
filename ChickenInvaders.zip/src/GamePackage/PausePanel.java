package GamePackage;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.PrintStream;

import javax.swing.JPanel;

import Buttons.PausePanel.ContinueButton;
import Buttons.PausePanel.NewFeatureButton;
import Buttons.PausePanel.QuitButton;
import Controllers.MyAdminister;
import InterfaceAble.Drawable;
import InterfaceAble.Paintable;
import ListOfAddress.MyObjectCollection;

public class PausePanel extends JPanel implements Drawable {

	private static PausePanel pausePanel;
	
	private PrintStream printer;

	private BufferedImage backgroundPausePanel;

	private ContinueButton continueButton;
	private QuitButton quitButton;
	private NewFeatureButton newFeatureButton;

	private PausePanel() {
		backgroundPausePanel = (BufferedImage) MyObjectCollection.getInstance().getImage("GalaxyBackgroundPause");

		continueButton = new ContinueButton();
		quitButton = new QuitButton();
		newFeatureButton = new NewFeatureButton();
		
		addMouseListener(quitButton);
		addMouseListener(continueButton);
		addMouseListener(newFeatureButton);
		addMouseMotionListener(continueButton);
		addMouseMotionListener(quitButton);
		addMouseMotionListener(newFeatureButton);
		

	}

	public static PausePanel getInstance(PrintStream printer) {
		if (pausePanel == null) {
			pausePanel = new PausePanel();
		}
		pausePanel.setPrinter(printer);
		return pausePanel;
	}

	private void setPrinter(PrintStream printer) {
		this.printer = printer;
		continueButton.setPrinter(printer);
		quitButton.setPrinter(printer);
		newFeatureButton.setPrinter(printer);
	}

	@Override
	protected void paintComponent(Graphics g) {
		render((Graphics2D) g);
	}

	@Override
	public void render(Graphics2D g) {
		g.drawImage(backgroundPausePanel, 0, 0, (int) MyAdminister.getInstance().getSizeOfFrame().getWidth(),
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight(), null);
		continueButton.paint(g);
		quitButton.paint(g);
		newFeatureButton.paint(g);

	}

}
