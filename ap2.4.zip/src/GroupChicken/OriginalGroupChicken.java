package GroupChicken;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import ChickenPackage.Chicken;
import ChickenPackage.ChickenLinear;
import ChickenPackage.Egg;
import Controllers.MyAdminister;
import GamePackage.SpaceShip;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import Tool.SuperGameEngineThread;

public
//abstract
class OriginalGroupChicken

		implements Updatable, Movable, Paintable, Destroyable, Serializable {

	private boolean isDestroy = false;
	private CopyOnWriteArrayList<Chicken> chickens = new CopyOnWriteArrayList<>();
	private CopyOnWriteArrayList<Egg> eggs = new CopyOnWriteArrayList<>();

	private CopyOnWriteArrayList<Point> wherePossibleThrowGift = new CopyOnWriteArrayList<>();
	private boolean isGetGiftPoint = false;

	public OriginalGroupChicken() {
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	public CopyOnWriteArrayList<Chicken> getChickens() {
		return chickens;
	}

	public void setChickens(CopyOnWriteArrayList<Chicken> chickens) {
		this.chickens = chickens;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void paint(Graphics2D g) {
		for (Chicken chicken : chickens) {
			chicken.paint(g);
		}
		for (Egg egg : eggs) {
			egg.paint(g);

		}
	}

	@Override
	public void move() {
		for (Chicken chicken : chickens) {
			chicken.move();
		}
		for (Egg egg : eggs) {
			egg.move();

		}
	}

	@Override
	public void update() {
		move();

		synchronized (wherePossibleThrowGift) {

			if (isGetGiftPoint) {
				wherePossibleThrowGift.clear();
				isGetGiftPoint = false;
			}
		}
		for (Chicken chicken : chickens) {

			chicken.update();

			if (chicken.isThrowEgg()) {
				eggs.add(new Egg(
						new Point((int) (chicken.getLocation().getX() + chicken.getDimension().getWidth() / 2),
								(int) (chicken.getLocation().getY() + chicken.getDimension().getHeight())),
						chicken.getLevel()));
			}

			if (chicken.isDestroy()) {
				wherePossibleThrowGift
						.add(new Point((int) (chicken.getLocation().getX() + chicken.getDimension().getWidth() / 2),
								(int) (chicken.getLocation().getY() + chicken.getDimension().getHeight())));
//				chickens.get(i).interrupt();
				chickens.remove(chicken);
			}
		}
		if (chickens.size() == 0) {
			isDestroy = true;
		}

		eggsUpdate();
	}

	private void eggsUpdate() {
		for (Egg egg : eggs) {
			egg.update();
			if (egg.isDestroy()) {
				eggs.remove(egg);
			}
		}

	}

	public CopyOnWriteArrayList<Point> getWherePosibleThrowGift() {
		synchronized (wherePossibleThrowGift) {

			isGetGiftPoint = true;
			return wherePossibleThrowGift;
		}
	}

	public Chicken getNearestChickenToPlayer(int id) {
		Point locationTryingToShot = new Point(
				(int) (MyAdminister.getInstance().getPlayer(id).getLocationTryingToShotBullet().getX()),
				(int) (MyAdminister.getInstance().getPlayer(id).getLocationTryingToShotBullet().getY()));

		Chicken nearest = null;
		for (Chicken chicken : getChickens()) {
			if(nearest == null) {
				nearest = chicken;
			}
			if (Math.pow(chicken.getMiddle().getX() - locationTryingToShot.getX(), 2)
					+ Math.pow(chicken.getMiddle().getY() - locationTryingToShot.getY(), 2) < Math
							.pow(nearest.getMiddle().getX() - locationTryingToShot.getX(), 2)
							+ Math.pow(nearest.getMiddle().getY() - locationTryingToShot.getY(), 2)) {
				
				nearest = chicken;
			}
		}
		return nearest;
	}
}
