package GamePackage.InformationOfPlayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import Controllers.MyAdminister;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class BombsOfPlayer implements Updatable, Paintable, Movable, Serializable {

	private CopyOnWriteArrayList<SpaceShipWithBomb> spaceShipWithBombs = new CopyOnWriteArrayList<>();
	private transient boolean isTryingToShotBomb;

	private int bombs = 3;
	private int id;

	public BombsOfPlayer(int id) {
		this.id = id;
		isTryingToShotBomb = false;

	}
	
	public void setNumberOfBombs(int bombs) {
		this.bombs = bombs;
	}
	@Override
	public void update() {
		if (isTryingToShotBomb && bombs > 0 && !MyAdminister.getInstance().getPlayer(id).getSpaceShip().isDestroy()) {
			spaceShipWithBombs.add(new SpaceShipWithBomb());
			bombs--;
			isTryingToShotBomb = false;
		}
		if (spaceShipWithBombs != null) {
			for (SpaceShipWithBomb spaceShipWithBomb: spaceShipWithBombs) {
				if (!spaceShipWithBomb.isDestroy()) {
					spaceShipWithBomb.update();
				} else {
					spaceShipWithBombs.remove(spaceShipWithBomb);
				}
			}
		}

		move();
	}

	@Override
	public void paint(Graphics2D g) {

		if (spaceShipWithBombs != null) {
			for (SpaceShipWithBomb spaceShipWithBomb : spaceShipWithBombs) {
				spaceShipWithBomb.paint(g);
			}
		}
	}

	@Override
	public void move() {
		if (spaceShipWithBombs != null) {
			for (SpaceShipWithBomb spaceShipWithBomb : spaceShipWithBombs) {
				spaceShipWithBomb.move();
			}
		}
	}

	public void TryingToShotBombs(boolean isTrying) {
		isTryingToShotBomb = isTrying;
	}

	public void increaseBomb() {
		bombs++;
	}

	public boolean isBlasting() {
		for (SpaceShipWithBomb spaceShipWithBomb : spaceShipWithBombs) {
			if (spaceShipWithBomb.isBlasting()) {
				return true;
			}
		}
		return false;
	}

	public int getNumberOfBomb() {
		return bombs;
	}
}

class SpaceShipWithBomb implements Movable, Paintable, Destroyable, Updatable, Serializable {

	private int spaceShipX;
	private int spaceShipY;
	private int spaceShipWidth = 80;
	private int spaceShipHeight = 80;
	private int veloctySpaceShipY = -1;

	private boolean isBombRelease;
	private int bombX;
	private int bombY;
	private int bombWidth = 50;
	private int bombHeight = 50;
	private int veloctyBombX = -2;
	private int veloctyBombY = -1;
	private transient ArrayList<BufferedImage> bombsImage = new ArrayList<>();
	private int whichBombImageSelected = 0;

	private transient ArrayList<BufferedImage> blastImage = new ArrayList<>();
	private int blastX;
	private int blastY;
	private int blastWidth;
	private int blastHeight;
	private long lastChangePictureOfBlast;
	private int whatBlastPaint;

	private boolean isBombDestroy;
	private boolean isSpaceShipDestroy;
	private boolean isBlastDestroy;
	private boolean isBlasting = false;;

	private transient Point whereBombRelease = new Point(1532, 800);

	private int centerXOnFrame;
	private int centerYOnFrame;

	public SpaceShipWithBomb() {
		initialize();
	}

	private void initialize() {
		centerXOnFrame = (int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2);
		centerYOnFrame = (int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2);

		spaceShipX = (int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() - 100);
		spaceShipY = (int) MyAdminister.getInstance().getSizeOfFrame().getHeight();

		setImageOfBomb();
		isBombRelease = false;
		isBombDestroy = false;
		isSpaceShipDestroy = false;
		isBlastDestroy = false;

		setImageOfBlast();
		blastWidth = 1500;
		blastHeight = 1500;
		blastX = (int) ((MyAdminister.getInstance().getSizeOfFrame().getWidth() - blastWidth) / 2);
		blastY = (int) ((MyAdminister.getInstance().getSizeOfFrame().getHeight() - blastHeight) / 2);
		whatBlastPaint = 0;

	}

	private void setImageOfBlast() {
		blastImage = new ArrayList<>();
		for (int i = 1; i <= 4; i++) {
			blastImage.add((BufferedImage) MyObjectCollection.getInstance().getImage("Blast" + i));
		}
	}

	private void setImageOfBomb() {
		bombsImage = new ArrayList<>();
		for (int i = 1; i <= 14; i++) {
			bombsImage.add((BufferedImage) MyObjectCollection.getInstance().getImage("Bomb" + i));
		}
	}

	@Override
	public void move() {
		spaceShipY += veloctySpaceShipY;
		if (!isBombRelease) {
			if (spaceShipY <= 800) {
				isBombRelease = true;
				bombX = spaceShipX;
				bombY = spaceShipY;
			}

		} else {
			bombX += veloctyBombX;
			bombY += veloctyBombY;
		}
	}

	@Override
	public void paint(Graphics2D g) {
		if (!isBombDestroy && isBombRelease) {
			g.drawImage(getImageOfBomb(), bombX, bombY, bombWidth, bombHeight, null);
		}
		if (!isSpaceShipDestroy) {
			g.drawImage((BufferedImage) MyObjectCollection.getInstance().getImage("SpaceShipWithBomb"), spaceShipX,
					spaceShipY, spaceShipWidth, spaceShipHeight, null);
		}
		if (!isBlastDestroy && isBombDestroy) {
			g.drawImage(getImageOfBlast(), blastX, blastY, blastWidth, blastHeight, null);
		}
	}

	private Image getImageOfBlast() {
		if(blastImage == null) {
			setImageOfBlast();
		}
		return blastImage.get(whatBlastPaint);
	}

	private Image getImageOfBomb() {
		if(bombsImage == null) {
			setImageOfBomb();
		}
		return bombsImage.get(whichBombImageSelected);
	}

	@Override
	public boolean isDestroy() {

		return isBombDestroy && isSpaceShipDestroy && isBlastDestroy;
	}

	@Override
	public void update() {
		if (!isBlastDestroy && isBombDestroy) {

			if (System.currentTimeMillis() - lastChangePictureOfBlast >= 100) {
				lastChangePictureOfBlast = System.currentTimeMillis();
				whatBlastPaint++;
				if (whatBlastPaint == 3) {
					isBlastDestroy = true;
				}
			}
		}
		if (!isBombDestroy && isBombRelease) {
			double distance = Math.sqrt(Math.pow(centerXOnFrame - bombX, 2) + Math.pow(centerYOnFrame - bombY, 2));
			double firstDistance = Math.sqrt(Math.pow(centerXOnFrame - whereBombRelease.getX(), 2)
					+ Math.pow(centerYOnFrame - whereBombRelease.getY(), 2));
			if (distance / firstDistance * 14 < 0.3) {
				bombX = centerXOnFrame;
				bombY = centerYOnFrame;
			}
			if (distance == firstDistance) {
				whichBombImageSelected = 0;
			} else if ((((int) (distance / firstDistance * 14)) - 13) * -1 < 0) {
				whichBombImageSelected = 0;
			} else {
				whichBombImageSelected = (((int) (distance / firstDistance * 14)) - 13) * -1;
			}

		}

		if (isBlasting) {
			isBlasting = false;
		}
		if (!isBombDestroy && bombX == centerXOnFrame && bombY == centerYOnFrame) {
			isBombDestroy = true;
			isBlasting = true;
			playingBlastSound();

		}
		if (!isSpaceShipDestroy && spaceShipY + spaceShipHeight <= 0) {
			isSpaceShipDestroy = true;

		}
	}

	private static void playingBlastSound() {
		new Thread(() -> {
			try {
				Clip Fire = AudioSystem.getClip();
				Fire.open(MyObjectCollection.getInstance().getSound("BlastSound"));
				Fire.start();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}).start();
	}

	@Override
	public void setDestroy() {

	}

	public boolean isBlasting() {
		return isBlasting;
	}

}
