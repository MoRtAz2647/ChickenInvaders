package Tool;

import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.Area;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import Controllers.MyAdminister;

public class IntersectsRotateRectangle {

	public IntersectsRotateRectangle() {

	}

	public static boolean intersects(Rectangle r1, double degree1, Rectangle r2, double degree2) {
//		ArrayList<Line> lines1 = new ArrayList<>();
//		ArrayList<Line> lines2 = new ArrayList<>();
//		lines1 = findLines(r1, degree1);
//		lines2 = findLines(r2, degree2);
		

//		for (Line line1 : lines1) {
//			for (Line line2 : lines2) {
//				if (Line.intersects(line1, line2)) {
//					return true;
//				}
//			}
//		}
//		for (int i = 0; i < 4; i++) {
//			if (new Polygon(
//					new int[] { (int) lines1.get(0).getEndingPoints().get(0).getX(),
//							(int) lines1.get(0).getEndingPoints().get(1).getX(),
//							(int) lines1.get(2).getEndingPoints().get(0).getX(),
//							(int) lines1.get(2).getEndingPoints().get(1).getX() },
//					new int[] { (int) lines1.get(0).getEndingPoints().get(0).getX(),
//							(int) lines1.get(0).getEndingPoints().get(1).getX(),
//							(int) lines1.get(2).getEndingPoints().get(0).getX(),
//							(int) lines1.get(2).getEndingPoints().get(1).getX() },
//					4).contains(lines2.get(i).getEndingPoints().get(0))
//					|| new Polygon(
//							new int[] { (int) lines2.get(0).getEndingPoints().get(0).getX(),
//									(int) lines2.get(0).getEndingPoints().get(1).getX(),
//									(int) lines2.get(2).getEndingPoints().get(0).getX(),
//									(int) lines2.get(2).getEndingPoints().get(1).getX() },
//							new int[] { (int) lines2.get(0).getEndingPoints().get(0).getX(),
//									(int) lines2.get(0).getEndingPoints().get(1).getX(),
//									(int) lines2.get(2).getEndingPoints().get(0).getX(),
//									(int) lines2.get(2).getEndingPoints().get(1).getX() },
//							4).contains(lines1.get(i).getEndingPoints().get(0))) {
//				return true;
//			}
//
//		}
		
		Area area1 = findArea(r1, degree1);
		Area area2 = findArea(r2, degree2);
		area1.intersect(area2);
		if(!area1.isEmpty()) {
			return true;
		}
		return false;

	}

	private static Area findArea(Rectangle r1, double degree1) {
		double x1 = (r1.getX() - r1.getCenterX()) * Math.cos(-degree1 * Math.PI / 180)
				- (r1.getY() - r1.getCenterY()) * Math.sin(-degree1 * Math.PI / 180) + r1.getCenterX();
		double y1 = (r1.getX() - r1.getCenterX()) * Math.sin(-degree1 * Math.PI / 180)
				+ (r1.getY() - r1.getCenterY()) * Math.cos(-degree1 * Math.PI / 180) + r1.getCenterY();

		double x2 = x1 + r1.getWidth() * Math.cos(degree1 * Math.PI / 180);
		double y2 = y1 + r1.getWidth() * Math.sin(degree1 * Math.PI / 180);

		double x3 = x2 + r1.getHeight() * Math.cos((degree1 + 90) * Math.PI / 180);
		double y3 = y2 + r1.getHeight() * Math.sin((degree1 + 90) * Math.PI / 180);

		double x4 = x1 + r1.getHeight() * Math.cos((degree1 + 90) * Math.PI / 180);
		double y4 = y1 + r1.getHeight() * Math.sin((degree1 + 90) * Math.PI / 180);

		Polygon polygon = new Polygon(new int[] { (int) x1, (int) x2, (int) x3, (int) x4 },
				new int[] { (int) y1, (int) y2, (int) y3, (int) y4 }, 4);

		return new Area(polygon);
	}

	private static ArrayList<Line> findLines(Rectangle r1, double degree1) {
		double x1 = (r1.getX() - r1.getCenterX()) * Math.cos(-degree1 * Math.PI / 180)
				- (r1.getY() - r1.getCenterY()) * Math.sin(-degree1 * Math.PI / 180) + r1.getCenterX();
		double y1 = (r1.getX() - r1.getCenterX()) * Math.sin(-degree1 * Math.PI / 180)
				+ (r1.getY() - r1.getCenterY()) * Math.cos(-degree1 * Math.PI / 180) + r1.getCenterY();

		double x2 = x1 + r1.getWidth() * Math.cos(degree1 * Math.PI / 180);
		double y2 = y1 + r1.getWidth() * Math.sin(degree1 * Math.PI / 180);

		double x3 = x2 + r1.getHeight() * Math.cos((degree1 + 90) * Math.PI / 180);
		double y3 = y2 + r1.getHeight() * Math.sin((degree1 + 90) * Math.PI / 180);

		double x4 = x1 + r1.getHeight() * Math.cos((degree1 + 90) * Math.PI / 180);
		double y4 = y1 + r1.getHeight() * Math.sin((degree1 + 90) * Math.PI / 180);

		ArrayList<Line> lines = new ArrayList<>(Arrays.asList(new Line(x1, x2, y1, y2), new Line(x2, x3, y2, y3),
				new Line(x3, x4, y3, y4), new Line(x4, x1, y4, y1)));

		return lines;
	}
}

class Line {
	private double x1;
	private double x2;
	private double y1;
	private double y2;
	private double teta;

	public Line(double x1, double x2, double y1, double y2) {
		this.x1 = x1;
		this.x2 = x2;
		this.y1 = y1;
		this.y2 = y2;
		teta = Math.atan2((y2 - y1), (x2 - x1));
	}

	public double getTeta() {
		return teta;
	}

	public double getMinX() {
		return Math.min(x1, x2);
	}

	public double getMinY() {
		return Math.min(y1, y2);
	}

	public double getMaxY() {
		return Math.max(y1, y2);
	}

	public double getMaxX() {
		return Math.max(x1, x2);
	}

	public ArrayList<Point> getEndingPoints() {
		ArrayList<Point> points = new ArrayList<>();
		points.add(new Point((int) x1, (int) y1));
		points.add(new Point((int) x2, (int) y2));
		return points;
	}

	public static boolean intersects(Line line1, Line line2) {
		if (Math.tan(line1.getTeta()) == Math.tan(line2.getTeta())) {
			double y0 = ((Math.tan(line1.getTeta())
					* (line2.getEndingPoints().get(0).getX() - line1.getEndingPoints().get(0).getX()))
					+ line1.getEndingPoints().get(0).getY());
			double y1 = ((Math.tan(line1.getTeta())
					* (line2.getEndingPoints().get(1).getX() - line1.getEndingPoints().get(0).getX()))
					+ line1.getEndingPoints().get(0).getY());

			if (((line1.getMinY() <= y0 && line1.getMaxY() >= y0 && y0 == line2.getEndingPoints().get(0).getY())
					&& (line1.getMinX() <= line2.getEndingPoints().get(0).getX()
							&& line1.getMaxX() >= line2.getEndingPoints().get(0).getX()))
					|| ((line1.getMinY() <= y1 && line1.getMaxY() >= y1 && y1 == line2.getEndingPoints().get(1).getY()))
							&& (line1.getMinX() <= line2.getEndingPoints().get(1).getX()
									&& line1.getMaxX() >= line2.getEndingPoints().get(1).getX())) {
				return true;
			}
		} else {
			double xIntersect = ((Math.tan(line2.getTeta()) * line2.getEndingPoints().get(0).getX())
					+ (Math.tan(line1.getTeta()) * line1.getEndingPoints().get(0).getX())
					+ line1.getEndingPoints().get(0).getY() + line2.getEndingPoints().get(0).getY())
					/ (Math.tan(line2.getTeta()) - Math.tan(line1.getTeta()));
			double yIntersect = Math.tan(line1.getTeta()) * (xIntersect - line1.getEndingPoints().get(0).getX())
					+ line1.getEndingPoints().get(0).getY();
			if (((line1.getMinX() <= xIntersect && line1.getMaxX() >= xIntersect)
					&& (line2.getMinX() <= xIntersect && line2.getMaxX() >= xIntersect))
					&& ((line1.getMinY() <= yIntersect && line1.getMaxY() >= yIntersect)
							&& (line2.getMinY() <= yIntersect && line2.getMaxY() >= yIntersect))) {
				return true;
			}

		}

		return false;
	}

}
