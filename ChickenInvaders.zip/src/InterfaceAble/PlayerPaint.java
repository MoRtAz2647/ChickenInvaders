package InterfaceAble;

import java.awt.Graphics2D;

import GamePackage.Player;

public interface PlayerPaint {
	void paint(Graphics2D g, Player player);

}
