package Buttons.SettingMainMenu;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.Paintable;
import InterfaceAble.Selectable;
import ListOfAddress.MyObjectCollection;

public class TuneButton extends OriginalButton implements Selectable {
	private boolean isSelected;

	public TuneButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("TuneInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("TuneOutClick"),
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 5 - 25 * 4, 400, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().setSelectedOfSettingButtons(false);
			setSelected(true);

		}
		if (isSelected) {
			SpaceShipsImage.getInstance().checkIfSelectSpaceShip(e);
		}
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);
		if (isSelected) {
			drawSpaceShips(g);
		}
	}

	private void drawSpaceShips(Graphics2D g) {
		SpaceShipsImage.getInstance().paint(g);
	}
}

class SpaceShipsImage implements Paintable {

	private static SpaceShipsImage spaceShipsImage;
	private BufferedImage[][] spaceShips = new BufferedImage[8][4];

	private int spaceShipStartX;
	private int spaceShipStartY;
	private int distanceInX;
	private int distanceInY;
	private int widthOfImage;
	private int heightOfImage;

	private SpaceShipsImage() {
		initialize();
	}

	private void initialize() {
		loadImage();
		spaceShipStartX = (int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 200);
		spaceShipStartY = 100;
		distanceInX = 50;
		distanceInY = 50;
		widthOfImage = 75;
		heightOfImage = 120;
	}

	public void checkIfSelectSpaceShip(MouseEvent e) {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 4; j++) {
				Rectangle rectangle = new Rectangle(spaceShipStartX + i * distanceInX + i * widthOfImage,
						spaceShipStartY + j * distanceInY + j * heightOfImage, widthOfImage, heightOfImage);
				if (rectangle.contains(e.getPoint())) {
					MyAdminister.getInstance().getPlayers().get(0).getSpaceShip().setSpaceShipImage(i, j);
					MyAdminister.getInstance().setSelectedOfSettingButtons(false);
				}
			}
		}
	}

	private void loadImage() {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 4; j++) {
				spaceShips[i][j] = (BufferedImage) MyObjectCollection.getInstance()
						.getImage("SpaceShip" + (i + 1) + (j + 1));
			}
		}
	}

	public static SpaceShipsImage getInstance() {
		if (spaceShipsImage == null) {
			spaceShipsImage = new SpaceShipsImage();
		}
		return spaceShipsImage;
	}

	@Override
	public void paint(Graphics2D g) {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 4; j++) {
				g.drawImage(spaceShips[i][j], spaceShipStartX + i * distanceInX + i * widthOfImage,
						spaceShipStartY + j * distanceInY + j * heightOfImage, widthOfImage, heightOfImage, null);
			}
		}

	}

}
