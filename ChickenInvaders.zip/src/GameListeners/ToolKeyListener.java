package GameListeners;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.PrintStream;

import com.google.gson.Gson;

import ActionEnum.PlayerTask;
import InterfaceAble.BroadcastOfPlayerTask;
import InterfaceAble.CheckIfInGame;

public class ToolKeyListener implements KeyListener, BroadcastOfPlayerTask {

	private PrintStream printer;

	public ToolKeyListener(PrintStream printer) {
		this.printer = printer;
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (KeyEvent.VK_R == e.getKeyCode()) {
			send(PlayerTask.RequestToPlay, printer);
		} else if (KeyEvent.VK_P == e.getKeyCode()) {
			send(PlayerTask.StartGameNow, printer);
		} else if (KeyEvent.VK_ESCAPE == e.getKeyCode()) {
			send(PlayerTask.PauseGame, printer);
		}

	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

}
