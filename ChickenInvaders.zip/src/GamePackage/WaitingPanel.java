package GamePackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JPanel;

import ActionEnum.PlayerTask;
import Controllers.ControllerOfPlayer;
import Controllers.MyAdminister;
import InterfaceAble.Drawable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class WaitingPanel implements Updatable, Paintable {

	private transient ArrayList<BufferedImage> loadBarPicture;
	private int whichLoadBarSelected = 0;
	private long lastLoadBarPictureChange = 0;
	private int loadBarWedth = 100;
	private int loadBarHeight = 100;
	private int allUser = 0;
	private int userWantToPlay = 0;
	private int maxPlayer = 0;

	private int levels = 4;
	private int waves = 4;

	public WaitingPanel(int levels, int waves) {
		this.waves = waves;
		this.levels = levels;
		initialize();
	}

	private void initialize() {
		loadImage();

	}

	private void loadImage() {
		loadBarPicture = new ArrayList<>();
		for (int i = 1; i <= 29; i++) {
			loadBarPicture.add((BufferedImage) MyObjectCollection.getInstance().getImage("LoadBar" + i));
		}
	}

	@Override
	public void paint(Graphics2D g) {
		g.drawImage((BufferedImage) MyObjectCollection.getInstance().getImage("BackgroundLoading"), 0, 0,
				(int) MyAdminister.getInstance().getSizeOfFrame().getWidth(),
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight(), null);
		g.setFont(new Font("Arial", 1, 42));
		g.setColor(Color.WHITE);

		g.drawString("All Player Connected: " + allUser,
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 21 * 42 / 3), 50);
		g.drawString("Player Want To Play: " + userWantToPlay,
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 21 * 42 / 3), 50 * 2);
		g.drawString("Max Player Can Play: " + maxPlayer,
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 21 * 42 / 3), 50 * 3);

		g.drawImage(getImage(), (int) MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - loadBarWedth + 10,
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 - loadBarHeight + 50, loadBarWedth,
				loadBarHeight, null);
	}

	private Image getImage() {
		if (loadBarPicture == null) {
			loadImage();
		}
		return loadBarPicture.get(whichLoadBarSelected);
	}

	@Override
	public void update() {
		if (System.currentTimeMillis() - lastLoadBarPictureChange >= 100) {
			lastLoadBarPictureChange = System.currentTimeMillis();
			whichLoadBarSelected++;
			if (whichLoadBarSelected > 28) {
				whichLoadBarSelected = 0;
			}
		}
		allUser = MyAdminister.getInstance().getAllUsers().size();
		userWantToPlay = MyAdminister.getInstance().getGalaxyWorld().getWaitingPlayers().size()
				+ MyAdminister.getInstance().getGalaxyWorld().getPlayers().size();
		maxPlayer = MyAdminister.getInstance().getMaxPlayer();
		if (maxPlayer <= userWantToPlay && isAllWaiting()) {
			MyAdminister.getInstance().changeAllUserForSituationOfGame(PlayerTask.GamePanel);
//			MyAdminister.getInstance().runGameEngine();
			MyAdminister.getInstance().showGalaxyWorld();
		}
	}

	private boolean isAllWaiting() {
		for (ControllerOfPlayer controllerOfPlayer : MyAdminister.getInstance().getAllUsers()) {
			if (controllerOfPlayer.getWhichPanelPaint() != PlayerTask.WaitingPanel) {
				return false;
			}
		}
		return true;
	}

}
