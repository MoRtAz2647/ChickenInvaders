package Tool;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import InterfaceAble.Drawable;
import InterfaceAble.Updatable;

public class SuperGameEnginePanel extends JPanel implements Runnable , Updatable , Drawable{

	private transient boolean running;
	private transient int repaints = 0;
	private transient Thread engine;
	

	
	public SuperGameEnginePanel() {
		// TODO Auto-generated constructor stub
	}
	
	
	public void interrupt() {
		running = false;
		if(engine!= null && engine.isAlive()  )
		engine.stop();
	}
	
	public void start() {
		if(engine == null || !engine.isAlive()) {
		engine = new Thread(this);
		engine.start();
		}
		running = true;
	}
	
	@Override
	public void run() {
		while (true) {
			// The Game Loop
			long lastTime = System.nanoTime();
			double amountOfTicks = 60.0; // per second
			double ns_per_tick = 1000000000 / amountOfTicks; // results in almost: 16 millions
			double delta = 0;
			long timer = System.currentTimeMillis();
			int frames = 0;
			while (running) {
				long now = System.nanoTime();
				delta += (now - lastTime) / ns_per_tick;
				lastTime = now;
				while (delta >= 1) {
					update(); // must take less than 16 million nano seconds
					frames++;
					delta--;
				}
//				if (running) {
//					repaint();
//				}

				try {
					Thread.sleep(frames > 105 ? 30 : 0);
					Thread.sleep((long) Math.max((System.nanoTime() - lastTime - ns_per_tick) / 1000000, 1));
				} catch (InterruptedException e) {
//					e.printStackTrace();
					System.out.println("Sleep:))");
				}

				if (frames > 100) {
					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				if (System.currentTimeMillis() - timer > 1000) {
					timer += 1000;
//					System.out.format("FPS: %d repaints: %d%n" + "   chicken %n" , frames, repaints);
					frames = 0;
					repaints = 0;
				}

			}
		}

	}
	@Override
	protected void paintComponent(Graphics g) {
		render((Graphics2D) g);
	}


	@Override
	public void render(Graphics2D g) {
		
	}


	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

}
