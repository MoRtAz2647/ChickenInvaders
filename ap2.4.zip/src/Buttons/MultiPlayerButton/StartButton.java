package Buttons.MultiPlayerButton;

import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.JLabel;
import javax.swing.JTextField;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class StartButton extends OriginalButton {

	private boolean isClicked = false;

	private static StartButton startButton;

	private boolean isServer;

	private StartButton(boolean isServer) {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("StartInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("StartOutClick"), 50 + 400 * 2 + 50 * 2,
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 4 - 25 * 3, 400, 100);

		this.isServer = isServer;

	}

	public static StartButton getInstance(boolean isServer) {
		if (startButton == null) {
			startButton = new StartButton(isServer);
		} else {
			startButton.setIsServer(isServer);
		}
		return startButton;

	}
	
	

	private void setIsServer(boolean isServer) {
		this.isServer = isServer;
	}
	
	public void setIsClicked(boolean isClicked) {
		this.isClicked = isClicked;
	}

	public boolean isClicked() {
		return isClicked;
	}
//	private void sizedTextField() {
//		portClient.setPreferredSize(new Dimension(100, 50));
//		portClient.setLocation(50 + 400 + 50 + 100, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50
//				- 100 * 4 - 25 * 3 - 100 / 2 - 5 - 50 - 100);
//		ipClient.setPreferredSize(new Dimension(100, 50));
//		ipClient.setLocation(50 + 400 + 50 + 100, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50
//				- 100 * 4 - 25 * 3 - 100 / 2 - 5 - 50 * 2 - 100 * 2);
//		spectaterClient.setPreferredSize(new Dimension(100, 50));
//		spectaterClient.setLocation(50 + 400 + 50 + 100, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight()
//				- 50 - 100 * 4 - 25 * 3 - 100 / 2 - 5 - 50 * 3 - 100 * 3);
//
//		
//		
//		portServer.setPreferredSize(new Dimension(100, 50));
//		portServer.setLocation(50 + 400 + 50 + 100, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50
//				- 100 * 4 - 25 * 3 + 100 / 2 + 5 - 50 - 100);
//		levelsServer.setPreferredSize(new Dimension(100, 50));
//		levelsServer.setLocation(50 + 400 + 50 + 100, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50
//				- 100 * 4 - 25 * 3 + 100 / 2 + 5 - 50 * 2 - 100 * 2);
//		wavesServer.setPreferredSize(new Dimension(100, 50));
//		wavesServer.setLocation(50 + 400 + 50 + 100, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50
//				- 100 * 4 - 25 * 3 + 100 / 2 + 5 - 50 * 3 - 100 * 3);
//		numberPlayerServer.setPreferredSize(new Dimension(100, 50));
//		numberPlayerServer.setLocation(50 + 400 + 50 + 100,
//				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 4 - 25 * 3 + 100 / 2 + 5
//						- 50 * 4 - 100 * 4);
//		spectaterServer.setPreferredSize(new Dimension(100, 50));
//		spectaterServer.setLocation(50 + 400 + 50 + 100, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight()
//				- 50 - 100 * 4 - 25 * 3 + 100 / 2 + 5 - 50 * 5 - 100 * 5);
//	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			isClicked = true;
		}
	}

}
