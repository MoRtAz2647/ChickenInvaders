package GameListeners;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.PrintStream;
import java.util.Scanner;

import javax.swing.SwingUtilities;

import com.google.gson.Gson;

import ActionEnum.PlayerTask;
import Controllers.MyAdminister;
import InterfaceAble.BroadcastOfPlayerTask;
import InterfaceAble.CheckIfInGame;

public class BombListener
		implements MouseListener, MouseMotionListener, KeyListener, BroadcastOfPlayerTask, CheckIfInGame {

	private PrintStream printer;
	private boolean isSpectater;
	private Scanner reader;

	public BombListener(PrintStream printer, Scanner reader, boolean isSpectater) {
		this.isSpectater = isSpectater;
		this.printer = printer;
		this.reader = reader;
	}

	public void setIsSpectater(boolean isSpectater) {
		this.isSpectater = isSpectater;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToShotBombWithKeyboard(e, true);
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToShotBombWithKeyboard(e, false);

	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToShotBombWithMouse(e, true);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToShotBombWithMouse(e, true);

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (!isSpectater && checkIfInGame(reader, printer))
			checkTryingToShotBombWithMouse(e, false);

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	private void checkTryingToShotBombWithMouse(MouseEvent e, boolean isTryingToShotBomb) {
		if (SwingUtilities.isRightMouseButton(e) && MyAdminister.getInstance().isPlayingWithMouse()) {
//			MyAdminister.getInstance().getPlayer(0).getInformationOfPlayerTab().getBombsOfPlayer()
//					.TryingToShotBombs(isTryingToShotBomb);
			PlayerTask playerTask = PlayerTask.ShootBomb;
			send(playerTask, printer);
		}

	}

	private void checkTryingToShotBombWithKeyboard(KeyEvent e, boolean isTryingToShotBomb) {
		if (!MyAdminister.getInstance().isPlayingWithMouse() && KeyEvent.VK_B == e.getKeyCode()) {
//			MyAdminister.getInstance().getPlayer(0).getInformationOfPlayerTab().getBombsOfPlayer()
//					.TryingToShotBombs(isTryingToShotBomb);
			PlayerTask playerTask = PlayerTask.ShootBomb;
			send(playerTask, printer);

		}
	}

}
