package Buttons.PanelAccounts;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class LetsPlayButton extends OriginalButton {

	public LetsPlayButton() throws Exception {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("LetsPlayInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("LetsPlayOutClick"),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 + 200  ),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight()-200 - 100 *3 - 25* 2), 500, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(new Point(e.getX(), e.getY()))) {
//			MyAdminister.getInstance().showGalaxyWorld();
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().showMainMenu();
			MyAdminister.getInstance().getPlayingAccount();
		}
	}

}
