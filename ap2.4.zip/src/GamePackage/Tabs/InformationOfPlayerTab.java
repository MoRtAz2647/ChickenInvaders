package GamePackage.Tabs;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.Serializable;

import Controllers.MyAdminister;
import GamePackage.Player;
import InterfaceAble.Paintable;
import InterfaceAble.PlayerPaint;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

public class InformationOfPlayerTab implements Updatable, PlayerPaint, Serializable {

	private transient BufferedImage mainTab;
	private int x;
	private int y;
	private int width;
	private int height;

	private int id;

	public InformationOfPlayerTab(int id) {
		this.id = id;
		initialize();
	}

	private void initialize() {
		x = 0;
		width = 500;
		height = 100;
		y = (int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - height - 28);
//		mainTab = (BufferedImage) MyObjectCollection.getInstance().getImage("InformationOfPlayerTab");

	}

	@Override
	public void update() {

	}

	@Override
	public void paint(Graphics2D g, Player player) {
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
//		g.drawImage(mainTab, x, y, width, height, null);
		g.drawImage((BufferedImage) MyObjectCollection.getInstance().getImage("InformationOfPlayerTab"), x, y, width,
				height, null);

		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));

		g.setFont(new Font("Arial", 1, 46));
		g.setColor(Color.WHITE);
		
		g.drawString(Integer.toString(player.getInformationOfPlayer().getBombsOfPlayer().getNumberOfBomb()),
				(int) (width / 2 - 17),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - height / 2 - 10));

		g.drawString(Integer.toString(player.getInformationOfPlayer().getChickenLeg().getNumberOfChicken()),
				(int) (width - 35), (int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - height / 2 - 10));

		g.drawString(Integer.toString(player.getInformationOfPlayer().getLifeOfPlayer().getLife()),
				(int) (width / 4 - 20),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - height / 2 - 10));

		g.drawString(Integer.toString(player.getInformationOfPlayer().getPowerOfBullet().getLevel()),
				(int) (width / 4 * 3 - 40),
				(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - height / 2 - 10));

	}

}
