package Tool;

import InterfaceAble.Updatable;

public
//abstract 
class SuperGameEngineThread implements Updatable, Runnable {

	private transient boolean running;
	private transient int repaints = 0;
	private transient Thread engine;

	public SuperGameEngineThread() {

	}

	public void interrupt() {
		running = false;
		Thread thread = engine;
		engine = null;
		if (thread != null) {
			thread.stop();
		}
	}

	public void start() {
		if (engine == null) {
			engine = new Thread(this);
			running = true;
			engine.start();
		}
	}

	@Override
	public void run() {
		while (true) {
			// The Game Loop
			long lastTime = System.nanoTime();
			double amountOfTicks = 100.0; // per second
			double ns_per_tick = 1000000000 / amountOfTicks; // results in almost: 16 millions
			double delta = 0;
			long timer = System.currentTimeMillis();
			int frames = 0;
			while (running) {
				long now = System.nanoTime();
				delta += (now - lastTime) / ns_per_tick;
				lastTime = now;
				while (delta >= 1) {
					update(); // must take less than 16 million nano seconds
					frames++;
					delta--;
				}
//				if (running) {
//					repaint();
//				}

				try {
					Thread.sleep(frames > 105 ? 30 : 0);
					Thread.sleep((long) Math.max((System.nanoTime() - lastTime - ns_per_tick) / 1000000, 1));
				} catch (InterruptedException e) {
//					e.printStackTrace();
				}

				if (frames > 100) {
					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				if (System.currentTimeMillis() - timer > 1000) {
					timer += 1000;
//					System.out.format("FPS: %d repaints: %d%n" + "   chicken %n" , frames, repaints);
					frames = 0;
					repaints = 0;
				}

			}
		}

	}

	private void waitToContinueGame() {
		while (!running) {
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

}
