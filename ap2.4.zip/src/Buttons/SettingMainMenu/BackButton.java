package Buttons.SettingMainMenu;

import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class BackButton extends OriginalButton {
	public BackButton() {
		super((BufferedImage)MyObjectCollection.getInstance().getImage("BackInClick"),
				(BufferedImage)MyObjectCollection.getInstance().getImage("BackOutClick"), 
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50 ,
				(int)MyAdminister.getInstance().getSizeOfFrame().getHeight()-50 - 100, 400, 100);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if(rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().showMainMenu();
			MyAdminister.getInstance().updateDataOfPlayer();
			MyAdminister.getInstance().setSelectedOfSettingButtons(false);
		}
	}

}
