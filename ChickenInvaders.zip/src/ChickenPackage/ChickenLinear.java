package ChickenPackage;

public class ChickenLinear extends Chicken {

	public ChickenLinear(int level, int x, int y) {
		super(level, x, y);
	}

	@Override
	public void move() {
		super.move();
		if (!isInPLace()) {
			double speed = (Math.sqrt(Math.pow(getLocationMustBe().getX() - getLocation().getX(), 2)
					+ Math.pow(getLocationMustBe().getY() - getLocation().getY(), 2)) < 2) ? 1 : 2.5;

			setLocation(
					getLocation().getX() + Math.cos(Math.atan2(getLocationMustBe().getY() - getLocation().getY(),
							getLocationMustBe().getX() - getLocation().getX())) * speed * getVelocty(),
					getLocation().getY() + Math.sin(Math.atan2(getLocationMustBe().getY() - getLocation().getY(),
							getLocationMustBe().getX() - getLocation().getX())) * speed * getVelocty());
		}
	}

	@Override
	public void update() {
		super.update();
		if (Math.sqrt(Math.pow(getLocationMustBe().getX() - getLocation().getX(), 2)
				+ Math.pow(getLocationMustBe().getY() - getLocation().getY(), 2)) < 1) {
			if (!isInPLace()) {
				setWhenBeInPlace(System.currentTimeMillis());
				setInPlace(true);
				setVelocty(1);
			}
			setLocation(getLocationMustBe().getX(), getLocationMustBe().getY());
		} else {
			setInPlace(false);
		}

	}

}
