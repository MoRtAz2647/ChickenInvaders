package Buttons.MultiPlayerButton;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.Selectable;
import ListOfAddress.MyObjectCollection;

public class ClientButton extends OriginalButton implements Selectable {

	private Clienthandler clienthandler;
	private boolean isSelected;

	public ClientButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("ClientInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("ClientOutClick"), 50 + 400 + 50,
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 4 - 25 * 3 - 100 / 2 - 5,
				400, 100);

		isSelected = false;
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().setSelectedOfServerAndClient(false);
			isSelected = !isSelected;
			clienthandler = new Clienthandler();
		}
	}

	@Override
	public void paint(Graphics2D g) {
		super.paint(g);

		if (isSelected) {
			StartButton.getInstance(false).paint(g);
			if (StartButton.getInstance(false).isClicked()) {
				MyAdminister.getInstance().createClientPlayer(clienthandler.getIp(), clienthandler.getPort(),
						clienthandler.isSpectater());
				StartButton.getInstance(false).setIsClicked(false);
			}
		}

	}
}

class Clienthandler {
	private PopUpClient popUpClient;

	public Clienthandler() {
//		BoxLayout boxLayout = new BoxLayout(popUpClient, BoxLayout.Y_AXIS);
		popUpClient = new PopUpClient();
		popUpClient.addAll();
	}

	public int getPort() {
		return popUpClient.getPort();
	}

	public String getIp() {
		return popUpClient.getIp();
	}

	public boolean isSpectater() {
		return popUpClient.isSpectater();
	}

}

class PopUpClient extends JFrame {

	private JTextField ipClient;
	private JTextField portClient;
	private Checkbox spectaterClient;
	private JButton okButton;

	public PopUpClient() {
		Initialize();
	}

	public boolean isSpectater() {
		return spectaterClient.getState();
	}

	public String getIp() {
		return ipClient.getText();
	}

	public int getPort() {
		return Integer.parseInt(portClient.getText());
	}

	public void addAll() {
		orderTextField();
		addTextField();
		setVisible(true);

	}

	private void Initialize() {
		setSize(300, 1);
		setLocationRelativeTo(null);
	}

	private void addTextField() {
		add(ipClient, BorderLayout.WEST);
		add(portClient, BorderLayout.EAST);
		add(spectaterClient, BorderLayout.CENTER);
		add(okButton, BorderLayout.SOUTH);
	}

	private void orderTextField() {
		portClient = new JTextField("Port");
		ipClient = new JTextField("IP");
		spectaterClient = new Checkbox("Spectater", false);
		okButton = new JButton("OK");

		okButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				PopUpClient.this.setEnabled(false);
				PopUpClient.this.setVisible(false);

			}
		});

		portClient.setPreferredSize(new Dimension(100, 25));
		ipClient.setPreferredSize(new Dimension(100, 25));
		spectaterClient.setPreferredSize(new Dimension(100, 50));
//
//
//		portServer = new JTextField("Port");
//		numberPlayerServer = new JTextField("Max Player");
//		levelsServer = new JTextField("Levels");
//		wavesServer = new JTextField("Waves");
//		spectaterServer = new Checkbox("Spectater", false);

	}

}
