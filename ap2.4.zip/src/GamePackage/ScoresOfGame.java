package GamePackage;

public class ScoresOfGame {

	private long score;
	private int id;
	
	public ScoresOfGame(int id) {
		this.id = id;
		score = 0;
	}
	
	public long getScore() {
		return score;
	}
	
	public void setScore(long score) {
		this.score = score;
	}
	
	public int getId() {
		return id;
	}

}
