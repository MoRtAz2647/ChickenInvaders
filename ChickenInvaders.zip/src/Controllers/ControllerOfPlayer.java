package Controllers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.lang.annotation.Annotation;
import java.net.Socket;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import ActionEnum.CheatEnum;
import ActionEnum.DirectionEnum;
import ActionEnum.PlayerTask;
import GamePackage.Player;
import InfoAnotation.WhichFeature;

public class ControllerOfPlayer extends Thread {

	private Socket socket;
	private int id;
	private boolean isSpectater;
	private PrintStream printer;
	private Scanner reader;
	private String playerName;

	private PlayerTask whichPanelPaint;

	public ControllerOfPlayer(Socket socket) {

		this.socket = socket;
		try {
			reader = new Scanner(socket.getInputStream());
			printer = new PrintStream(socket.getOutputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		playerName = reader.nextLine();
		printer.println(MyAdminister.getInstance().isPlayingSinglePlayer());
		id = Integer.parseInt(reader.nextLine());
		isSpectater = Boolean.parseBoolean(reader.nextLine());
		whichPanelPaint = MyAdminister.getInstance().getSituationOfGame();
//		whichPanelPaint = PlayerTask.WaitingPanel;

		start();

	}

	public int getPlayerId() {
		return id;
	}

	public String getPlayerName() {
		return playerName;
	}

	@Override
	public void run() {
		Gson gson = new Gson();
		try {
			while (true) {
				ByteArrayInputStream byreReaderPlayerTask = new ByteArrayInputStream(
						gson.fromJson(reader.nextLine(), byte[].class));
				ObjectInputStream objectReaderPlayerTask = new ObjectInputStream(byreReaderPlayerTask);

				PlayerTask playerTask = (PlayerTask) objectReaderPlayerTask.readObject();
				playerTask.setCheat((CheatEnum) objectReaderPlayerTask.readObject());
				playerTask.getCheat().setTypeOfBullet((int) objectReaderPlayerTask.readObject());
				playerTask.setDirection((DirectionEnum) objectReaderPlayerTask.readObject());
				playerTask.setIsShootingBullet((boolean) objectReaderPlayerTask.readObject());
				playerTask.setLocation((double) objectReaderPlayerTask.readObject(),
						(double) objectReaderPlayerTask.readObject());
//				System.out.println(playerTask);
//				PlayerTask playerTask = gson.fromJson(reader.nextLine(), PlayerTask.class);

				switch (playerTask) {
				case ChangeDirectionWithKeyword:
					MyAdminister.getInstance().getPlayer(id).getSpaceShip().setMove(playerTask.getDirection());
					break;

				case ChangeDirectionWithMouse:
					MyAdminister.getInstance().getPlayer(id).getSpaceShip()
							.setLocationOfSpaceShipWithMouse(playerTask.getX(), playerTask.getY());
//					System.out.println(playerTask.getX() + "   " + playerTask.getY());
//					System.out.println("in change direction");
//					System.out.println(playerTask.getX() + "      " + playerTask.getY());
					break;
				case Paint:
					synchronized (this) {
//						System.out.println(whichPanelPaint);
						printer.println(gson.toJson(whichPanelPaint));
						switch (whichPanelPaint) {
						case GamePanel:
							ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
							ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
							objectOutputStream.writeObject(MyAdminister.getInstance().getGalaxyWorld());

							printer.println(gson.toJson(byteArrayOutputStream.toByteArray()));
							break;
						case PauseGame:
							break;
						case WaitingPanel:
							printer.println(gson.toJson(MyAdminister.getInstance().getWaitingPanel()));
							break;
						case Quit:
							System.out
									.println(MyAdminister.getInstance().getGalaxyWorld().getScoreOfGame(id).getScore());
							printer.println(MyAdminister.getInstance().getGalaxyWorld().getScoreOfGame(id).getScore());
							printer.println(MyAdminister.getInstance().isPlayingSinglePlayer());
							MyAdminister.getInstance().stopGameEngine();

							new Thread(() -> {
								for (ControllerOfPlayer controllerOfPlayer : MyAdminister.getInstance().getGalaxyWorld()
										.getAllUsers()) {
									controllerOfPlayer.interrupt();
								}
							}).start();

							break;
						default:
							break;
						}
					}
					break;
				case PauseGame:
					MyAdminister.getInstance().stopGameEngine();
					MyAdminister.getInstance().changeAllUserForSituationOfGame(PlayerTask.PauseGame);
					break;
				case ShootBomb:
					MyAdminister.getInstance().getPlayer(id).tryingToShotBomb(true);
					break;
				case ShootBullet:
					MyAdminister.getInstance().getPlayer(id).tryingToShotBullet(playerTask.getIsShootingBullet());
					break;
				case RequestToPlay:
					if (MyAdminister.getInstance().getMaxPlayer() > MyAdminister.getInstance().getPlayers().size()) {
						if (MyAdminister.getInstance().getGalaxyWorld().getWaitingPlayer(id) == null
								&& MyAdminister.getInstance().getGalaxyWorld().getPlayer(id) == null) {
							MyAdminister.getInstance().getGalaxyWorld().getWaitingPlayers()
									.add(new Player(id, playerName));
							isSpectater = false;

						}
					}
					break;
				case StartGameNow:
					if (id == MyAdminister.getInstance().getServerPlayerId()
							&& !MyAdminister.getInstance().isGameStart()) {
						MyAdminister.getInstance().showGalaxyWorld();
					}
					break;
				case Cheating:
//					System.out.println(playerTask.getCheat() + " in server");
					checkCheat(playerTask.getCheat());
					break;
				case Continue:
					whichPanelPaint = PlayerTask.WaitingPanel;
					MyAdminister.getInstance().runGameEngine();
					break;
				case Quit:
//					printer.println(gson.toJson(PlayerTask.Quit));
					endConnection();
//					MyAdminister.getInstance().stopGameEngine();
					break;
				case NewFeature:
					byte[] data = new Gson().fromJson(reader.nextLine(), new TypeToken<byte[]>() {
					}.getType());
					ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
					ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
					Class newFeature = (Class) objectInputStream.readObject();

					MyAdminister.getInstance().addNewFeature(newFeature);

					break;
				case WhichPanelPaint:
//					System.out.println("in whichpanel");
					printer.println(new Gson().toJson(whichPanelPaint));
					break;
				default:
					break;

				}
			}
		} catch (Exception e) {
			endConnection();

		}

	}

	private void endConnection() {
		printer.close();
		reader.close();
		MyAdminister.getInstance().getGalaxyWorld().removePlayer(id);

	}

	private void checkCheat(CheatEnum cheat) {
		if (cheat != null) {
			switch (cheat) {
			case Bomb:
				MyAdminister.getInstance().getPlayer(id).increaseBomb();
				break;
			case LevelOfBullet:
				MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getPowerOfBullet().increaseLevel();
				break;
			case Life:
				MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getLifeOfPlayer().increaseLife();
				break;
			case Shield:
				MyAdminister.getInstance().getPlayer(id).getSpaceShip().setShieldForSpaceShip(
						!MyAdminister.getInstance().getPlayer(id).getSpaceShip().isHavingShield());
				break;
			case TypeOfBullet:
				MyAdminister.getInstance().getPlayer(id).getInformationOfPlayer().getPowerOfBullet()
						.setTypeOfBullet(cheat.getTypeOfBullet());
				break;
			default:
				break;
			}
		}
	}

	public boolean isSpectater() {
		return isSpectater;
	}

	public void setSpectater(boolean isSpectater) {
		this.isSpectater = isSpectater;
	}

	public PlayerTask getWhichPanelPaint() {
		return whichPanelPaint;
	}

	public void setWhichPanelPaint(PlayerTask whichPanelPaint) {
		this.whichPanelPaint = whichPanelPaint;
	}

	@Override
	public String toString() {
		String info = "[ Name: " + playerName;

		info += " , Id: " + id;
		info += " , IsSpectater: " + isSpectater;
		if (!isSpectater && MyAdminister.getInstance().getPlayer(id) != null) {
			Player player = MyAdminister.getInstance().getPlayer(id);
			info += " , Score: " + player.getInformationOfPlayer().getScore().getScoreOfGame();
			info += " , Life: " + player.getInformationOfPlayer().getLifeOfPlayer().getLife();
			info += " , Bomb: " + player.getInformationOfPlayer().getBombsOfPlayer().getNumberOfBomb();
			info += " , Degree: " + player.getInformationOfPlayer().getHeat().getDegreeHeat() + "/"
					+ player.getInformationOfPlayer().getHeat().getMaxHeat();

			info += " , Level Of Power: " + player.getInformationOfPlayer().getPowerOfBullet().getLevel();
		}

		info += "]";
		return info;
	}

}
