package Settings;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import Buttons.SettingMainMenu.BackButton;
import Buttons.SettingMainMenu.ControlsButton;
import Buttons.SettingMainMenu.CreditsButton;
import Buttons.SettingMainMenu.LogOutButton;
import Buttons.SettingMainMenu.SoundsButton;
import Buttons.SettingMainMenu.TuneButton;
import Controllers.MyAdminister;
import InterfaceAble.Drawable;
import ListOfAddress.MyObjectCollection;

public class MainSettingPanel extends JPanel implements Drawable  {

	private BufferedImage backgroundMainSetting;
	
	private ControlsButton controlsButton;
	private TuneButton tuneButton;
	private SoundsButton soundsButton;
	private LogOutButton logOutButton;
	private CreditsButton creditsButton;
	private BackButton backButton;
	
	
	public MainSettingPanel() {
		initialize();
		new Thread(() -> {
			while(true) {
				repaint();
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
	}
	
	private void initialize() {
		backgroundMainSetting = (BufferedImage) MyObjectCollection.getInstance().getImage("GalaxyBackgroundMainMenu2");
		addButtons();
		
	}

	private void addButtons() {
		controlsButton = new ControlsButton();
		tuneButton = new TuneButton();
		soundsButton = new SoundsButton();
		logOutButton = new LogOutButton();
		creditsButton = new CreditsButton();
		backButton = new BackButton();
		
		addMouseListener(controlsButton);
		addMouseListener(logOutButton);
		addMouseListener(backButton);
		addMouseListener(creditsButton);
		addMouseListener(soundsButton);
		addMouseListener(tuneButton);
		
		addMouseMotionListener(controlsButton);
		addMouseMotionListener(logOutButton);
		addMouseMotionListener(backButton);
		addMouseMotionListener(creditsButton);
		addMouseMotionListener(soundsButton);
		addMouseMotionListener(tuneButton);
	}

	@Override
	public void render(Graphics2D g) {
		g.drawImage(backgroundMainSetting, 0, 0,
				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth(), 
				(int)MyAdminister.getInstance().getSizeOfFrame().getHeight(),null);
		renderButtons(g);
	}

	private void renderButtons(Graphics2D g) {
		controlsButton.paint(g);
		tuneButton.paint(g);
		soundsButton.paint(g);
		logOutButton.paint(g);
		creditsButton.paint(g);
		backButton.paint(g);
		
	}

	@Override
	protected void paintComponent(Graphics g) {
		render((Graphics2D) g);
	}

	public void setSelectedOfSettingButtons(boolean b) {
		tuneButton.setSelected(b);
		soundsButton.setSelected(b);
		controlsButton.setSelected(b);
	}

}
