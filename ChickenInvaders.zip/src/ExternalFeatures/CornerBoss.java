package ExternalFeatures;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.concurrent.CopyOnWriteArrayList;

import ActionEnum.DirectionEnum;
import ActionEnum.FeatureEnum;
import BossPackage.Fire;
import BossPackage.OriginalBoss;
import BulletPackage.Bullet;
import BulletPackage.LinearBullet;
import BulletPackage.OriginalBullet;
import ChickenPackage.Chicken;
import Controllers.MyAdminister;
import GamePackage.Player;
import InfoAnotation.WhichFeature;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;

@WhichFeature(feature = FeatureEnum.Boss)
public class CornerBoss extends OriginalBoss {

	private boolean isDestroy;

	private DirectionEnum direction;

	private double degree;
	private long lastShotFire;

	public CornerBoss(int levelPlayerPlay) {
		super(levelPlayerPlay);
		setX(-getDimension().getWidth());
		setY(0);

		direction = DirectionEnum.MoveRight;

		lastShotFire = System.currentTimeMillis();

	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;
	}

	@Override
	public void move() {
		super.move();
		changeLocationOfBoss();

	}

	private void changeLocationOfBoss() {
		switch (direction) {
		case MoveRight:
			setX(getLocation().getX() + 1);
			break;
		case MoveDown:
			setY(getLocation().getY() + 1);
			break;
		case MoveLeft:
			setX(getLocation().getX() - 1);
			break;
		case MoveUp:
			setY(getLocation().getY() - 1);
			break;
		default:
			break;
		}
	}

	@Override
	public void update() {
		super.update();
		move();

		ifChangeDirection();

		if (System.currentTimeMillis() - lastShotFire >= 500) {
			lastShotFire = System.currentTimeMillis();
			degree = Math.random() * 360;
			for (int i = 1; i <= 8; i++) {
				if (Math.random() < 0.8 && ifDrectionPermit(degree + i * 360 / 8)) {
					getFires().add(new Fire(
							new Point((int) (getLocation().getX() + getDimension().getWidth() / 2),
									(int) (getLocation().getY() + getDimension().getHeight() / 2)),
							degree + i * 360 / 8));
				}
			}
		}

	}

	private boolean ifDrectionPermit(double degree) {
		degree = degree % 360;
		switch (direction) {
		case MoveRight:
			if (0 <= degree && degree <= 180) {
				return true;
			}
			break;
		case MoveDown:
			if (90 <= degree && degree <= 270) {
				return true;
			}
			break;
		case MoveLeft:
			if (180 <= degree && degree <= 360) {
				return true;
			}
			break;
		case MoveUp:
			if ((270 <= degree && degree <= 360) || (0 <= degree && degree <= 90)) {
				return true;
			}
			break;

		default:
			break;
		}
		return false;
	}

	private void ifChangeDirection() {
		switch (direction) {
		case MoveRight:
			if (MyAdminister.getInstance().getSizeOfFrame().getWidth() <= getDimension().getWidth()
					+ getLocation().getX())
				direction = DirectionEnum.MoveDown;
			break;
		case MoveDown:
			if (MyAdminister.getInstance().getSizeOfFrame().getHeight() <= getDimension().getHeight()
					+ getLocation().getY())
				direction = DirectionEnum.MoveLeft;
			break;
		case MoveLeft:
			if (0 >= getLocation().getX())
				direction = DirectionEnum.MoveUp;
			break;
		case MoveUp:
			if (0 >= getLocation().getY())
				direction = DirectionEnum.MoveRight;
			break;
		default:
			break;
		}

	}

}
