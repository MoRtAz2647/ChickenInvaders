package Buttons.PausePanel;

import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.PrintStream;

import javax.swing.JOptionPane;

import com.google.gson.Gson;

import ActionEnum.PlayerTask;
import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import InterfaceAble.BroadcastOfPlayerTask;
import ListOfAddress.MyObjectCollection;
import PlayersData.Players;

public class QuitButton extends OriginalButton implements BroadcastOfPlayerTask{

	private PrintStream printer;

	public QuitButton() {
		super((BufferedImage) (MyObjectCollection.getInstance().getImage("QuitInClick")),
				(BufferedImage) (MyObjectCollection.getInstance().getImage("QuitOutClick")),
				(int) MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2 - 250,
				(int) MyAdminister.getInstance().getSizeOfFrame().getHeight() / 2 - 50 + 55, 500, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().showMainMenu();
			if (MyAdminister.getInstance().isPlayingSinglePlayer()) {
				MyAdminister.getInstance().updateDataOfPlayer();
			} 
				MyAdminister.getInstance().getPlayingAccount();
				synchronized (printer) {
					send(PlayerTask.Quit, printer);
					
				}

			
		}
	}

	public void setPrinter(PrintStream printer) {
		this.printer = printer;
	}

}
