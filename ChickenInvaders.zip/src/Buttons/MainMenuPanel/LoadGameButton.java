package Buttons.MainMenuPanel;

import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import Buttons.PanelAccounts.OriginalButton;
import Controllers.MyAdminister;
import ListOfAddress.MyObjectCollection;

public class LoadGameButton extends OriginalButton {

	public LoadGameButton() {
		super((BufferedImage) MyObjectCollection.getInstance().getImage("LoadGameInClick"),
				(BufferedImage) MyObjectCollection.getInstance().getImage("LoadGameOutClick"),
//				(int)MyAdminister.getInstance().getSizeOfFrame().getWidth()/2 - 250,
				50, (int) MyAdminister.getInstance().getSizeOfFrame().getHeight() - 50 - 100 * 5 - 25 * 4, 400, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (rectangle.contains(e.getPoint())) {
			MyAdminister.getInstance().playingClickSound();
			MyAdminister.getInstance().createGalaxyWorld(true, false, 1, 4, 4);
			MyAdminister.getInstance().runServerConnecter(9999);
			MyAdminister.getInstance().createClientPlayer("127.0.0.1", 9999, false);
			MyAdminister.getInstance().showGalaxyWorld();
			;
		}
	}

}
