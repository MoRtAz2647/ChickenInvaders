package ChickenPackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.nio.BufferUnderflowException;
import java.util.ArrayList;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import BulletPackage.Bullet;
import BulletPackage.LinearBullet;
import BulletPackage.OriginalBullet;
import Controllers.MyAdminister;
import GamePackage.Player;
import GamePackage.SpaceShip;
import InterfaceAble.Destroyable;
import InterfaceAble.Movable;
import InterfaceAble.Paintable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import Tool.IntersectsRotateRectangle;
import Tool.SuperGameEngineThread;

public
//abstract 
class Chicken
//	extends SuperGameEngineThread 
		implements Destroyable, Updatable, Paintable, Movable  , Serializable{

	private int level;
	private double hp;
	private boolean isDestroy;

	private double probablityOfCreateEgg;
	private long lastTimeThrowEgg = 0;
	private boolean isThrowEgg = false;

	private transient ArrayList<BufferedImage> chickens = new ArrayList<>();
	private int whichPictureSelected = 0;
	private long lastChangePicture = 0;

	private double x;
	private double y;
	public final static int height = 100;
	public final static int width = 100;

	private double xMustBe;
	private double yMustBe;
	private boolean isInPlace = false;
	private long whenBeInPlace = 0;

	private double velocty = 1;

	public Chicken(int level, int x, int y) {

		getImage();

		this.level = level;
		this.hp = level * 2 * Math.sqrt(MyAdminister.getInstance().getPlayers().size());
		this.probablityOfCreateEgg = level * 0.0005;

		this.x = x;
		this.y = y;

		isDestroy = false;
	}

	private void getImage() {
		chickens = new ArrayList<>();
		for (int i = 1; i <= 7; i++) {
			chickens.add((BufferedImage) MyObjectCollection.getInstance().getImage("Chicken" + level + "" + i));

		}
	}

	@Override
	public void move() {

	}

	@Override
	public void paint(Graphics2D g) {
		if (!isDestroy) {
			g.drawImage(getImg(), (int) x, (int) y, width, height, null);
		}
	}

	private Image getImg() {
		if (chickens == null) {
			getImage();
		}
		return chickens.get(whichPictureSelected);
	}

	@Override
	public void update() {
		if (!isDestroy) {
			for (Player player : MyAdminister.getInstance().getPlayers()) {

				if (player.getInformationOfPlayer().getBombsOfPlayer().isBlasting()) {
					hp = 0;
				}
				for (Bullet bullet : player.getBullets()) {
//					if (new Rectangle((int) x, (int) y, width, height).intersects(bullet.getRectangle())
					synchronized (bullet) {
//							if (Point.distance(x, y, ((LinearBullet) bullet).getRectangle().getX(),
//									((LinearBullet) bullet).getRectangle().getY()) < 200) {
						if (bullet.isIntersect(new Rectangle((int) x, (int) y, width, height), 0) && !bullet.isDestroy()
								&& hp > 0) {
							hp -= bullet.getPower();
							bullet.setDestroy();
							if (hp <= 0) {
								player.getInformationOfPlayer().getScore().increaseScore(level * 2);
							}
						}
					}
//					}
				}
				synchronized (player.getSpaceShip()) {

					if (new Rectangle((int) x, (int) y, width, height).intersects(player.getSpaceShip().getRectangle())
							&& !player.getSpaceShip().isDestroy() && hp > 0
							&& !player.getSpaceShip().isHavingShield()) {
						hp = 0;
						player.getSpaceShip().setDestroy();
						player.getInformationOfPlayer().getScore().increaseScore(level * 2);
					}
				}
			}

			if (probablityOfCreateEgg >= Math.random() && System.currentTimeMillis() - lastTimeThrowEgg >= 1000) {
				lastTimeThrowEgg = System.currentTimeMillis();
				isThrowEgg = true;

			}

			if (System.currentTimeMillis() - lastChangePicture >= 60) {
				lastChangePicture = System.currentTimeMillis();
				whichPictureSelected++;
				if (chickens == null) {
					getImage();
				}
				if (whichPictureSelected >= chickens.size()) {
					whichPictureSelected = 0;

				}
			}
		}

		if (hp <= 0 && !isDestroy) {
			isDestroy = true;
			playingSoundDamaging();
		}
	}

	@Override
	public boolean isDestroy() {
		return isDestroy;
	}

	@Override
	public void setDestroy() {
		isDestroy = true;

	}

	public void setWhereMustBe(double x, double y) {
		xMustBe = x;
		yMustBe = y;
	}

	public boolean isInPLace() {
		return isInPlace;
	}

	public Point getLocation() {
		return new Point((int) x, (int) y);
	}

	public Dimension getDimension() {
		return new Dimension(width, height);
	}

	public void setLocation(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public Point getLocationMustBe() {
		return new Point((int) xMustBe, (int) yMustBe);
	}

	public long getWhenBeInPlace() {
		return whenBeInPlace;
	}

	public void setVelocty(double d) {
		velocty = d;

	}

	public double getVelocty() {
		return velocty;
	}

	public void setInPlace(boolean isInPlace) {
		this.isInPlace = isInPlace;
	}

	public void setWhenBeInPlace(long whenBeInPlace) {
		this.whenBeInPlace = whenBeInPlace;
	}

	private void playingSoundDamaging() {
		new Thread(() -> {

			try {
				Clip damaging = AudioSystem.getClip();
				damaging.open(MyObjectCollection.getInstance().getSound("DamagingChicken"));
				damaging.start();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}).start();

	}

	public boolean isThrowEgg() {
		if (isThrowEgg) {
			isThrowEgg = false;
			return true;
		}
		return false;

	}

	public int getLevel() {
		return level;
	}

	public Point getMiddle() {
		return new Point((int) (x + width / 2), (int) (y + (height / 2)));
	}
	
	

}
