package GamePackage;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Modifier;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;

import ActionEnum.PlayerTask;
import Controllers.ControllerOfPlayer;
import Controllers.MyAdminister;
import GameListeners.BombListener;
import GameListeners.BulletsListener;
import GameListeners.CheatListener;
import GameListeners.SpaceShipListener;
import GamePackage.Tabs.InformationOfPlayerTab;
import GamePackage.Tabs.ScoreAndHeatTab;
import InterfaceAble.Drawable;
import InterfaceAble.Updatable;
import ListOfAddress.MyObjectCollection;
import StagesOfGame.HandlerOfEnemyAndChicken;

public class GameEngine implements Runnable, Updatable {

	private transient boolean running;
	private transient int repaints = 0;
	private transient Thread gameThread;
	private boolean isGameStart = false;

	private WaitingPanel waitingPanel;
//	
//	private transient SpaceShipListener spaceShipListener;
//	private transient BulletsListener bulletsListener;
//	private transient BombListener bombListener;
//	private transient CheatListener cheatListener;

	private transient Clip inGameSound;

	private GalaxyWorld galaxyWorld;
	private String playerName;

	private PlayerTask whichSituation;

	public GameEngine(String playerName) {
		this.playerName = playerName;

		initialize();
//		new Thread(()->{
//			while(true) {
//				repaint();
//			}
//		}).start();
	}

	public GalaxyWorld getGalaxyWorld() {
		return galaxyWorld;
	}

	public void setGalaxyWorld(GalaxyWorld galaxyWorld) {
		this.galaxyWorld = galaxyWorld;
	}

	private void initialize() {
		whichSituation = PlayerTask.WaitingPanel;

		waitingPanel = new WaitingPanel(4, 4);
		galaxyWorld = new GalaxyWorld(4, 4);
//
//		spaceShipListener = new SpaceShipListener();
//		bombListener = new BombListener();
//		bulletsListener = new BulletsListener();
//		cheatListener = new CheatListener();
//
//		addMouseMotionListener(spaceShipListener);
//		addMouseListener(spaceShipListener);
//		addMouseListener(bulletsListener);
//		addMouseMotionListener(bulletsListener);
//		addMouseListener(bombListener);
//		addMouseMotionListener(bombListener);
//
//		addKeyListener(this);
//		addKeyListener(spaceShipListener);
//		addKeyListener(bulletsListener);
//		addKeyListener(bombListener);
//		addKeyListener(cheatListener);

//		try {
//			new Robot().mouseMove((int) (MyAdminister.getInstance().getSizeOfFrame().getWidth() / 2),
//					(int) (MyAdminister.getInstance().getSizeOfFrame().getHeight() - 28));
//		} catch (AWTException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		setVisible(true);
	}

	public void start() {
		running = true;
		if (gameThread == null) {
			gameThread = new Thread(this);
			playingSoundGame();
			gameThread.start();
		}
//		if (!gameThread.isAlive()) {
//			gameThread.start();
//		}
//		try {
//			new Robot().mouseMove((int) galaxyWorld.getPlayers().get(0).getSpaceShip().getLocation().getX(),
//					(int) galaxyWorld.getPlayers().get(0).getSpaceShip().getLocation().getY());
//		} catch (AWTException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

	public void stop() {
		running = false;
		if (whichSituation == PlayerTask.GamePanel) {
			stopSoundGame();
		}
		Thread thread = gameThread;
		gameThread = null;
		thread.stop();
//		try {
//			gameThread.join();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

	}

	@Override
	public void run() {
		while (true) {
			// The Game Loop
			long lastTime = System.nanoTime();
//			double amountOfTicks = 100.0; // per second
			double amountOfTicks = 60.0; // per second
			double ns_per_tick = 1000000000 / amountOfTicks; // results in almost: 16 millions
			double delta = 0;
			long timer = System.currentTimeMillis();
			int frames = 0;
			while (running) {

				long now = System.nanoTime();
				delta += (now - lastTime) / ns_per_tick;
				lastTime = now;
				while (delta >= 1) {
					update(); // must take less than 16 million nano seconds
					frames++;
					delta--;
				}
//				if (running) {
//					repaint();
//				}

				try {
					Thread.sleep(frames > 105 ? 30 : 0);
					Thread.sleep((long) Math.max((System.nanoTime() - lastTime - ns_per_tick) / 1000000, 1));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				if (frames > 100) {
					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				if (System.currentTimeMillis() - timer > 1000) {
					timer += 1000;
//					System.out.format("FPS: %d repaints: %d%n", frames, repaints);
					frames = 0;
					repaints = 0;
				}

			}
		}
	}

	@Override
	public void update() {
		if (whichSituation == PlayerTask.GamePanel) { // gamePanel
			galaxyWorld.update();
		} else
//			if (whichSituation == PlayerTask.WaitingPanel || whichSituation == PlayerTask.PauseGame)
		{ // waitingPanel
			waitingPanel.update();
		}
	}
//
//	@Override
//	protected void paintComponent(Graphics graphics) {
//		Graphics2D g = (Graphics2D) graphics;
//		render(g);
//
//	}

//	@Override
//	public void render(Graphics2D g) {
//		galaxyWorld.paint(g);
//
//	}

	public boolean isRunning() {
		return gameThread == null;
	}

	private void playingSoundGame() {

		try {
			inGameSound = AudioSystem.getClip();
			inGameSound.open(MyObjectCollection.getInstance().getSound("InGameSound"));
			inGameSound.loop(Clip.LOOP_CONTINUOUSLY);
			inGameSound.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void stopSoundGame() {
		if (inGameSound != null)
			inGameSound.stop();
	}

	public boolean isStartGame() {
		return isGameStart;
	}

	public WaitingPanel getWaitingPanel() {
		return waitingPanel;
	}

	public void setWaitingPanel(WaitingPanel waitingPanel) {
		this.waitingPanel = waitingPanel;
	}

	public PlayerTask getWhichSituation() {
		return whichSituation;
	}

	public void setWhichSituation(PlayerTask whichSituation) {
		this.whichSituation = whichSituation;
	}

}
